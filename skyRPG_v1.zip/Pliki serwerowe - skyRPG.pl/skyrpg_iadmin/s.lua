addEvent("i:przecho", true)
addEventHandler("i:przecho", root, function(p)
	if getElementData(p, "id") then
		--exports["nm-noti"]:noti("Pomyślnie oddano pojazd do przechowalni.", source)
		exports.skyrpg_gui:addNotification(source, "Pomyślnie oddano pojazd do przechowalni.", 'success')
		exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(p, "id"))
		destroyElement(p)
	else
		destroyElement(p)
		--exports["nm-noti"]:noti("Pomyślnie usunięto pojazd.", source)
		exports.skyrpg_gui:addNotification(source, "Pomyślnie usunięto pojazd.", 'success')
	end
end)

addEvent("i:obroc", true)
addEventHandler("i:obroc", root, function(p)
	local rx, ry, rz = getElementRotation(p)
	setElementRotation(p, 0, 0, rz)
end)

addEvent("i:napraw", true)
addEventHandler("i:napraw", root, function(p)
	fixVehicle(p)
end)

addEvent("i:reczny", true)
addEventHandler("i:reczny", root, function(l, p)
	if isElementFrozen(p) == true then
		setElementFrozen(p, false)
		--exports["nm-noti"]:noti("Spuściłeś ręczny w pojeździe.", l)
		exports.skyrpg_gui:addNotification(l, "Spuściłeś ręczny w pojeździe.", 'info')
	else
		setElementFrozen(p, true)
		--exports["nm-noti"]:noti("Zaciągnąłeś ręczny w pojeździe.", l)
		exports.skyrpg_gui:addNotification(l, "Zaciągnąłeś ręczny w pojeździe.", 'info')
	end
end)
