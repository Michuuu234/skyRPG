local a_pojazd = false
local f3 = false

local o = {}
o.b1 = guiCreateButton(0.306, 0.20, 0.12, 0.07, "Zamknij panel", true)
o.b2 = guiCreateButton(0.306, 0.12, 0.12, 0.07, "Oddaj na parking", true)
o.b3 = guiCreateButton(0.436, 0.12, 0.12, 0.07, "Napraw pojazd", true)
o.b4 = guiCreateButton(0.566, 0.12, 0.12, 0.07, "Zatankuj pojazd", true)
o.b5 = guiCreateButton(0.436, 0.20, 0.12, 0.07, "Obróć pojazd", true)
o.b6 = guiCreateButton(0.566, 0.20, 0.12, 0.07, "Spuść ręczny", true)
guiSetVisible(o.b1, false)
guiSetVisible(o.b2, false)
guiSetVisible(o.b3, false)
guiSetVisible(o.b4, false)
guiSetVisible(o.b5, false)
guiSetVisible(o.b6, false)

local c = guiCreateFont( ":skyrpg_gui/hud/fonts/normal.ttf", 10 )
guiSetFont(o.b1, c)
guiSetFont(o.b2, c)
guiSetFont(o.b3, c)
guiSetFont(o.b4, c)
guiSetFont(o.b5, c)
guiSetFont(o.b6, c)

addEventHandler("onClientGUIClick", resourceRoot, function()
	if source == o.b1 then
		close()
	elseif source == o.b2 then
		triggerServerEvent("i:przecho", localPlayer, a_pojazd)
		close()
	elseif source == o.b3 then
		triggerServerEvent("i:napraw", localPlayer, a_pojazd)
		--exports["nm-noti"]:noti("Naprawiłeś pojazd.")
		exports.skyrpg_gui:addNotification("Naprawiono pojazd.", 'success')
		close()
	elseif source == o.b4 then
		local bak = getElementData(a_pojazd, "bak") or 100
		setElementData(a_pojazd, "paliwo", bak)
		--exports["nm-noti"]:noti("Zatankowałeś pojazd.")
		exports.skyrpg_gui:addNotification("Zatankowano pojazd.", 'success')
		close()
	elseif source == o.b5 then
		triggerServerEvent("i:obroc", localPlayer, a_pojazd)
		--exports["nm-noti"]:noti("Obróciłeś pojazd na koła.")
		exports.skyrpg_gui:addNotification("Obrócono pojazd na kołą.", 'success')
		close()
	elseif source == o.b6 then
		triggerServerEvent("i:reczny", resourceRoot, localPlayer, a_pojazd)
		close()
	end
end)

function close()
	removeEventHandler("onClientPreRender", root, gui)
	guiSetVisible(o.b1, false)
	guiSetVisible(o.b2, false)
	guiSetVisible(o.b3, false)
	guiSetVisible(o.b4, false)
	guiSetVisible(o.b5, false)
	guiSetVisible(o.b6, false)
	f3 = false
	showCursor(false)
	a_pojazd = false
end

local screenW, screenH = guiGetScreenSize()

local czcionka = dxCreateFont(":skyrpg_gui/hud/fonts/normal.ttf", 8)
if not czcionka then czcionka = "default-bold" end

function gui()
  exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.3031, screenH * 0.0365, screenW * 0.3865, screenH * 0.2589, tocolor(150, 150, 150, 255))
  dxDrawText("Pojazd: "..getVehicleName(a_pojazd).." | ID: "..(getElementData(a_pojazd, "id") or 0), (screenW * 0.3067) + 1, (screenH * 0.0404) + 1, (screenW * 0.6823) + 1, (screenH * 0.1107) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
  dxDrawText("Pojazd: "..getVehicleName(a_pojazd).." | ID: "..(getElementData(a_pojazd, "id") or 0), screenW * 0.3067, screenH * 0.0404, screenW * 0.6823, screenH * 0.1107, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
end

bindKey("F3", "down", function()
	if not getElementData(localPlayer, "duty") then return end
	if isCursorShowing() then
		f3 = false
		showCursor(false)
		if guiGetVisible(o.b5) then
			removeEventHandler("onClientPreRender", root, gui)
			guiSetVisible(o.b1, false)
			guiSetVisible(o.b2, false)
			guiSetVisible(o.b3, false)
			guiSetVisible(o.b4, false)
			guiSetVisible(o.b5, false)
			guiSetVisible(o.b6, false)
			a_pojazd = false
		end
	else
		f3 = true
		showCursor(true, false)
	end
end)

addEventHandler("onClientClick", getRootElement(), function (button, state, _, _, _, _, _, el)
  if not el or button ~= "left" or state ~= "down" then return end
  if getElementType(el) == "vehicle" and getElementData(localPlayer, "duty") and f3 == true then
		if guiGetVisible(o.b1) == true then return end
		addEventHandler("onClientPreRender", root, gui)
		a_pojazd = el
		guiSetVisible(o.b5, true)
		guiSetVisible(o.b6, true)
		guiSetVisible(o.b1, true)
		guiSetVisible(o.b2, true)
		guiSetVisible(o.b3, true)
		guiSetVisible(o.b4, true)
		if isElementFrozen(a_pojazd) == true then
			guiSetText(o.b6, "Spuść ręczny")
		else
			guiSetText(o.b6, "Zaciągnij ręczny")
		end
		showCursor(true, false)
	end
end)