removeWorldModel(11360, 5, -2038.873046875, 169.986328125, 28.839275360107)
removeWorldModel(11359, 5, -2052.7578125, 150.462890625, 28.8359375)
removeWorldModel(11416, 5, -2026.716796875, 129.830078125, 28.842931747437)
removeWorldModel(11327, 5, -2026.9326171875, 129.833984375, 28.842931747437)

local kolizja = engineLoadCOL("collision.col")
engineReplaceCOL(kolizja, 11387)

local punkty = {
{-2050.75, 175.90, 28.84},
{-2050.66, 167.67, 28.84},
}

for i,v in ipairs(punkty) do
	createMarker(v[1], v[2], v[3]-0.9, "cylinder", 1, 0, 0, 255, 75)
end

addEventHandler("onClientMarkerHit", resourceRoot, function(hit) if hit ~= localPlayer then return end setElementData(hit, "mechanik", true) showCursor(true, false) km = true exports["skyrpg_gui"]:addNotification("Aby naprawić pojazd, naciśnij na niego!", 'info') end)
addEventHandler("onClientMarkerLeave", resourceRoot, function(hit) if hit ~= localPlayer then return end setElementData(hit, "mechanik", false) showCursor(false) km = false end)

local text = "Pojazd jest w niskim stanie technicznym (50%)\nCena naprawy wyniesie 150.15 PLN\nAby naprawić pojazd Banshee kliknij przycisk 'Napraw'."
local cena = false
local pojazd = false

local cuboid = createColCuboid(-2056.54, 174.85, 30.09-2.5, 15, 7, 5)
local cuboid2 = createColCuboid(-2056.54, 166.85, 30.09-2.5, 15, 7, 5)

local screenW, screenH = guiGetScreenSize()
local sx, sy = guiGetScreenSize()

function mysz(psx,psy,pssx,pssy,abx,aby)
    if not isCursorShowing() then return end
    cx,cy=getCursorPosition()
    cx,cy=cx*sx,cy*sy
    if cx >= psx and cx <= psx+pssx and cy >= psy and cy <= psy+pssy then
        return true,cx,cy
    else
        return false
    end
end

local text = false

local czcionka = dxCreateFont(":skyrpg_gui/hud/fonts/normal.ttf", 8)
if not czcionka then czcionka = "default-bold" end

function gui()
	        exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.3572, screenH * 0.2813, screenW * 0.2862, screenH * 0.2461, tocolor(150, 150, 150, 255))
	        --dxDrawRectangle(screenW * 0.3565, screenH * 0.2786, screenW * 0.2870, screenH * 0.0521, tocolor(25, 75, 125, 155), false)
			dxDrawImage(screenW * 0.3565, screenH * 0.2786, screenW * 0.2870, screenH * 0.0521, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
	        dxDrawText("Panel naprawy pojazdów", (screenW * 0.3565) + 1, (screenH * 0.2786) + 1, (screenW * 0.6435) + 1, (screenH * 0.3307) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText("Panel naprawy pojazdów", screenW * 0.3565, screenH * 0.2786, screenW * 0.6435, screenH * 0.3307, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText(text, (screenW * 0.3638) + 1, (screenH * 0.3385) + 1, (screenW * 0.6318) + 1, (screenH * 0.4466) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText(text, screenW * 0.3638, screenH * 0.3385, screenW * 0.6318, screenH * 0.4466, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
					--[[if mysz(screenW * 0.3638, screenH * 0.4570, screenW * 0.1318, screenH * 0.0573) then
						dxDrawRectangle(screenW * 0.3638, screenH * 0.4570, screenW * 0.1318, screenH * 0.0573, tocolor(25, 75, 125, 180), false)
					else
						dxDrawRectangle(screenW * 0.3638, screenH * 0.4570, screenW * 0.1318, screenH * 0.0573, tocolor(25, 75, 125, 125), false)
					end
					if mysz(screenW * 0.4985, screenH * 0.4570, screenW * 0.1332, screenH * 0.0586) then
						dxDrawRectangle(screenW * 0.4985, screenH * 0.4570, screenW * 0.1332, screenH * 0.0586, tocolor(25, 75, 125, 180), false)
					else
						dxDrawRectangle(screenW * 0.4985, screenH * 0.4570, screenW * 0.1332, screenH * 0.0586, tocolor(25, 75, 125, 125), false)
					end]]--
			dxDrawImage(screenW * 0.3638, screenH * 0.4570, screenW * 0.1318, screenH * 0.0573, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
			dxDrawImage(screenW * 0.4985, screenH * 0.4570, screenW * 0.1332, screenH * 0.0586, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
	        dxDrawText("Napraw pojazd", (screenW * 0.3638) + 1, (screenH * 0.4557) + 1, (screenW * 0.4956) + 1, (screenH * 0.5143) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText("Napraw pojazd", screenW * 0.3638, screenH * 0.4557, screenW * 0.4956, screenH * 0.5143, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText("Zamknij panel", (screenW * 0.4985) + 1, (screenH * 0.4557) + 1, (screenW * 0.6318) + 1, (screenH * 0.5156) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	        dxDrawText("Zamknij panel", screenW * 0.4985, screenH * 0.4557, screenW * 0.6318, screenH * 0.5156, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
end


addEventHandler("onClientClick", getRootElement(), function (button, state, _, _, _, _, _, cw)
  if not cw or button ~= "left" or state ~= "down" then return end
  if getElementType(cw) ~= "vehicle" then return end
  if isElementWithinColShape(cw, cuboid) or isElementWithinColShape(cw, cuboid2) then
		if not text == false then return end
		if getElementData(localPlayer, "mechanik") ~= true then return end
		local zycie = getElementHealth(cw)/10
		if zycie == 100 then
			exports["skyrpg_gui"]:addNotification("Ten pojazd jest sprawny.", 'error')
			return
		end
    addEventHandler("onClientPreRender", root, gui)
		local stan = "dobrym"

		local zycie = getElementHealth(cw)/10
		local grosz = math.random(0, 10)

		if zycie > 3 and zycie <= 25 then
			cena = "500."..grosz
			stan = "bardzo niskim"
		elseif zycie > 25 and zycie <= 50 then
			cena = "350."..grosz
			stan = "niskim"
		elseif zycie > 50 and zycie <= 75 then
			cena = "200."..grosz
			stan = "średnim"
		elseif zycie > 75 and zycie <= 85 then
			cena = "100."..grosz
			stan = "dobrym"
		elseif zycie > 85 and zycie <= 100 then
			cena = "50."..grosz
			stan = "bardzo dobrym"
		end
		cena = string.format("%1.2f", cena)

		local nstan = string.format("%1d", zycie)

		pojazd = cw
		local np = getVehicleName(cw)
		text = "Pojazd jest w "..stan.." stanie technicznym ("..nstan.."%)\nCena naprawy wyniesie "..cena.."$\nAby naprawić pojazd "..np.." kliknij przycisk 'Napraw'."
 	   showCursor(true, false)
  end
end)

addEventHandler("onClientClick", root, function(button, state)
	if button ~= "state" and state ~= "down" then return end
	if mysz(screenW * 0.3638, screenH * 0.4570, screenW * 0.1318, screenH * 0.0573) and text ~= false then
		local hajs = getElementData(localPlayer, "dolary")
		hajs = string.format("%1.2f", hajs)
		hajs = tonumber(hajs)
		if hajs > tonumber(cena) then
			showCursor(false)
			removeEventHandler("onClientPreRender", root, gui)
			exports["skyrpg_gui"]:addNotification("Naprawiłeś pojazd "..getVehicleName(pojazd).." za cene "..cena.."$.", 'success')
			fixVehicle (pojazd)
			setElementData(localPlayer, "dolary", hajs-cena)
			text = false
		else
			exports["skyrpg_gui"]:addNotification("Potrzebujesz "..cena.." PLN aby naprawić pojazd, masz "..hajs.."$.", 'error')
			showCursor(false)
			text = false
			removeEventHandler("onClientPreRender", root, gui)
		end
	elseif mysz(screenW * 0.4985, screenH * 0.4570, screenW * 0.1332, screenH * 0.0586) and text ~= false then
		removeEventHandler("onClientPreRender", root, gui)
		showCursor(false)
		text = false
	end
end)
