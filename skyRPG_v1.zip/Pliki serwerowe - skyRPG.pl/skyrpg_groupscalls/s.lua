function straz_pozarna(plr,commands, ...) 
local msg = table.concat ( {...}, " " ) 
exports.skyrpg_gui:addNotification(plr, "Wezwano San Andreas Fire Departament!", 'success')
for k,v in ipairs(getElementsByType("player")) do
if getElementData(v, "sluzba")=="SAFD" then
	outputChatBox( "* "..getPlayerName(plr):gsub("#%x%x%x%x%x%x","")..", zadzwonił po Was, powód: "..msg:gsub("#%x%x%x%x%x%x","")..". ",v) 
    end
 end
end 
addCommandHandler("wezwij.safd",straz_pozarna)

function pogotowie(plr,commands, ...) 
local msg = table.concat ( {...}, " " ) 
exports.skyrpg_gui:addNotification(plr, "Wezwano San Andreas Medical Center!", 'success')
for k,v in ipairs(getElementsByType("player")) do
if getElementData(v, "sluzba")=="SAMC" then
	outputChatBox( "* "..getPlayerName(plr):gsub("#%x%x%x%x%x%x","")..", zadzwonił po Was, powód: "..msg:gsub("#%x%x%x%x%x%x","")..". ",v) 
    end
 end
end 
addCommandHandler("wezwij.samc",pogotowie)

function policja(plr,commands, ...) 
local msg = table.concat ( {...}, " " ) 
exports.skyrpg_gui:addNotification(plr, "Wezwano San Andreas Police Departament!", 'success')
for k,v in ipairs(getElementsByType("player")) do
if getElementData(v, "sluzba")=="SAPD" then
	outputChatBox( "* "..getPlayerName(plr):gsub("#%x%x%x%x%x%x","")..", zadzwonił po Was, powód: "..msg:gsub("#%x%x%x%x%x%x","")..". ",v) 
    end
 end
end 
addCommandHandler("wezwij.sapd",policja)