--     skyRPG, baza danych       --
-- 	      Autor: Michuuu 		--

local mysql = false

function connect()
	mysql = dbConnect("mysql", "dbname=mta;host=127.0.0.1", "root", "michal123", "share=1")
	if not mysql then
		outputDebugString("Nieudane połączenie z bazą danych.")
	else
		outputDebugString("Udane połączenie z bazą danych.")
	end
end
addEventHandler("onResourceStart", resourceRoot, connect)

function query(...)
	local qh = dbQuery(mysql, ...)
	if not qh then return false end
	local result, num_affected_rows, last_insert_id = dbPoll(qh, -1)
	return result, num_affected_rows, last_insert_id
end
