
local mule = createVehicle(414, -1709.86, -153.62, 44.09, 0.0, 0.0, 179.8)
addEventHandler("onVehicleStartEnter", mule, function() cancelEvent() end)
setVehicleDoorOpenRatio(mule, 1, 1, 2000)
setElementDimension(mule, 1)
setElementFrozen(mule, true)

local wozki = {
{-1732.00, -154.80, 43.7},
{-1734.50, -154.80, 43.7},
{-1737.00, -154.80, 43.7},
{-1739.50, -154.80, 43.7},
{-1742.00, -154.80, 43.7},
{-1744.50, -154.80, 43.7},
{-1747.00, -154.80, 43.7},
{-1749.50, -154.80, 43.7},
{-1753.00, -154.80, 43.7},
}

local shapes = {}

addEventHandler("onResourceStart", resourceRoot, function()
	for i,v in ipairs(wozki) do
		shapes[i] = createColSphere(v[1], v[2], v[3], 1.2)
		setElementDimension(shapes[i], 1)
		setElementData(shapes[i], "slot", i)
		stworzWozki(i)
		addEventHandler("onColShapeLeave", shapes[i], wyjechal)
	end
end)

function stworzWozki(slot)
local pojazdy = getElementsWithinColShape(shapes[slot], "vehicle")
 if #pojazdy == 1 then return end
	local x,y,z = wozki[slot][1], wozki[slot][2], wozki[slot][3]
	local pojazd = createVehicle(530, x, y, z)
	setVehicleHandling(pojazd, "maxVelocity", 35)
	setVehicleColor(pojazd, 255, 255, 0, 255, 255, 255)
	setElementData(pojazd, "nametag", "Praca w magazynie")
	setElementData(pojazd, "i", slot)
	setElementDimension(pojazd, 1)
	setElementFrozen(pojazd, true)
	addEventHandler("onVehicleEnter", pojazd, rozpocznijPrace)
end

function wyjechal(hit)
	if getElementType(hit) ~= "vehicle" then return end
	local i = getElementData(source, "slot")
	setTimer(stworzWozki, 5000, 1, i)
end

function rozpocznijPrace(gracz, tryb)
	if tryb ~= 0 then return end
	setElementFrozen(source, false)
	local p = gracz
	local lvl = getElementData(p, "mlvl")
	if lvl == 1 then l = "pierwszego"
	elseif lvl == 2 then l = "drugiego"
	elseif lvl == 3 then l = "trzeciego"
	elseif lvl == 4 then l = "czwartego"
	elseif lvl == 5 then l = "piątego"
	elseif lvl == 6 then l = "szóstego"
	elseif lvl == 7 then l = "siódmego"
	elseif lvl == 8 then l = "ósmego"
	elseif lvl == 9 then l = "dziewiątego"
	elseif lvl == 10 then l = "dziesiątego"
	end
	exports.skyrpg_gui:addNotification(p, "Rozpocząłeś prace magazyniera poziomu"..l..". Udaj się do ciężarówki aby załadować skrzynie.", 'info')
	triggerClientEvent("dpm", resourceRoot, p)
	setElementData(gracz, "pojazd", source)
end

addEventHandler("onVehicleExit", resourceRoot, function(p, tryb)
	if tryb ~= 0 then return end
	local pojazd = getElementData(p, "pojazd")
	local skrzynia = getElementData(p, "skrzynia")
	if skrzynia then
		destroyElement(skrzynia)
		setElementData(p, "skrzynia", false)
	end
	triggerClientEvent(p, "usun", resourceRoot)
	exports.skyrpg_gui:addNotification(p, "Zakończyłeś pracę w magazynie.", 'info')
	if getElementData(p, "isElementWithinMarker") == true then
		setElementData(p, "isElementWithinMarker", false)
	end
	local i = getElementData(pojazd, "i")
	if #getElementsWithinColShape(shapes[i]) < 0 then return end
	setTimer(stworzWozki, 5000, 1, i)
	destroyElement(pojazd)
	setElementData(p, "pojazd", false)
end)

addEventHandler("onPlayerQuit", root, function()
	local pojazd = getElementData(source, "pojazd")
	if not pojazd then return end

	local i = getElementData(pojazd, "i")
	if #getElementsWithinColShape(shapes[i]) < 0 then return end
	setTimer(stworzWozki, 5000, 1, i)

	destroyElement(pojazd)
	local skrzynia = getElementData(source, "skrzynia")
	if skrzynia then
		destroyElement(skrzynia)
	end
end)

addEvent("upm", true)
addEventHandler("upm", root, function(p)
	local skrzynia = getElementData(p, "skrzynia")
	if skrzynia then destroyElement(skrzynia) setElementData(p, "skrzynia", false) end
		local mlvl = getElementData(p, "mlvl")
		local mexp = getElementData(p, "mexp")
		local dbid = getElementData(p, "dbid")
		local wyk = exports.skyrpg_db:query("UPDATE konta SET mlvl=?, mexp=? WHERE dbid=?", mlvl, mexp, dbid)
		if not wyk then
			outputDebugScript("Blad magazynu")
		end
end)

addEvent("wpm", true)
addEventHandler("wpm", root, function(p)
	local pojazd = getElementData(p, "pojazd")
	local skrzynia = createObject(1271, 0, 0, 0)
	setElementDimension(skrzynia, 1)
	setElementCollisionsEnabled(skrzynia, false)
	attachElements(skrzynia, pojazd, 0, 0.6, 0.4)
	setObjectScale(skrzynia, 1.4)
	setElementData(p, "skrzynia", skrzynia)
end)
