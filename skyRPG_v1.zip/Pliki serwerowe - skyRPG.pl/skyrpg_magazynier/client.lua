setElementData(localPlayer, "isElementWithinMarker", false)

addEventHandler( "onClientKey", root, function(button,press)
    if button == "num_8" and getPedOccupiedVehicle(localPlayer) or button == "num_2" and getPedOccupiedVehicle(localPlayer) then
      cancelEvent()
    end
end)

local rmarker = false
local marker = false
local blip = false

addEvent("usun", true)
addEventHandler("usun", resourceRoot, function()
  if isElement(marker) and isElement(blip) then
    destroyElement(marker)
    destroyElement(blip)
  end
  if isElement(rmarker) then
    destroyElement(rmarker)
  end
end)

addEvent("dpm", true)
addEventHandler("dpm", resourceRoot, function(p)
  if p ~= localPlayer then return end
  rmarker = createMarker(-1709.84, -148.56, 43.99-1, "cylinder", 2, 255, 0, 0, 75)
  setElementDimension(rmarker, 1)
end)

local punkty = {
{-1737.84, -128.17, 43.99},
{-1743.66, -127.92, 43.99},
{-1751.99, -128.82, 43.99},
{-1751.99, -110.42, 43.99},
{-1751.35, -102.68, 43.99},
{-1751.75, -95.36, 43.99},
{-1751.61, -78.02, 43.99},
{-1745.79, -77.36, 43.99},
{-1741.34, -77.53, 43.99},
{-1731.84, -78.10, 43.99},
{-1726.09, -78.19, 43.99},
{-1717.46, -78.37, 43.99},
{-1711.87, -78.03, 43.99},
{-1706.61, -77.79, 43.99},
{-1707.03, -95.36, 43.99},
{-1707.15, -102.50, 43.99},
{-1707.55, -110.33, 43.99},
{-1719.83, -128.82, 43.99},
{-1714.23, -128.00, 43.99},
{-1706.90, -128.63, 43.99},
{-1734.48, -111.69, 43.99},
{-1729.12, -113.10, 43.99},
{-1723.63, -112.72, 43.99},
{-1735.20, -94.94, 43.99},
{-1729.20, -96.94, 43.99},
{-1729.23, -92.63, 43.99},
{-1723.08, -94.86, 43.99},
}

addEventHandler("onClientMarkerHit", resourceRoot, function(hit)
  if source ~= rmarker then return end
  if hit ~= localPlayer then return end
  if getElementData(hit, "skrzynia") then return end
  --exports["nm-noti"]:noti("Załadowałeś skrzynie, udaj się położyć ją na półke nieopodal.")
  exports.skyrpg_gui:addNotification("Załadowałeś skrzynie, udaj się położyć ją na półke nieopodal.", 'info')
  triggerServerEvent("wpm", resourceRoot, localPlayer)
  local r = math.random(2, #punkty)
  marker = createMarker(punkty[r][1], punkty[r][2], punkty[r][3]-1, "checkpoint", 2, 255, 0, 0, 75)
  blip = createBlipAttachedTo(marker, 41)
  setElementDimension(marker, 1)
  setElementDimension(blip, 1)
end)

addEventHandler("onClientMarkerHit", resourceRoot, function(hit)
  if source == marker then
    if hit ~= localPlayer then return end
    --exports["nm-noti"]:noti("Aby odłożyć skrzynie kliknij Spacje.")
	exports.skyrpg_gui:addNotification("Aby odłożyć skrzynie kliknij Spacje.", 'info')
    setElementData(hit, "isElementWithinMarker", true)
  end
end)

addEventHandler("onClientMarkerLeave", resourceRoot, function(hit)
  if source == marker then
    if hit ~= localPlayer then return end
    setElementData(hit, "isElementWithinMarker", false)
  end
end)

local hajs = false
local info = false

bindKey("space", "down", function()
  if getElementData(localPlayer, "isElementWithinMarker") == true then
    if getElementData(localPlayer, "premium") then
      hajs = math.random(90,110)
      exp = math.random(12,22)
    else
      hajs = math.random(70,90)
      exp = math.random(10,20)
    end
    if getElementData(localPlayer, "mlvl") == 1 then
      hajs = hajs+2.15
    elseif getElementData(localPlayer, "mlvl") == 2 then
      hajs = hajs+4.15
    elseif getElementData(localPlayer, "mlvl") == 3 then
      hajs = hajs+6.35
    elseif getElementData(localPlayer, "mlvl") == 4 then
      hajs = hajs+8.45
    elseif getElementData(localPlayer, "mlvl") == 5 then
      hajs = hajs+10.55
    elseif getElementData(localPlayer, "mlvl") == 6 then
      hajs = hajs+12.65
    elseif getElementData(localPlayer, "mlvl") == 7 then
      hajs = hajs+14.75
    elseif getElementData(localPlayer, "mlvl") == 8 then
      hajs = hajs+16.85
    elseif getElementData(localPlayer, "mlvl") == 9 then
      hajs = hajs+18.95
    elseif getElementData(localPlayer, "mlvl") == 10 then
      hajs = hajs+20.10
    end
    local hajsiwo = getElementData(localPlayer, "dolary")
    setElementData(localPlayer, "dolary", hajsiwo+hajs)
    local mexp = getElementData(localPlayer, "mexp")
    if getElementData(localPlayer, "mlvl") == 10 then
      info = "Odłożyłeś skrzynie na półke otrzymujesz "..hajs.."$."
      setElementData(localPlayer, "mexp", 0)
    else
      info = "Odłożyłeś skrzynie na półke otrzymujesz "..hajs.."$ oraz "..exp.." punktów doświadczenia."
      setElementData(localPlayer, "mexp", mexp+exp)
    end
    if getElementData(localPlayer, "mlvl") == 1 and getElementData(localPlayer, "mexp") >= 150 then
      outputChatBox("Awansowałeś na poziom 2!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 2)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 2 and getElementData(localPlayer, "mexp") >= 250 then
      outputChatBox("Awansowałeś na poziom 3!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 3)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 3 and getElementData(localPlayer, "mexp") >= 400 then
      outputChatBox("Awansowałeś na poziom 4!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 4)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 4 and getElementData(localPlayer, "mexp") >= 550 then
      outputChatBox("Awansowałeś na poziom 5!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 5)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 5 and getElementData(localPlayer, "mexp") >= 700 then
      outputChatBox("Awansowałeś na poziom 6!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 6)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 6 and getElementData(localPlayer, "mexp") >= 850 then
      outputChatBox("Awansowałeś na poziom 7!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 7)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 7 and getElementData(localPlayer, "mexp") >= 1000 then
      outputChatBox("Awansowałeś na poziom 8!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 8)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 8 and getElementData(localPlayer, "mexp") >= 1150 then
      outputChatBox("Awansowałeś na poziom 9!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 9)
      setElementData(localPlayer, "mexp", 0)
    elseif getElementData(localPlayer, "mlvl") == 9 and getElementData(localPlayer, "mexp") >= 1300 then
      outputChatBox("Awansowałeś na poziom 10!", 255, 255, 255)
      setElementData(localPlayer, "mlvl", 10)
      setElementData(localPlayer, "mexp", 0)
    end
    --exports["nm-noti"]:noti(info)
	exports.skyrpg_gui:addNotification(info, 'success')
    destroyElement(marker)
    destroyElement(blip)
    setElementData(localPlayer, "isElementWithinMarker", false)
    triggerServerEvent("upm", resourceRoot, localPlayer)
  end
end)
