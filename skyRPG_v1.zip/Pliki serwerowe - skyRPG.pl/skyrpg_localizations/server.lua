--[[
]]
setPlayerHudComponentVisible ( "area_name", false )