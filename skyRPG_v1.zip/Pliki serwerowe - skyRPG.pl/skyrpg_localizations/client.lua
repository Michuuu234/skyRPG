local sw,sh = guiGetScreenSize()

local font = dxCreateFont("rotz.ttf", 18)
if not font then dxfont0_tekst = "sans" end


addEventHandler("onClientPreRender", root, function()
	local x,y,z = getElementPosition(localPlayer)
	local ulica = getZoneName(x,y,z, false)
	local ulica2 = getZoneName(x,y,z, true)
	if ulica2~=ulica then ulica = "   "..ulica.."\n"..ulica2 else ulica = "   "..ulica end
	if dxSetAspectRatioAdjustmentEnabled then
		dxSetAspectRatioAdjustmentEnabled(true)
	end
	if isPlayerHudComponentVisible("radar") and getElementInterior(localPlayer) == 0 then
		dxDrawText(ulica, sw*4.2/20, sh*18/20, sw*4/20, sh*18/20+sh*1/21.9, tocolor(255, 255, 255,255), 1, font, "left", "center")
		
	end
end)