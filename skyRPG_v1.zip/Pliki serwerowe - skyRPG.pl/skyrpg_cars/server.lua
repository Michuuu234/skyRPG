function shuffle(t)
  local n = #t

  while n >= 2 do
    -- n is now the last pertinent index
    local k = math.random(n) -- 1 <= k <= n
    -- Quick swap
    t[n], t[k] = t[k], t[n]
    n = n - 1
  end
  return t
end

function onParkVehicle(vehicle)
	local query=exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(vehicle, "id"))
	if query then
        destroyElement(vehicle)
	end
end

local function vr()

	local pojazdy=getElementsByType("vehicle")

	if (#pojazdy<1) then return end

	local pojazdwoda={}
	for _,pojazd in ipairs(pojazdy) do
		if isElementInWater(pojazd) and not getVehicleController(pojazd) then
			local x,y,z=getElementPosition(pojazd)
			if (z<-1) then
				table.insert(pojazdwoda,pojazd)
			end
		end
	end
	if (#pojazdwoda<1) then return end

	shuffle(pojazdwoda)

	local pojazd=pojazdwoda[1]
	if getElementData(pojazd, "id") then
		onParkVehicle(pojazd)
	end
end
setTimer(vr, 35000, 0)

addEventHandler("onVehicleExit", resourceRoot, function(gracz, tryb)
	if tryb ~= 0 then return end
	setElementData(source, "naliczanie", true)
	local pojazd = source
	setTimer(function()
		if getElementData(pojazd, "naliczanie") then
			exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(pojazd, "id"))
			destroyElement(pojazd)
		end
	end, 25200000, 1)
end)

addEventHandler("onVehicleEnter", resourceRoot, function(gracz, tryb)
	if tryb ~= 0 then return end
	setElementData(source, "naliczanie", false)
end)

addEventHandler("onResourceStart", resourceRoot, function()
	local spr = exports.skyrpg_db:query("SELECT * FROM pojazdy WHERE przechowalnia=0")
	for _, p in ipairs(spr) do
		stworzPojazdy(p)
	end
end)

addEventHandler("onResourceStop", resourceRoot, function()
	for _, p in ipairs(getElementsByType("vehicle")) do
		zapiszPojazdy(p)
	end
end)

function stworzPojazdy(p)
	local pozycja = split(p.pozycja, ",")
	local kolor = split(p.kolor, ",")
	local pojazd = createVehicle(p.model, pozycja[1], pozycja[2], pozycja[3], pozycja[4], pozycja[5], pozycja[6])
	setVehicleColor(pojazd, kolor[1], kolor[2], kolor[3], kolor[4], kolor[5], kolor[6])
	setElementData(pojazd, "wlasciciel", p.wlasciciel)
	setElementData(pojazd, "id", p.id)
	setElementData(pojazd, "przebieg", p.przebieg)
	setElementData(pojazd, "paliwo", p.paliwo)
	setElementHealth(pojazd, p.zdrowie)
	if (p.panelstates~="0,0,0,0,0,0,0") then
    	p.panelstates=split(p.panelstates,",")
		for i,v in ipairs(p.panelstates) do
		  setVehiclePanelState(pojazd,i-1, tonumber(v))
		end
	else
    	p.panelstates=split(p.panelstates,",")
	end
	local tuning = split(p.tuning, ",")
	for i=1,#tuning do
		addVehicleUpgrade(pojazd, tuning[i])
	end
	--dodatki mechaniczne
	if p.intercooler == 1 then
		local handling = getVehicleHandling(pojazd)
		setVehicleHandling(pojazd, "engineAcceleration", handling.engineAcceleration+0.75)
	end
	if p.filtr == 1 then
		local handling = getVehicleHandling(pojazd)
		setVehicleHandling(pojazd, "engineAcceleration", handling.engineAcceleration+1.25)
	end
	if p.sturbo == 1 then
		local handling = getVehicleHandling(pojazd)
		setVehicleHandling(pojazd, "maxVelocity", handling.maxVelocity+15)
		setVehicleHandling(pojazd, "engineAcceleration", handling.engineAcceleration+2)
	end
	if p.duklad == 1 then
		local handling = getVehicleHandling(pojazd)
		setVehicleHandling(pojazd, "maxVelocity", handling.maxVelocity+8)
		setVehicleHandling(pojazd, "engineAcceleration", handling.engineAcceleration+1.2)
	end
	if p.zawieszenie == 1 then
		setElementData(pojazd, "zawieszenie", 2)
	end
	setElementData(pojazd, "bak", p.bak)
	--
	if p.organizacja:len() > 2 then
		setElementData(pojazd, "organizacja", p.organizacja)
	else
		setElementData(pojazd, "organizacja", false)
	end
	if p.rejestracja:len() > 1 then
		setVehiclePlateText(pojazd, p.rejestracja)
	else
		setVehiclePlateText(pojazd, "SR "..p.id)
	end
	if p.naped:len() > 1 then
		setVehicleHandling(pojazd, "driveType", p.naped)
	end
	if p.licznik ~= "" then
 		local licznik = split(p.licznik, ",")
		setElementData(pojazd, "lrgb", {
			["r"] = licznik[1],
			["g"] = licznik[2],
			["b"] = licznik[3],
		})
	end
	if p.swiatla:len() > 1 then
		local swiatla = split(p.swiatla, ",")
		setVehicleHeadLightColor(pojazd, swiatla[1], swiatla[2], swiatla[3])
	end
end

function zapiszPojazdy(p)
	local id = getElementData(p, "id")
	if not id then return end
	local x, y, z = getElementPosition(p)
	local model = getVehicleModel(p)
	local rx, ry, rz = getElementRotation(p)
	local r1,g1,b1, r2,g2,b2 = getVehicleColor(p, true)
	local pozycja = x..", "..y..", "..z..", "..rx..", "..ry..", "..rz
	local kolor = r1..", "..g1..", "..b1..", "..r2..", "..g2..", "..b2
	local zdrowie = getElementHealth(p)
	local paliwo = getElementData(p, "paliwo")
	local przebieg = getElementData(p, "przebieg")
	local panelstates={}
	for i=0,6 do
		table.insert(panelstates, getVehiclePanelState(p,i))
	end
	panelstates=table.concat(panelstates,",")
	local licznik = getElementData(p, "lrgb")
	local r,g,b = false
	if licznik then
		r = licznik.r
		g = licznik.g
		b = licznik.b
	else
		r = 255
		g = 255
		b = 255
	end
	local r3, g3, b3 = getVehicleHeadLightColor(p)
	local swiatla = r3..", "..g3..", "..b3
	licznik = r..", "..g..", "..b
	local wyk = exports.skyrpg_db:query("UPDATE pojazdy SET pozycja=?, model=?, kolor=?, panelstates=?, zdrowie=?, paliwo=?, przebieg=?, licznik=?, swiatla=? WHERE id=?", pozycja, model, kolor, panelstates, zdrowie, paliwo, przebieg, licznik, swiatla, id)
	if not wyk then
		outputDebugString("Nie udalo sie zapisac pojazdu o id "..id)
	end
end

addEventHandler("onVehicleStartEnter", root, function(gracz, seat)
	if seat ~= 0 then return end
	if getElementData(source, "id") then
		if getElementData(source, "keys") and getElementData(source, "keys") == getElementData(gracz, "dbid") then return end
		if getElementData(source, "organizacja") and getElementData(source, "organizacja") == getElementData(gracz, "organizacja") then return end
		if getElementData(source, "wlasciciel") ~= getElementData(gracz, "dbid") then
			cancelEvent()
			exports["skyrpg_gui"]:addNotification(gracz, "Ten pojazd nie należy do ciebie.", 'error')
		end
	end
end)

local motory = {
{"Freeway"},
{"FCR-900"},
{"Faggio"},
{"Pizzaboy"},
{"BF-400"},
{"NRG-500"},
{"PCJ-600"},
{"HPV-1000"},
{"Wayfarer"},
{"Sanchez"},
{"Quadbike"},
}

addEventHandler("onVehicleStartEnter", root, function(g, typ)
	if typ ~= 0 then return end
	local serial = getPlayerSerial(g)
	local spr = exports.skyrpg_db:query("SELECT * FROM prawka WHERE serial=? AND data>NOW()", serial)
	if #spr > 0 then
		exports["skyrpg_gui"]:addNotification(g, "Posiadasz zawieszone prawo jazdy kat. A, B, C od "..spr[1].admin.." do "..spr[1].data, 'error')
		cancelEvent()
	else
		exports.skyrpg_db:query("DELETE FROM prawka WHERE serial=?", serial)
	end
end)

addEventHandler("onVehicleStartEnter", root, function(gracz, seat)
	if seat ~= 0 then return end
	if not getElementData(source, "id") then return end
 	for i,v in ipairs(motory) do
 		if v[1] == getVehicleName(source) then 
 			if getElementData(gracz, "prawko_a") ~= 1 then
 				cancelEvent()
				exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy kategorii A.", 'error')
 				return 
 			end
 		end
	 end
	if getElementData(gracz, "prawko_b") ~= 1 then
		cancelEvent()
		exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy kategorii B.", 'error')
	end
end)

-- przechowalnia

local oddawanie = {
{-2121.98, 3.76, 35.32, -2121.98, -5.20, 35.32},
}

local odbieranie = {
{-2116.85, -0.61, 35.32},
}

local moddwanie = false
local modbieranie = false

addEventHandler("onResourceStart", resourceRoot, function()
	for _, m in ipairs(oddawanie) do
		moddwanie = createMarker(m[1], m[2], m[3]-1, "cylinder", 5, 255, 255, 255, 0)
		createMarker(m[1], m[2], m[3]-5.95, "cylinder", 5, 255, 255, 255)
		createMarker(m[4], m[5], m[6]-5.95, "cylinder", 5, 255, 255, 255)
	end
	for _, m in ipairs(odbieranie) do
		modbieranie = createMarker(m[1], m[2], m[3]-1, "cylinder", 1.35, 155, 255, 75, 50)
	end
end)

local oCuboid = createColCuboid(-2127.9675292969, 0.7691383361816, 34.3203125, 10.25, 7.5, 4)
local wCuboid = createColCuboid(-2127.9675292969, -9.7691383361816, 34.3203125, 10.25, 7.5, 4)

addEventHandler("onVehicleExit", resourceRoot, function(g, s)
	if s ~= 0 then return end
	if isElementWithinColShape(g, oCuboid) then
		local wyk = exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(source, "id"))
		if wyk then
			outputChatBox("Pojazd został zaparkowany na parkingu.", g, 255, 255, 255)
			zapiszPojazdy(source)
			destroyElement(source)
		else
			outputChatBox("Blad przechowalni zglos sie do Administratora.", g, 255, 255, 255)
		end
	end
end)

addEventHandler("onColShapeHit", oCuboid, function(hit)
	if getElementType(hit) ~= "player" then return end
	if not getPedOccupiedVehicle(hit) then return end
	exports["skyrpg_gui"]:addNotification(hit, "Witaj, znajdujesz się w przechowalni pojazdów, aby schować pojazdu musisz z niego wyjść.", 'info')
end)

function sprawdzPrzechowalnie(gracz)
	if getElementData(gracz, "organizacja") then
		return exports.skyrpg_db:query("SELECT * FROM pojazdy WHERE (wlasciciel=? OR organizacja=?) AND przechowalnia=1", getElementData(gracz, "dbid"), getElementData(gracz, "organizacja"))
	else
		return exports.skyrpg_db:query("SELECT * FROM pojazdy WHERE wlasciciel=? AND przechowalnia=1", getElementData(gracz, "dbid"))
	end
end

addEventHandler("onMarkerHit", resourceRoot, function(hit)
	if source == modbieranie then
	if getElementType(hit) ~= "player" then return end
	local spr = sprawdzPrzechowalnie(hit)
		if #spr < 1 then
			outputChatBox("Nie posiadasz pojazdow w przechowalni.", hit, 255, 0, 0)
			return
		end
		triggerClientEvent(hit, "pojazdy", hit, spr)
	end
end)

addEventHandler("onMarkerLeave", resourceRoot, function(hit)
	if source == modbieranie then
	if getElementType(hit) ~= "player" then return end
		triggerClientEvent(hit, "oknoPrzecho", hit)
	end
end)

addEvent("wyjmij", true)
addEventHandler("wyjmij", root, function(gracz, id)
	local vehicles = getElementsWithinColShape(wCuboid, "vehicle")
	for _, veh in ipairs(vehicles) do  
		if not getVehicleController(veh) then
			if getElementData(veh, "id") then
				exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(veh, "id"))
			end
			destroyElement(veh)
		end
	end
	if #getElementsWithinColShape(wCuboid, "vehicle") > 0 then 
		exports["skyrpg_gui"]:addNotification(gracz, "Wyjazd z parkingu jest zastawiony, spróbuj później.", 'error')
		return
	end
 	local sprx = exports.skyrpg_db:query("SELECT * FROM prawka WHERE serial=?", getPlayerSerial(gracz))
	if #sprx > 0 then
		exports["skyrpg_gui"]:addNotification(gracz, "Posiadasz zawieszone prawo jazdy kat. A,B,C do "..sprx[1].data.." zabrane przez "..sprx[1].admin, 'error')
		return
	end
	if getElementData(gracz, "prawko_b") ~= 1 then
		exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy.", 'error')
		return
	end
	local spr = exports.skyrpg_db:query("SELECT * FROM pojazdy WHERE id=?", id)
	local model = spr[1].model
	local mojpojazd = createVehicle(model, -2121.71, -5.18, 35.00, 360.0, 0.0, 269.6)
	local kolor = split(spr[1].kolor, ",")
	setVehicleColor(mojpojazd, kolor[1], kolor[2], kolor[3], kolor[4], kolor[5], kolor[6])
	if (spr[1].panelstates~="0,0,0,0,0,0,0") then
    	spr[1].panelstates=split(spr[1].panelstates,",")
		for i,v in ipairs(spr[1].panelstates) do
		  setVehiclePanelState(mojpojazd,i-1, tonumber(v))
		end
	else
    	spr[1].panelstates=split(spr[1].panelstates,",")
	end
	setElementHealth(mojpojazd, spr[1].zdrowie)
	setElementData(mojpojazd, "wlasciciel", spr[1].wlasciciel)
	setElementData(mojpojazd, "id", spr[1].id)
	setElementData(mojpojazd, "przebieg", spr[1].przebieg)
	setElementData(mojpojazd, "paliwo", spr[1].paliwo)
	 if spr[1].rejestracja:len() > 1 then
		 setVehiclePlateText(mojpojazd, spr[1].rejestracja)
	 else
	 	 setVehiclePlateText(mojpojazd, "SR "..id)
 	 end
	setElementData(mojpojazd, "bak", spr[1].bak)
	if spr[1].zawieszenie == 1 then
		setElementData(mojpojazd, "zawieszenie", 2)
	else
		setElementData(mojpojazd, "zawieszenie", false)
	end
	local tuning = split(spr[1].tuning, ",")
	for i=1,#tuning do
		addVehicleUpgrade(mojpojazd, tuning[i])
	end
	warpPedIntoVehicle(gracz, mojpojazd)
     if spr[1].organizacja:len() > 2 then
		setElementData(mojpojazd, "organizacja", spr[1].organizacja)
	else
	 	setElementData(mojpojazd, "organizacja", false)
  	end
	if spr[1].naped:len() > 1 then
		setVehicleHandling(mojpojazd, "driveType", spr[1].naped)
	end

	if spr[1].intercooler == 1 then
		local handling = getVehicleHandling(mojpojazd)
		setVehicleHandling(mojpojazd, "engineAcceleration", handling.engineAcceleration+0.75)
		setVehicleHandling(mojpojazd, "engineInertia", handling.engineInertia-8)
	end
	if spr[1].filtr == 1 then
		local handling = getVehicleHandling(mojpojazd)
		setVehicleHandling(mojpojazd, "engineInertia", handling.engineInertia-11)
		setVehicleHandling(mojpojazd, "engineAcceleration", handling.engineAcceleration+1.25)
	end
	if spr[1].sturbo == 1 then
		local handling = getVehicleHandling(mojpojazd)
		setVehicleHandling(mojpojazd, "maxVelocity", handling.maxVelocity+15)
		setVehicleHandling(mojpojazd, "engineAcceleration", handling.engineAcceleration+2)
	end
	if spr[1].duklad == 1 then
		local handling = getVehicleHandling(mojpojazd)
		setVehicleHandling(mojpojazd, "maxVelocity", handling.maxVelocity+8)
		setVehicleHandling(mojpojazd, "engineAcceleration", handling.engineAcceleration+1.2)
	end

 	local licznik = split(spr[1].licznik, ",")
	if spr[1].licznik ~= "" then
		setElementData(mojpojazd, "lrgb", {
		["r"] = licznik[1],
		["g"] = licznik[2],
		["b"] = licznik[3],
		})
	end
	setElementData(mojpojazd, "przecho", true)
	if spr[1].swiatla:len() > 1 then
		local swiatla = split(spr[1].swiatla, ",")
		setVehicleHeadLightColor(mojpojazd, swiatla[1], swiatla[2], swiatla[3])
	end
	exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=0 WHERE id=?", id)
end)

setTimer(function()
for _, vehicle in pairs(getElementsByType("vehicle")) do
if getElementHealth(vehicle) < 300 then
setVehicleDamageProof(vehicle, true)
elseif getElementHealth(vehicle) > 301 then
if getVehicleController (vehicle) then
setVehicleDamageProof(vehicle, false)
end
end
end
end, 500, 0)

setTimer(function()
for _, vehicle in pairs(getElementsByType("vehicle")) do
if not getVehicleController(vehicle) then
setVehicleDamageProof(vehicle, true)
end
end
end, 500, 0)

local pojazd = false
local shape = {}

local pojazdy = {
-- id, x,y, z, cena, salon
-- auta
-- salon
{507, -1954.26, 303.48, 35.29, 359.8, 0.0, 163.0, 12375, "salon", 3},
{585, -1961.45, 304.27, 35.06, 359.6, 0.0, 180.8, 9900, "salon", 3},
{445, -1946.14, 273.00, 35.35, 360.0, 0.0, 87.5, 13200, "salon", 3},
{518, -1945.97, 257.18, 35.14, 360.0, 359.9, 44.4, 11550, "salon", 3},
{542, -1960.85, 257.79, 35.22, 0.0, 360.0, 2.6, 9900, "salon", 3},
{458, -1946.16, 265.46, 35.25, 360.0, 0.0, 89.2, 9900, "salon", 3},
{527, -1953.53, 257.52, 35.19, 360.0, 359.8, 359.4, 11550, "salon", 3},
{517, -1946.03, 265.40, 40.90, 360.0, 359.8, 92.5, 14850, "salon", 3},
{589, -1945.91, 273.31, 40.71, 0.1, 0.1, 88.2, 11550, "salon", 3},
{551, -1945.91, 257.74, 40.85, 360.0, 0.0, 46.1, 13200, "salon", 3},
{426, -1953.96, 258.05, 40.79, 0.0, 360.0, 3.3, 16500, "salon", 3},
-- motory
--[[{468, -1952.49, 291.26, 40.72, 359.9, 360.0, 84.2, 1000, "salon", 1.5},
{521, -1956.37, 306.22, 40.62, 359.2, 360.0, 164.1, 1000, "salon", 1.5},
{461, -1952.64, 304.74, 40.63, 358.8, 360.0, 119.6, 1000, "salon", 1.5},
{581, -1952.55, 300.43, 40.64, 359.4, 0.0, 86.3, 1000, "salon", 1.5},
{463, -1952.62, 295.70, 40.59, 0.1, 0.0, 86.4, 1000, "salon", 1.5},]]
-- cygan
{418, -911.04, -515.90, 26.05, 0.1, 359.8, 46.8, 2475, "cygan", 3},
{404, -931.37, -538.83, 25.68, 359.7, 359.9, 326.2, 3300, "cygan", 3},
{478, -960.06, -518.21, 25.95, 359.2, 0.0, 280.8, 4125, "cygan", 3},
{410, -932.07, -494.00, 25.62, 359.4, 0.0, 187.9, 4125, "cygan", 3},
{436, -932.89, -512.40, 25.73, 359.5, 359.9, 29.6, 4950, "cygan", 3},
}

addEventHandler("onResourceStart", resourceRoot, function()
 for _, v in ipairs(pojazdy) do
	 pojazd = createVehicle(v[1], v[2], v[3], v[4], v[5], v[6], v[7])
	 local cena = string.format("%1.2f$", v[8])
	 local cenap = string.format("%1.2f", v[8])
	 local model = getModelHandling(tonumber(v[1]))
	 local naped = model["driveType"]
	 if naped == "rwd" then naped = "RWD" elseif naped == "fwd" then naped = "FWD" elseif naped == "awd" then naped = "AWD" end
	 setElementData(pojazd, "nametag", "Model: "..getVehicleName(pojazd).."\nCena: "..cena.."\nNapęd: "..naped.."\nAby zakupić pojazd, wejdź do auta a później wpisz komendę /kuppojazd")
	 setElementFrozen(pojazd, true)
	 setVehicleDamageProof(pojazd, true)
	 setElementData(pojazd, "salon", v[9])
	 if v[9] == "salon" then
	 	setElementData(pojazd, "obracanie", true)
	 end
	 shape[_] = createColSphere(v[2], v[3], v[4], v[10])
	 setElementData(shape[_], "i", _)
	 setElementData(shape[_], "salon", pojazd)
	 setElementData(shape[_], "cena", cenap)
	 setElementData(shape[_], "size", v[10])

	 addEventHandler("onColShapeHit", shape[_], function(gracz)
		 if getElementType(gracz) ~= "player" then return end
		 exports["skyrpg_gui"]:addNotification(gracz, "Aby zakupić ten pojazd, wejdź najpierw do pojazdu a następnie wpisz komendę /kuppojazd", 'error')
	 end)

 end
end)

addCommandHandler("kuppojazd", function(gracz)
 local shape = cuboid(gracz)
 if not shape then return end
 local veh = getElementData(shape, "salon")
 if not veh then return end
 if getElementData(shape, "size") == 3 and getElementData(gracz, "prawko_b") ~= 1 then
 	exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy kategorii B.", 'error')
 	return
 end
 if getElementData(shape, "size") == 1.5 and getElementData(gracz, "prawko_a") ~= 1 then
 	exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy kategorii A.", 'error')
 	return
 end
 local cenap = getElementData(shape, "cena")
 local hajs = getElementData(gracz, "dolary")
 cenap = tonumber(cenap)
 if hajs < cenap then
 	 exports["skyrpg_gui"]:addNotification(gracz, "Brak funduszy na zakup tego pojazdu.", 'error')
 else
 	if getElementData(gracz, "prawko_b") ~= 1 then
		exports["skyrpg_gui"]:addNotification(gracz, "Nie posiadasz prawa jazdy.", 'error')
		return
	end
 	local spr = exports.skyrpg_db:query("SELECT * FROM prawka WHERE serial=?", getPlayerSerial(gracz))
	if #spr > 0 then
		exports["skyrpg_gui"]:addNotification(gracz, "Posiadasz zawieszone prawo jazdy kat. A, B, C do "..spr[1].data.." zabrane przez "..spr[1].admin, 'error')
		return
	end
	 local model = getVehicleModel(veh)
	 local dbid = getElementData(gracz, "dbid")
	 local k = getElementData(veh, "salon")
	 if k == "salon" then
		 x, y, z, r, z, yx = -1970.59, 305.56, 34.91, 0.0, 360.0, 85.2
	 elseif k == "cygan" then
		 x, y, z, r, z, yx = -922.65, -516.90, 25.73, 359.6, 360.0, 340.8
	 end
	 local pozycja = x..", "..y..", "..z..", "..r..", "..z..", "..yx
	 local wyk, _, id = exports.skyrpg_db:query("INSERT INTO pojazdy SET model=?, wlasciciel=?, pozycja=?, paliwo=50, bak=50, przebieg=0", model, dbid, pozycja)
	 local mojpojazd = createVehicle(model, x, y, z, r, z, yx)
	 setElementData(mojpojazd, "wlasciciel", dbid)
	 setElementData(mojpojazd, "id", tonumber(id))
	 setElementData(mojpojazd, "paliwo", 50)
	 setElementData(mojpojazd, "bak", 50)
	 setElementData(mojpojazd, "przebieg", 0)
	 setVehiclePlateText(mojpojazd, "SR "..id)
	 warpPedIntoVehicle(gracz, mojpojazd)
	 setElementData(gracz, "dolary", hajs-cenap)
	 exports["skyrpg_gui"]:addNotification(gracz, "Zakupiłeś swój pojazd "..getVehicleName(veh).." za cene "..cenap.."$", 'success')
	 if not wyk then
		 destroyElement(mojpojazd)
	 end
 end
end)

function cuboid(gracz)
 for _, v in ipairs(shape) do
	 if isElementWithinColShape(gracz, v) then return v end
 end
 return false
end

local marker = createMarker(-1980.31, 301.25, 35.17-1, "cylinder", 2, 0, 255, 0, 75)

addEventHandler("onMarkerHit", marker, function(hit)
	if getElementType(hit) ~= "player" then return end
	if isPedInVehicle(hit) then return end
	if getPlayerName(hit) ~= "Gutek" then return end
	triggerClientEvent(hit, "ogKomis", root, "p")
end)

addEventHandler("onMarkerLeave", marker, function(hit)
	if getElementType(hit) ~= "player" then return end
	if isPedInVehicle(hit) then return end
	if getPlayerName(hit) ~= "Gutek" then return end
	triggerClientEvent(hit, "ogKomis", root, "s")
end)

addEvent("kpStworz", true)
addEventHandler("kpStworz", root, function(l, i)
	 local x, y, z, r, y, yx = -2330.66, 36.37, 34.78, 360.0, 0.0, 180.0
	 local pozycja = x..", "..y..", "..z..", "..r..", "..z..", "..yx
	 local przebieg = math.random(0,10000)
	 local dbid = getElementData(l, "dbid")
	 local wyk, _, id = exports.skyrpg_db:query("INSERT INTO pojazdy SET model=?, wlasciciel=?, pozycja=?, paliwo=25, bak=25, przebieg=?", i, dbid, pozycja, przebieg)
	 local mojpojazd = createVehicle(i, x, y, z, r, z, yx)
	  exports["skyrpg_gui"]:addNotification(l, "Zakupiłeś pojazd, został on zrespiony przed komisem.", 'success')
	 setElementData(mojpojazd, "wlasciciel", dbid)
	 setElementData(mojpojazd, "id", tonumber(id))
	 setElementData(mojpojazd, "paliwo", 25)
	 setElementData(mojpojazd, "bak", 25)
	 setElementData(mojpojazd, "przebieg", przebieg)
	 setVehiclePlateText(mojpojazd, "SR "..id)
end)