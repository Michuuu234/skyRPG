--[[
  Autor: Asper
  Dla: .newMode
  Skrypt: przechowalnia
]]

addEventHandler("onClientRender", root, function()
  for i,v in ipairs(getElementsByType("vehicle")) do
    if getElementData(v, "obracanie") then
      local rx, ry, rz = getVehicleRotation(v)
      setElementRotation(v, 0, 0, rz+1)
    end
  end
end)

--

local screenW, screenH = guiGetScreenSize()
local sx, sy = guiGetScreenSize()

function mysz(psx,psy,pssx,pssy,abx,aby)
    if not isCursorShowing() then return end
    cx,cy=getCursorPosition()
    cx,cy=cx*sx,cy*sy
    if cx >= psx and cx <= psx+pssx and cy >= psy and cy <= psy+pssy then
        return true,cx,cy
    else
        return false
    end
end

local wybieralka = guiCreateComboBox(0.37, 0.25, 0.26, 0.33, "Wybierz pojazd", true)

local f = dxCreateFont( ":skyrpg_gui/hud/fonts/normal.ttf", 10 )
local logo = dxCreateFont( ":skyrpg_gui/hud/fonts/bold.ttf", 14 )
if not f then f = "default-bold" end
if not logo then logo = "default-bold" end

function gui()
  exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.3551, screenH * 0.1758, screenW * 0.2899, screenH * 0.6484, tocolor(150, 150, 150, 255))
  --dxDrawRectangle(screenW * 0.3551, screenH * 0.1758, screenW * 0.2899, screenH * 0.0612, tocolor(25, 75, 125, 155), false)
  dxDrawImage(screenW * 0.3551, screenH * 0.1758, screenW * 0.2899, screenH * 0.0612, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
  dxDrawText("Odbiór pojazdów", (screenW * 0.3551) + 1, (screenH * 0.1758) + 1, (screenW * 0.6442) + 1, (screenH * 0.2370) + 1, tocolor(0, 0, 0, 255), 1.00, logo, "center", "center", false, false, false, false, false)
  dxDrawText("Odbiór pojazdów", screenW * 0.3551, screenH * 0.1758, screenW * 0.6442, screenH * 0.2370, tocolor(255, 255, 255, 255), 1.00, logo, "center", "center", false, false, false, false, false)
    --dxDrawRectangle(screenW * 0.3799, screenH * 0.6510, screenW * 0.2416, screenH * 0.0638, tocolor(25, 75, 125, 125), false)
	dxDrawImage(screenW * 0.3799, screenH * 0.6510, screenW * 0.2416, screenH * 0.0638, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
	dxDrawImage(screenW * 0.3799, screenH * 0.7279, screenW * 0.2416, screenH * 0.0638, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
  dxDrawText("Odbierz pojazd", (screenW * 0.3799) + 1, (screenH * 0.6510) + 1, (screenW * 0.6215) + 1, (screenH * 0.7148) + 1, tocolor(0, 0, 0, 255), 1.00, f, "center", "center", false, false, false, false, false)
  dxDrawText("Odbierz pojazd", screenW * 0.3799, screenH * 0.6510, screenW * 0.6215, screenH * 0.7148, tocolor(255, 255, 255, 255), 1.00, f, "center", "center", false, false, false, false, false)
  dxDrawText("Zamknij panel", (screenW * 0.3799) + 1, (screenH * 0.7279) + 1, (screenW * 0.6215) + 1, (screenH * 0.7917) + 1, tocolor(0, 0, 0, 255), 1.00, f, "center", "center", false, false, false, false, false)
  dxDrawText("Zamknij panel", screenW * 0.3799, screenH * 0.7279, screenW * 0.6215, screenH * 0.7917, tocolor(255, 255, 255, 255), 1.00, f, "center", "center", false, false, false, false, false)
end

guiSetVisible(wybieralka, false)

addEvent("pojazdy", true)
addEventHandler("pojazdy", root, function(spr)
  if guiGetVisible(wybieralka) == true then
    removeEventHandler("onClientRender", root, gui)
    showCursor(false)
    panel = false
    guiSetVisible(wybieralka, false)
  else
    guiSetVisible(wybieralka, true)
    showCursor(true, false)
    addEventHandler("onClientRender", root, gui)
    guiComboBoxClear(wybieralka)
    for i, v in pairs(spr) do
    local info = v["id"].." "..getVehicleNameFromModel(v["model"])
    if v["organizacja"]:len() > 2 and v["wlasciciel"] ~= getElementData(localPlayer, "dbid") then
      info = v["id"].." "..getVehicleNameFromModel(v["model"]).." - Pojazd organizacji "..v["organizacja"]
    end
    guiComboBoxAddItem(wybieralka, info)
  end
  end
end)

addEventHandler("onClientClick", root, function(b, s)
  if b ~= "state" and s ~= "down" then return end
  if mysz(screenW * 0.3799, screenH * 0.6510, screenW * 0.2416, screenH * 0.0638) and guiGetVisible(wybieralka) == true then
    local i = guiComboBoxGetSelected(wybieralka)
    if not i then return end
    local id = guiComboBoxGetItemText(wybieralka, i)
    id = string.gsub(id, "%a", "")
    triggerServerEvent("wyjmij", resourceRoot, localPlayer, id)
    guiSetVisible(wybieralka, false)
    showCursor(false)
    removeEventHandler("onClientRender", root, gui)
  elseif mysz(screenW * 0.3799, screenH * 0.7279, screenW * 0.2416, screenH * 0.0638) and guiGetVisible(wybieralka) == true then
    guiSetVisible(wybieralka, false)
    showCursor(false)
    removeEventHandler("onClientRender", root, gui)
  end
end)

addEvent("oknoPrzecho", true)
addEventHandler("oknoPrzecho", root, function(hit)
  removeEventHandler("onClientRender", root, gui)
  showCursor(false)
  guiSetVisible(wybieralka, false)
end)

--[[
Komis pojazdów
Autor: Asper
]]

local klista = guiCreateGridList(0.375, 0.248, 0.25, 0.48, true)   
guiGridListAddColumn(klista, "ID", 0.2)
guiGridListAddColumn(klista, "Model", 0.3)
guiGridListAddColumn(klista, "Cena", 0.3)
guiSetVisible(klista, false) 

local pojazdy = {
{411, "Infernus", 1000000},
}

function guik()
        dxDrawRectangle(screenW * 0.3675, screenH * 0.1849, screenW * 0.2650, screenH * 0.7083, tocolor(3, 0, 0, 102), false)
        dxDrawRectangle(screenW * 0.3675, screenH * 0.1836, screenW * 0.2650, screenH * 0.0560, tocolor(255, 255, 255, 255), false)
        dxDrawText("Komis pojazdów", (screenW * 0.3675) + 1, (screenH * 0.1823) + 1, (screenW * 0.6325) + 1, (screenH * 0.2396) + 1, tocolor(0, 0, 0, 255), 1.00, "default", "center", "center", false, false, false, false, false)
        dxDrawText("Komis pojazdów", screenW * 0.3675, screenH * 0.1823, screenW * 0.6325, screenH * 0.2396, tocolor(255, 255, 255, 255), 1.00, "default", "center", "center", false, false, false, false, false)
        dxDrawRectangle(screenW * 0.3975, screenH * 0.7318, screenW * 0.1984, screenH * 0.0703, tocolor(255, 255, 255, 255), false)
        dxDrawText("Zakup pojazd", (screenW * 0.3975) + 1, (screenH * 0.7305) + 1, (screenW * 0.5952) + 1, (screenH * 0.8021) + 1, tocolor(0, 0, 0, 255), 1.00, "default", "center", "center", false, false, false, false, false)
        dxDrawText("Zakup pojazd", screenW * 0.3975, screenH * 0.7305, screenW * 0.5952, screenH * 0.8021, tocolor(255, 255, 255, 255), 1.00, "default", "center", "center", false, false, false, false, false)
        dxDrawRectangle(screenW * 0.3975, screenH * 0.8151, screenW * 0.1984, screenH * 0.0703, tocolor(255, 255, 255, 255), false)
        dxDrawText("Anuluj kupno", (screenW * 0.3975) + 1, (screenH * 0.8151) + 1, (screenW * 0.5952) + 1, (screenH * 0.8867) + 1, tocolor(0, 0, 0, 255), 1.00, "default", "center", "center", false, false, false, false, false)
        dxDrawText("Anuluj kupno", screenW * 0.3975, screenH * 0.8151, screenW * 0.5952, screenH * 0.8867, tocolor(255, 255, 255, 255), 1.00, "default", "center", "center", false, false, false, false, false)
end

addEvent("ogKomis", true)
addEventHandler("ogKomis", root, function(c)
	if c == "p" then
		guiSetVisible(klista, true)
		showCursor(true)
		addEventHandler("onClientPreRender", root, guik)
	elseif c == "s" then
		showCursor(false)
		guiSetVisible(klista, false)
		removeEventHandler("onClientPreRender", root, guik)
	end
end)

addEventHandler("onClientClick", root, function(b, s)
  if b ~= "state" and s ~= "down" then return end
  if guiGetVisible(klista) ~= true then return end
  if mysz(screenW * 0.3975, screenH * 0.8151, screenW * 0.1984, screenH * 0.0703) then
		showCursor(false)
		guiSetVisible(klista, false)
		removeEventHandler("onClientPreRender", root, guik)
	elseif mysz(screenW * 0.3975, screenH * 0.7318, screenW * 0.1984, screenH * 0.0703) then
		local wybral = guiGridListGetSelectedItem(klista) or 0
		local id = guiGridListGetItemText(klista, wybral, 1)
		local nazwa = guiGridListGetItemText(klista, wybral, 2)
		local cena = guiGridListGetItemText(klista, wybral, 3)
		local hajs = getElementData(localPlayer, "pieniadze")
		if wybral < 0 then return end
		cena = tonumber(cena)
		if cena > hajs then
			exports["nm-noti"]:noti("Brak wystarczających funduszy.")
			return
		end
		showCursor(false)
		guiSetVisible(klista, false)
		removeEventHandler("onClientPreRender", root, guik)
		exports["nm-noti"]:noti("Zakupiłeś pojazd "..nazwa.." od id modelu "..id.." za cene "..cena.." PLN.")
		setElementData(localPlayer, "pieniadze", hajs-cena)
		triggerServerEvent("kpStworz", resourceRoot, localPlayer, id)
	end
end)

addEventHandler("onClientResourceStart", resourceRoot, function()
	for k,v in ipairs(pojazdy) do
		local r = guiGridListAddRow(klista)
		guiGridListSetItemText(klista, r, 1, v[1], false, false)
		guiGridListSetItemText(klista, r, 2, v[2], false, false)
		local cx = v[3]
		cx = string.format("%1.2f", cx)
		guiGridListSetItemText(klista, r, 3, cx, false, false)
	end
end)