local napis = createElement("text")
setElementData(napis, "text", "(( Punkt spawnu, nie zastawiać ))")
setElementPosition(napis, -2038.45, 489.49, 35.17)

local cuboid = createColCuboid(-2040.7486572266, 486.69851074219, 34.172294616699, 4.25, 6, 3)

addEvent("zdalEgzamin", true)
addEventHandler("zdalEgzamin", root, function(p)
	exports.skyrpg_gui:addNotification(p, "Gratulacje, właśnie zdałeś egzamin! :)", 'success')
	zEgz(p)
	local pojazd = getPedOccupiedVehicle(p)
	destroyElement(pojazd)
	setElementData(p, "pegz", false)
	setTimer(function()
		setElementPosition(p, -2022.78, 457.23, 161.55)
		setElementDimension(p, 1)
	end, 50, 1)
end)

local pegz = false

addEvent("rozpocznijKurs", true)
addEventHandler("rozpocznijKurs", root, function(p, c)
	local vehicles = getElementsWithinColShape(cuboid, "vehicle")
	for _, veh in ipairs(vehicles) do  
		if not getVehicleController(veh) then
			if getElementData(veh, "id") then
				exports.skyrpg_db:query("UPDATE pojazdy SET przechowalnia=1 WHERE id=?", getElementData(veh, "id"))
			end
			destroyElement(veh)
		end
	end
	if #getElementsWithinColShape(cuboid, "vehicle") > 0 then 
		--exports["nm-noti"]:noti("Spawn pojazdu prawa jazdy jest zastawiony, spróbuj później.", p)
		exports.skyrpg_gui:addNotification(p, "Spawn pojazdu dla prawa jazdy jest aktualnie zastawiony, spróbuj później.", 'error')
		return
	end
	if c == "Kategoria A" then
		if getElementData(p, "prawko_a") == 1 then exports.skyrpg_gui:addNotification(p, "Masz już zdane prawo jazdy kategorii A.", 'error') return end
		pegz = createVehicle(586, -2039.26, 489.40, 34.85, 360.0, 0.0, 358.6)
		setElementData(pegz, "nametag", "Prawo jazdy kategoria A")
		setVehicleHandling(pegz, "maxVelocity", 75)
		setElementData(p, "pegz", pegz)
		setVehicleColor(pegz, 255, 255, 255)
		warpPedIntoVehicle(p, pegz)
		setElementData(p, "prawko", "A")
		setElementDimension(p, 0)
		setElementDimension(pegz, 0)
		setElementData(p, "zdaje", 300)
	elseif c == "Kategoria B" then
		if getElementData(p, "prawko_b") == 1 then exports.skyrpg_gui:addNotification(p, "Masz już zdane prawo jazdy kategorii B.", 'error') return end
		pegz = createVehicle(589, -2039.26, 489.40, 34.85, 360.0, 0.0, 358.6)
		setElementData(pegz, "nametag", "Prawo jazdy kategoria B")
		setElementData(p, "pegz", pegz)
		setVehicleColor(pegz, 255, 255, 255)
		warpPedIntoVehicle(p, pegz)
		setElementData(p, "prawko", "B")
		setVehicleHandling(pegz, "maxVelocity", 75)
		setElementDimension(pegz, 0)
		setElementData(p, "zdaje", 300)
		setElementDimension(p, 0)
	elseif c == "Kategoria C" then
		if getElementData(p, "prawko_c") == 1 then exports.skyrpg_gui:addNotification(p, "Masz już zdane prawo jazdy kategorii C.", 'error') return end
		pegz = createVehicle(440, -2039.26, 489.40, 34.85, 360.0, 0.0, 358.6)
		setElementData(pegz, "nametag", "Prawo jazdy kategoria C")
		setElementData(p, "pegz", pegz)
		setVehicleColor(pegz, 255, 255, 255)
		warpPedIntoVehicle(p, pegz)
		setElementData(p, "prawko", "C")
		setElementData(p, "zdaje", 300)
		setElementDimension(pegz, 0)
		setElementDimension(p, 0)
		setVehicleHandling(pegz, "maxVelocity", 75)
	end
end)

function zEgz(p)
	local c = getElementData(p, "prawko")
	if not c then return end
	if c == "A" then co = "a"
	elseif c == "B" then co = "b"
	elseif c == "C" then co = "c"
	end
	setElementData(p, "prawko_"..co, 1)
	exports.skyrpg_db:query("UPDATE konta SET prawko_"..co.."=1 WHERE dbid=?", getElementData(p, "dbid"))
end

addEvent("zakaczylEgzamin", true)
addEventHandler("zakaczylEgzamin", root, function()
	local pa = getElementData(source, "pegz")
	if pa then
		destroyElement(pa)
		setElementData(source, "pegz", false)
	end
end)

addEventHandler("onVehicleExit", resourceRoot, function(g, s) 
		if s ~= 0 then return end 
		destroyElement(source) 
		setElementData(g, "zdaje", false)
		exports.skyrpg_gui:addNotification(g, "Opuściłeś pojazd, nie zdajesz egzaminu!", 'error')
		setElementData(g, "pegz", false)
		setTimer(function()
			setElementPosition(g, -2022.78, 457.23, 161.55)
			setElementDimension(g, 1)
		end, 1000, 1)
end)

addEventHandler("onPlayerQuit", root, function()
	local pa = getElementData(source, "pegz") 
	if pa and isElement(pa) then 
		destroyElement(pa) 
	end 
end)

addEventHandler("onVehicleDamage", resourceRoot, function()
	local gracz = getVehicleController(source)
	if not gracz then return end
	destroyElement(source)
	exports.skyrpg_gui:addNotification(gracz, "Uszkodziłeś pojazd, nie zdajesz egzaminu!", 'error')
	setElementData(gracz, "zdaje", false)
	setElementData(gracz, "pegz", false)
		setTimer(function()
			setElementPosition(gracz, -2022.78, 457.23, 161.55)
			setElementDimension(gracz, 1)
		end, 1000, 1)
end)

local marker = createMarker(-2033.50, 466.22, 161.55-1, "cylinder", 1.5, 150, 150, 150, 75)
setElementDimension(marker, 1)

addEventHandler("onMarkerHit", marker, function(hit)
	triggerClientEvent(hit, "oknoEgz", root)
end)

addEventHandler("onMarkerLeave", marker, function(hit)
	triggerClientEvent(hit, "oknoEgzC", root)
end)
