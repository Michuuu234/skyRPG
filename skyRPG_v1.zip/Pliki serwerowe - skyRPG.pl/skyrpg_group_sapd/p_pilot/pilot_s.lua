﻿local brama = createObject(969 ,-1632.1999511719,688.29998779297,6.3000001907349 ,0 ,0 ,0)
local brama2 = createObject(969 ,-1639.6811523438,688.66552734375,6.3000001907349 ,0 ,0 ,0)
local drzwi = createObject(2930 ,-1621.9000244141 ,692.79998779297,7.1875 ,0 ,0, 0)


function start(player)
	local accName = getAccountName ( getPlayerAccount ( player ) )      
	if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then  
	 triggerClientEvent(player, "StartPGui", root)
	end
end
addCommandHandler("pilot", start)

addEvent("brama",true)
addEventHandler("brama",root,
	function()
			local accName = getAccountName ( getPlayerAccount ( source ) )
			local x,y,z = getElementPosition(source)			
		if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then  
			local data = getElementData(brama,"otwarta") or false
			if (getDistanceBetweenPoints3D(x,y,z,-1632.1999511719,688.29998779297,6.3000001907349)<100) then
				if data then
					moveObject(brama, 500, -1632.1999511719,688.29998779297,6.3000001907349)
					moveObject(brama2, 500, -1639.6811523438,688.66552734375,6.3000001907349)
					setElementData(brama,"otwarta", false)
					exports["skyrpg_gui"]:addNotification(source, "Zamknięto brame policyjną.", 'success')
				else
					moveObject(brama, 500, -1639.9000244141, 688.29998779297, 6.3000001907349)
					setElementData(brama,"otwarta", true)
					exports["skyrpg_gui"]:addNotification(source, "Otwarto brame policyjną.", 'success')
				end
			else
				--outputChatBox("● INFO: Brama jest za daleko od pilota.",source,255,0,0,true)
				exports["skyrpg_gui"]:addNotification(source, "Brama jest za daleko od pilota.", 'error')
			end
		else
			--outputChatBox("Nie znasz kodu",source)
			exports["skyrpg_gui"]:addNotification(source, "Nie posiadasz dostępu do pilota.", 'error')
		end
	end
)
 

addEvent("drzwi",true)
addEventHandler("drzwi",root,
	function()
		local accName = getAccountName ( getPlayerAccount ( source ) )      
		local x,y,z = getElementPosition(source)
		if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then  
			local data1 = getElementData(drzwi,"otwarte") or false
			if (getDistanceBetweenPoints3D(x,y,z,-1621.9000244141 ,692.79998779297,8.8000001907349)<100) then
				if data1 then
					moveObject(drzwi, 500, -1621.9000244141 ,692.79998779297,8.8000001907349 )
					setElementData(drzwi,"otwarte", false)
				else
					moveObject(drzwi, 500, -1621.9000244141, 691.29998779297,8.8000001907349)
					setElementData(drzwi,"otwarte", true)
				end
			else
				--outputChatBox("● INFO: Drzwi są za daleko od pilota.",source,255,0,0,true)
				exports["skyrpg_gui"]:addNotification(source, "Drzwi są za daleko od pilota.", 'error')
			end
		else
		outputChatBox("Nie znasz kodu",source)
		end
	end
)