mojeW,mojeH = 1680, 1050
sW,sH = guiGetScreenSize()
width, height = (sW/mojeW), (sH/mojeH)

GUIEditor = {
    button = {},
    window = {}
}
GUIEditor.window[1] = guiCreateWindow(633*width, 325*height, 338*width, 432*height, "Pilot policyjny", false)
guiWindowSetSizable(GUIEditor.window[1], false)

GUIEditor.button[1] = guiCreateButton(74*width, 276*height, 194*width, 79*height, "Drzwi", false, GUIEditor.window[1])
guiSetProperty(GUIEditor.button[1], "NormalTextColour", "FFAAAAAA")
GUIEditor.button[2] = guiCreateButton(74*width, 106*height, 194*width, 79*height, "Brama", false, GUIEditor.window[1])
guiSetProperty(GUIEditor.button[2], "NormalTextColour", "FFAAAAAA")
GUIEditor.button[3] = guiCreateButton(280*width, 25*height, 48*width, 47*height, "X", false, GUIEditor.window[1])
guiSetProperty(GUIEditor.button[3], "NormalTextColour", "FFAAAAAA")

guiSetVisible(GUIEditor.window[1], false)

addEvent("StartPGui", true)
addEventHandler("StartPGui",root,
	function()
		guiSetVisible(GUIEditor.window[1], true)
		showCursor(true)
	end
)


function zamknij()
	guiSetVisible(GUIEditor.window[1], false)
	showCursor(false)		
end
addEventHandler("onClientGUIClick",GUIEditor.button[3],zamknij,false)


function brama()
	triggerServerEvent("brama",localPlayer)
	guiSetVisible(GUIEditor.window[1], false)
	showCursor(false)	
end
addEventHandler("onClientGUIClick",GUIEditor.button[2], brama, false)


function drzwi()
	triggerServerEvent("drzwi",localPlayer)
	guiSetVisible(GUIEditor.window[1], false)
	showCursor(false)	
end
addEventHandler("onClientGUIClick",GUIEditor.button[1],drzwi,false)
