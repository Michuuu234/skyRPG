﻿function findPlayer(plr,cel)
	local target=nil
	if (tonumber(cel) ~= nil) then
		target=getElementByID("p"..cel)
	else -- podano fragment nicku
		for _,thePlayer in ipairs(getElementsByType("player")) do
			if string.find(string.gsub(getPlayerName(thePlayer):lower(),"#%x%x%x%x%x%x", ""), cel:lower(), 1, true) then
				if (target) then
					--outputChatBox("● INFO: Znaleziono wiecej niz jednego gracza o pasujacym nicku, podaj wiecej liter.", plr)
					exports["skyrpg_gui"]:addNotification(plr, "Znaleziono wiecej niz jednego gracza o pasujacym nicku, podaj wiecej liter.", 'error')
					return nil
				end
				target=thePlayer
			end
		end
	end
	return target
end


function okaz(player, cmd, target)
	local target = findPlayer(plr, target)
	local x2,y2,z2 = getElementPosition(target)
	local x,y,z = getElementPosition(player)
	local accName = getAccountName ( getPlayerAccount ( player ) )      
	if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then 	
		if (getDistanceBetweenPoints3D(x,y,z,x2,y2,z2)<20) then
		local gracz = getPlayerName(target)
		local graczz = getPlayerFromName(gracz)
		local nick = getPlayerName(player)
		local ac = getPlayerFromName(nick)
		local acc = getPlayerAccount(ac)
		local stopien = getAccountData(acc, "StopienPol")
		local data = getAccountData(acc, "dataPol") or "Brak"
		local nr = getAccountData(acc, "nrPol") or "Brak"
		triggerClientEvent(graczz, "startLeg", player, nick, stopien, data, nr )
		--outputChatBox("● INFO: Okazujesz legitymacje graczowi "..gracz..".",player, 255,0,0,true)
		--outputChatBox("● INFO: Funkcjonariusz "..nick.." okazuje ci legitymacje.",graczz, 255,0,0,true)
		exports["skyrpg_gui"]:addNotification(player, "Okazujesz legitymacje graczowi "..gracz..".", 'info')
		exports["skyrpg_gui"]:addNotification(graczz, "Funkcjonariusz "..nick.." okazuje ci legitymacje.", 'info')
		else
			--outputChatBox("● INFO: Jesteś za daleko aby okazac legitymacje.",player, 255,0,0,true)
			exports["skyrpg_gui"]:addNotification(player, "Jesteś za daleko aby okazac legitymacje.", 'info')
		end
	end
end
addCommandHandler("legitymacja", okaz)