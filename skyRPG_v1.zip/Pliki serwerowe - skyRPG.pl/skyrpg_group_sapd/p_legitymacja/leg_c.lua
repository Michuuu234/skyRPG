mojeW,mojeH = 1680, 1050
sW,sH = guiGetScreenSize()
width, height = (sW/mojeW), (sH/mojeH)

GUIEditors = {
    button = {},
    window = {},
    label = {},
	staticimage = {}
}
GUIEditors.window[1] = guiCreateWindow(666*width, 228*height, 387*width, 494*height, "Legitymacja Policyjna", false)
guiWindowSetSizable(GUIEditors.window[1], false)

GUIEditors.staticimage[1] = guiCreateStaticImage(140*width, 46*height, 490*width, 150*height, "img/policja.png", false, GUIEditors.window[1])
GUIEditors.staticimage[2] = guiCreateStaticImage(20*width, 56*height, 140*width, 140*height, "img/avatar.png", false, GUIEditors.window[1])
GUIEditors.staticimage[3] = guiCreateStaticImage(20*width, 435*height, 340*width, 50*height, "img/policja1.png", false, GUIEditors.window[1])
GUIEditors.label[9] = guiCreateLabel(50*width, 30*height, 339*width, 35*height, "Komenda miejska w San Fierro", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[9], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditors.label[9], "center")
GUIEditors.label[1] = guiCreateLabel(20*width, 204*height, 139*width, 35*height, "Nick:", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[1], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditors.label[1], "center")
GUIEditors.label[2] = guiCreateLabel(20*width, 285*height, 139*width, 35*height, "Stopień:", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[2], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditors.label[2], "center")
GUIEditors.label[3] = guiCreateLabel(20*width, 373*height, 139*width, 35*height, "Numer identyfikatora:", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[3], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditors.label[3], "center")
GUIEditors.button[1] = guiCreateButton(175*width, 385*height, 169*width, 49*height, "ZAMKNIJ", false, GUIEditors.window[1])
guiSetProperty(GUIEditors.button[1], "NormalTextColour", "FFAAAAAA")
GUIEditors.label[4] = guiCreateLabel(206*width, 189*height, 153*width, 25*height, "Ważna do:", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[4], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditors.label[4], "center")
GUIEditors.label[5] = guiCreateLabel(20*width, 239*height, 139*width, 25*height, "none nick", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[5], "default-bold-small")
guiLabelSetColor(GUIEditors.label[5], 253, 238, 1)
guiLabelSetVerticalAlign(GUIEditors.label[5], "center")
GUIEditors.label[6] = guiCreateLabel(20*width, 320*height, 232*width, 27*height, "none stopień", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[6], "default-bold-small")
guiLabelSetColor(GUIEditors.label[6], 253, 238, 1)
guiLabelSetVerticalAlign(GUIEditors.label[6], "center")
GUIEditors.label[7] = guiCreateLabel(20*width, 408*height, 139*width, 27*height, "none nr", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[7], "default-bold-small")
guiLabelSetColor(GUIEditors.label[7], 253, 238, 1)
guiLabelSetVerticalAlign(GUIEditors.label[7], "center")
GUIEditors.label[8] = guiCreateLabel(206*width, 214*height, 153*width, 35*height, "none data", false, GUIEditors.window[1])
guiSetFont(GUIEditors.label[8], "default-bold-small")
guiLabelSetColor(GUIEditors.label[8], 253, 238, 1)
guiLabelSetVerticalAlign(GUIEditors.label[8], "center")

guiSetVisible(GUIEditors.window[1], false)

addEvent("startLeg", true)
addEventHandler("startLeg", root, 
function(nick, stopien, data, nr)
	guiSetText(GUIEditors.label[5], nick)
	guiSetText(GUIEditors.label[6], stopien)
	guiSetText(GUIEditors.label[8], data)
	guiSetText(GUIEditors.label[7], nr)
	guiSetVisible(GUIEditors.window[1], true)
	showCursor(true)
end
)

function close()
	guiSetVisible(GUIEditors.window[1], false)
	showCursor(false)
end
addEventHandler("onClientGUIClick", GUIEditors.button[1], close, false)