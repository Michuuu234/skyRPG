﻿function start(player)
	local accName = getAccountName ( getPlayerAccount ( player ) )      
	if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then  
	local name = getPlayerName(player)
	local acc = getPlayerAccount ( player )
	local ranga = getAccountData(acc,"StopienPol") or "Brak"
	triggerClientEvent(player, "StartGPol",root, ranga, name)
	end
end
addCommandHandler("panel",start)

addEvent("SprGracza",true)
addEventHandler("SprGracza",root, 
	function(name)
		local g = getPlayerFromName(name)
		local acc = getPlayerAccount ( g )
		local pkt = getAccountData(acc,"PktKarne") or 0
		triggerClientEvent(source, "SprGracz",root, pkt)
	end
)

manda = {}
addEvent("WystawionyMandat",true)
addEventHandler("WystawionyMandat",root, 
	function(kwota, pkt, powod, name)
		local gracz = getPlayerFromName(name)
		manda[gracz] = {}
		manda[gracz] = {source}
		local gracze = getPlayerName(source)
		triggerClientEvent(gracz, "WysMan",root, kwota, pkt, powod, gracz, gracze)
	end
)

addEvent("odrzucOferte",true)
addEventHandler("odrzucOferte",root, 
	function(name, plr)
		local gracz = getPlayerName(name)
		local plr = manda[source][1]
		--outputChatBox("● INFO: Gracz "..gracz.." odrzuca mandat.", plr, 255,0,0,true)
		exports["skyrpg_gui"]:addNotification(plr, "Gracz "..gracz.." odrzuca mandat.", 'info')
		manda[source] = nil
	end
)

addEvent("przyjmijOferte",true)
addEventHandler("przyjmijOferte",root, 
	function(name, plr)
		local plr = manda[source][1]
		local gra = getPlayerName(name)
		local gracz = getPlayerFromName(gra)
		local data = getElementData(gracz, "kwotaM")
		local data1 = getElementData(gracz, "pktM")
		local hajs = getElementData(gracz, "dolary")
		local acc = getPlayerAccount ( gracz )
		local man = getAccountData(acc, "mandaty") or 0
		local pkt = getAccountData(acc, "PktKarne") or 0
		--outputChatBox("● INFO: Gracz "..gra.." przyjął mandat.",plr,255,0,0,true)
		exports["skyrpg_gui"]:addNotification(plr, "Gracz "..gra.." przyjął mandat. Otrzymałeś "..data.."$, za mandat.", 'info')
		setAccountData(acc, "PktKarne", pkt + tonumber(data1))
		--setElementData(gracz, "dolary", hajs-data)
		--setElementData(plr, "dolary", hajs+data)
		setAccountData(acc, "mandaty", man + tonumber(data))
		manda[source] = nil
	end
)