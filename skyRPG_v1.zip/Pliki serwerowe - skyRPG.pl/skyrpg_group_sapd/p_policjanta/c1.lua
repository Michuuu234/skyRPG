mojeW,mojeH = 1680, 1050
sW,sH = guiGetScreenSize()
width, height = (sW/mojeW), (sH/mojeH)


GUIEditore = {
    gridlist = {},
    window = {},
    button = {},
    label = {},
	edit = {}
}
GUIEditore.window[1] = guiCreateWindow(575*width, 279*height, 468*width, 421*height, "Panel Policjanta", false)
guiWindowSetSizable(GUIEditore.window[1], false)

GUIEditore.label[1] = guiCreateLabel(19*width, 47*height, 389*width, 30*height, "Policjant: none", false, GUIEditore.window[1])
guiSetFont(GUIEditore.label[1], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[1], "center")
GUIEditore.gridlist[1] = guiCreateGridList(19*width, 101*height, 229*width, 306*height, false, GUIEditore.window[1])
guiGridListAddColumn(GUIEditore.gridlist[1], "Gracze", 0.9)
GUIEditore.button[1] = guiCreateButton(313*width, 147*height, 145*width, 44*height, "Wypisz Mandat", false, GUIEditore.window[1])
guiSetProperty(GUIEditore.button[1], "NormalTextColour", "FFAAAAAA")
GUIEditore.button[2] = guiCreateButton(314*width, 219*height, 144*width, 44*height, "Ostrzeż", false, GUIEditore.window[1])
guiSetProperty(GUIEditore.button[2], "NormalTextColour", "FFAAAAAA")
guiSetEnabled ( GUIEditore.button[2], false ) 
GUIEditore.button[4] = guiCreateButton(415*width, 371*height, 43*width, 40*height, "X", false, GUIEditore.window[1])
guiSetProperty(GUIEditore.button[4], "NormalTextColour", "FFAAAAAA")

GUIEditore.window[2] = guiCreateWindow(570, 312, 510, 430, "Panel mandatu", false)
guiWindowSetSizable(GUIEditore.window[2], false)

GUIEditore.label[2] = guiCreateLabel(28, 42, 175, 43, "Gracz: none", false, GUIEditore.window[2])
guiSetFont(GUIEditore.label[2], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[2], "center")
GUIEditore.label[3] = guiCreateLabel(267, 42, 175, 43, "Punkty karne: none", false, GUIEditore.window[2])
guiSetFont(GUIEditore.label[3], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[3], "center")
GUIEditore.label[4] = guiCreateLabel(28, 112, 175, 43, "Powód:", false, GUIEditore.window[2])
guiSetFont(GUIEditore.label[4], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[4], "center")
GUIEditore.edit[1] = guiCreateEdit(27, 157, 220, 36, "", false, GUIEditore.window[2])
GUIEditore.label[5] = guiCreateLabel(267, 112, 175, 43, "Punkty karne:", false, GUIEditore.window[2])
guiSetFont(GUIEditore.label[5], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[5], "center")
GUIEditore.edit[2] = guiCreateEdit(267, 157, 220, 36, "", false, GUIEditore.window[2])
GUIEditore.label[6] = guiCreateLabel(154, 208, 175, 43, "Kwota mandatu:", false, GUIEditore.window[2])
guiSetFont(GUIEditore.label[6], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditore.label[6], "center")
GUIEditore.edit[3] = guiCreateEdit(154, 261, 220, 36, "", false, GUIEditore.window[2])
GUIEditore.button[5] = guiCreateButton(10, 372, 227, 48, "Wystaw mandat", false, GUIEditore.window[2])
guiSetProperty(GUIEditore.button[5], "NormalTextColour", "FFAAAAAA")
GUIEditore.button[6] = guiCreateButton(452, 376, 48, 44, "X", false, GUIEditore.window[2])
guiSetProperty(GUIEditore.button[6], "NormalTextColour", "FFAAAAAA")

guiSetVisible(GUIEditore.window[2], false)
guiSetVisible(GUIEditore.window[1], false)

addEvent("StartGPol",true)
addEventHandler("StartGPol",root,
	function(ranga, name)
		guiSetVisible(GUIEditore.window[1], true)
		showCursor(true)
		guiGridListClear( GUIEditore.gridlist[1] )
		guiSetText(GUIEditore.label[1], "Policjant: ["..ranga.."]"..name..".")
		for i,v in ipairs(getElementsByType("player")) do
			local row = guiGridListAddRow( GUIEditore.gridlist[1] )
			guiGridListSetItemText( GUIEditore.gridlist[1], row, 1, getPlayerName(v), false, false )
		end
	end
)

function OnMandat()
	local row = guiGridListGetSelectedItem( GUIEditore.gridlist[1] )
    if row ~= -1 then
    local name = guiGridListGetItemText( GUIEditore.gridlist[1], row, 1 )
	triggerServerEvent("SprGracza", localPlayer, name)
	setElementData(localPlayer,"nickO", name)
	guiSetText(GUIEditore.label[2],"Gracz: "..name)
	guiSetVisible(GUIEditore.window[1], false)
	guiSetVisible(GUIEditore.window[2], true)
	else
	--outputChatBox("#FF0036[#919191System#FF0036]#919191Wybierz gracza!",255,255,255,true)
	exports["skyrpg_gui"]:addNotification("Wybierz gracza!", 'error')
	end
end
addEventHandler("onClientGUIClick",GUIEditore.button[1], OnMandat, false)

addEvent("SprGracz",true)
addEventHandler("SprGracz",root, 
	function(pkt)
		guiSetText(GUIEditore.label[3],"Pkt karne: "..pkt)
	end
)

function ZamknijPol()
	guiSetVisible(GUIEditore.window[1], false)
	showCursor(false)
end
addEventHandler("onClientGUIClick",GUIEditore.button[4], ZamknijPol, false)

function ZamknijPol2()
	guiSetVisible(GUIEditore.window[2], false)
	showCursor(false)
end
addEventHandler("onClientGUIClick",GUIEditore.button[6], ZamknijPol2, false)

---

function createGUI()
	if not GUIEditorz then
	GUIEditorz = {
    button = {},
    window = {},
	staticimage = {},
    label = {}
	}
		GUIEditorz.window[1] = guiCreateWindow(555*width, 249*height, 547*width, 402*height, "Mandat", false)
		guiWindowSetSizable(GUIEditorz.window[1], false)

		GUIEditorz.staticimage[1] = guiCreateStaticImage(20*width, 283*height, 516*width, 53*height, ":mygame_police/img/policja1.png", false, GUIEditorz.window[1])
		GUIEditorz.staticimage[2] = guiCreateStaticImage(246*width, 19*height, 290*width, 239*height, ":mygame_police/img/policja.png", false, GUIEditorz.window[1])
		GUIEditorz.label[1] = guiCreateLabel(15*width, 39*height, 307*width, 38*height, "Policjant: none", false, GUIEditorz.window[1])
		guiSetFont(GUIEditorz.label[1], "default-bold-small")
		guiLabelSetVerticalAlign(GUIEditorz.label[1], "center")
		GUIEditorz.label[2] = guiCreateLabel(15*width, 87*height, 307*width, 38*height, "Kwota: none", false, GUIEditorz.window[1])
		guiSetFont(GUIEditorz.label[2], "default-bold-small")
		guiLabelSetVerticalAlign(GUIEditorz.label[2], "center")	
		GUIEditorz.label[3] = guiCreateLabel(15*width, 135*height, 307*width, 38*height, "Punkty karne: none", false, GUIEditorz.window[1])
		guiSetFont(GUIEditorz.label[3], "default-bold-small")
		guiLabelSetVerticalAlign(GUIEditorz.label[3], "center")
		GUIEditorz.label[4] = guiCreateLabel(15*width, 193*height, 521*width, 71*height, "Powód mandatu: none", false, GUIEditorz.window[1])
		guiSetFont(GUIEditorz.label[4], "default-bold-small")
		guiLabelSetHorizontalAlign(GUIEditorz.label[4], "left", true)
		GUIEditorz.button[1] = guiCreateButton(15*width, 350*height, 211*width, 42*height, "Przyjmuję!", false, GUIEditorz.window[1])
		guiSetProperty(GUIEditorz.button[1], "NormalTextColour", "FFAAAAAA")
		GUIEditorz.button[2] = guiCreateButton(326*width, 350*height, 211*width, 42*height, "Odrzucam...", false, GUIEditorz.window[1])
		guiSetProperty(GUIEditorz.button[2], "NormalTextColour", "FFAAAAAA")
		addEventHandler("onClientGUIClick", GUIEditorz.button[2], onOdrzuc, false)
		addEventHandler("onClientGUIClick",GUIEditorz.button[1], onPrzyjmij, false)
	end
	
guiSetVisible(GUIEditorz.window[1], true)
showCursor(true)
end

addEvent("WysMan",true)
addEventHandler("WysMan",root, 
	function(kwota, pkt, powod, name, plr)
		createGUI()
		guiSetText(GUIEditorz.label[1],"Policjant: "..plr.." ")
		guiSetText(GUIEditorz.label[2],"Kwota: "..math.ceil(tonumber(kwota)))
		guiSetText(GUIEditorz.label[3],"Punkty Karne: "..math.ceil(tonumber(pkt)))
		guiSetText(GUIEditorz.label[4],"Powód Mandatu: "..powod.." ")
		setElementData(name, "kwotaM", math.ceil(tonumber(kwota)))
		setElementData(name, "pktM", (tonumber(pkt)))
		setElementData(localPlayer, "graczMa", name)
	end
)

function onZamknij()
guiSetVisible(GUIEditorz.window[1], false)
showCursor(false)
end

function onOdrzuc()
local name = getElementData(localPlayer,"graczMa")
onZamknij()
triggerServerEvent("odrzucOferte", localPlayer, name, ss)
end

function onPrzyjmij()
local name = getElementData(localPlayer,"graczMa")
onZamknij()
triggerServerEvent("przyjmijOferte", localPlayer, name, ss)
end

function Wyslij()
	local kwota = guiGetText(GUIEditore.edit[3])
	local pkt = guiGetText(GUIEditore.edit[2])
	local powod = guiGetText(GUIEditore.edit[1])
	local name = getElementData(localPlayer,"nickO")
	if tonumber(kwota) then
		if kwota ~= "" and pkt ~= "" and powod ~= "" then
			if tonumber(pkt) then
				if tonumber(pkt) <= 5 then
					if tonumber(pkt) >= 0 and tonumber(kwota) >= 0 then
						guiSetVisible(GUIEditore.window[2], false)
						showCursor(false)
						triggerServerEvent("WystawionyMandat", localPlayer, kwota, pkt, powod, name)
						setElementData(localPlayer, "wysM", localPlayer)
					else
						--outputChatBox("● INFO: Kwota oraz punkty muszą być dodatnie!",255,0,0,true)
						exports["skyrpg_gui"]:addNotification("Kwota oraz punkty muszą być dodatnie!", 'error')
					end
				else
					--outputChatBox("● INFO: Max możesz dać 5 punktów karnych!",255,0,0,true)
					exports["skyrpg_gui"]:addNotification("Maksymalnie możesz dać 5 punktów karnych!", 'error')
				end
			else
				--outputChatBox("● INFO: Punkty muszą być podane liczbowo!",255,0,0,true)
				exports["skyrpg_gui"]:addNotification("Punkty muszą być podane liczbowo!", 'error')
			end
		else
		--outputChatBox("● INFO: Uzupełnij wszystkie pola!",255,0,0,true)
		exports["skyrpg_gui"]:addNotification("Uzupełnij wszystkie pola!", 'error')
		end
	else
		--outputChatBox("● INFO: Kwota musi być podana liczbowo!",255,0,0,true)
		exports["skyrpg_gui"]:addNotification("Kwota musi być podana liczbowo!", 'error')
	end
end
addEventHandler("onClientGUIClick",GUIEditore.button[5], Wyslij, false)