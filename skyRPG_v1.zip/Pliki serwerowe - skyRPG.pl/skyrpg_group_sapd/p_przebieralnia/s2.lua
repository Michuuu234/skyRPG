
local mark = createPickup(254.2509765625, 77.1572265625, 1003.640625,3, 1275, 1)
setElementInterior(mark, 6)

addEventHandler("onPickupHit",mark,
	function(player)
		local accName = getAccountName ( getPlayerAccount ( player ) )      
		if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then
		triggerClientEvent(player, "startGGPol", root, player)
		end
	end
)

addEvent("przebierzPol", true)
addEventHandler("przebierzPol",root,
	function(model)
	local skin = getElementModel(source)
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
	local accName = getAccountName ( getPlayerAccount ( source ) )      
		if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then 	
			if getAccountData(acc,"PracaPol") == false then
				setAccountData(acc,"starySkinPol", skin)
				setElementModel(source, model)
				setAccountData(acc,"PracaPol", true)
				--outputChatBox("● INFO: Rozpoczynasz służbę w policji!",source,255,0,0,true)
				exports["skyrpg_gui"]:addNotification(source, "Rozpoczynasz służbę w policji!", 'info')
				setElementData(source, "sluzba", "SAPD")
				toggleControl(source,"fire",true)
				toggleControl(source,"aim_weapon",true)
				toggleControl(source,"action", true)
			else
				--outputChatBox("● INFO: Jesteś już na służbie!",source,255,0,0,true)
				exports["skyrpg_gui"]:addNotification(source, "Jesteś już na służbie!", 'error')
			end
		end
	end
)

addEvent("bronPol", true)
addEventHandler("bronPol",root,
	function()
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
		if getAccountData(acc,"PracaPol") == true then
			giveWeapon(source, 3)
			giveWeapon(source, 23, 99999)
			giveWeapon(source, 29, 99999)
			giveWeapon(source, 31, 99999)
			setWeaponAmmo(source,23,99999)
			setWeaponAmmo(source,29,99999)
			setWeaponAmmo(source,31,99999)
			--outputChatBox("● INFO: Pobierasz broń z magazynu policyjnego.",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Pobierasz broń z magazynu policyjnego.", 'info')
		else
			--outputChatBox("● INFO: Niestety, nie jesteś na służbie!",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Niestety, nie jesteś na służbie!", 'error')
		end
	end
)

addEvent("kamizelkaPol", true)
addEventHandler("kamizelkaPol",root,
	function()
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
		if getAccountData(acc,"PracaPol") == true then
			setPedArmor(source, 100)
			--outputChatBox("● INFO: Pobierasz kamizelke z magazynu",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Pobierasz kamizelke z magazynu.", 'info')
		else
			--outputChatBox("● INFO: Nie jesteś na służbie!",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Nie jesteś na służbie!", 'error')
		end
	end
)

addEvent("zakonczPol", true)
addEventHandler("zakonczPol",root,
	function()
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
	local skin = getAccountData(acc,"starySkinPol")
		if getAccountData(acc,"PracaPol") == true then
			setElementModel(source, skin)
			setAccountData(acc,"PracaPol", false)
			setElementData(source, "sluzba", false)
			--outputChatBox("● INFO: Kończysz służbe w policji!",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Kończysz służbe w policji!", 'info')
			toggleControl(source,"fire",false)
			toggleControl(source,"aim_weapon",false)
			toggleControl(source,"action", false)
			takeWeapon(source, 3)
			takeWeapon(source, 23)
			takeWeapon(source, 29)
			takeWeapon(source, 31)
		else
			--outputChatBox("● INFO: Nie jesteś na służbie policyjnej!",source,255,0,0,true)
			exports["skyrpg_gui"]:addNotification(source, "Nie jesteś na służbie policyjnej!", 'error')
		end
	end
)

local function trzezwienie()
    local players=getElementsByType('player')
    for i,v in pairs(players) do
		local acc = getPlayerAccount(v)   
	local accName = getAccountName ( acc )      			
		if getAccountData(acc,"PracaPol") == true or isObjectInACLGroup ("user."..accName, aclGetGroup ( "Admin" ) ) or isObjectInACLGroup ("user."..accName, aclGetGroup ( "ModeratorG" ) ) then
			toggleControl(v,"fire",true)
			toggleControl(v,"aim_weapon",true)
			toggleControl(v,"action", true)
		end
    end 
end
setTimer(trzezwienie, 4000, 0)

addEvent("zakonczPolQuit", true)
addEventHandler("onPlayerQuit", root,
	function()
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
	setAccountData(acc,"PracaPol", false)
end)

addEvent("zakonczPolDead", true)
addEventHandler("onPlayerWasted", root,
	function()
	local gracz = getPlayerName(source)
	local nick = getPlayerFromName(gracz)
	local acc = getPlayerAccount(nick)
	local accName = getAccountName ( getPlayerAccount ( source ) ) 
	local sluzba = getAccountData(acc,"PracaPol")
	local skin = getAccountData(acc,"starySkinPol")
	if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then
		if sluzba then
			setElementModel(source, skin)
			setAccountData(acc, "PracaPol", false)
			setElementData(source, "sluzba", false)
			exports["skyrpg_gui"]:addNotification(source, "Kończysz służbe w policji z powodu zginięcia!", 'info')
		end
	end
end)