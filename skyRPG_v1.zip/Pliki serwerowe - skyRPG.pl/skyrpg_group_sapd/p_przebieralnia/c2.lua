﻿mojeW,mojeH = 1680, 1050
sW,sH = guiGetScreenSize()
width, height = (sW/mojeW), (sH/mojeH)

GUIEditorq = {
    button = {},
    window = {},
    radiobutton = {}
}
GUIEditorq.window[1] = guiCreateWindow(578*width, 234*height, 500*width, 384*height, "Przebieralnia policji", false)
guiWindowSetSizable(GUIEditorq.window[1], false)

GUIEditorq.button[1] = guiCreateButton(28*width, 75*height, 192*width, 49*height, "Pobierz broń", false, GUIEditorq.window[1])
guiSetProperty(GUIEditorq.button[1], "NormalTextColour", "FFAAAAAA")
GUIEditorq.button[2] = guiCreateButton(28*width, 147*height, 192*width, 49*height, "Pobierz kamizelke", false, GUIEditorq.window[1])
guiSetProperty(GUIEditorq.button[2], "NormalTextColour", "FFAAAAAA")
GUIEditorq.button[3] = guiCreateButton(300*width, 196*height, 190*width, 49*height, "Rozpocznij pracę", false, GUIEditorq.window[1])
guiSetProperty(GUIEditorq.button[3], "NormalTextColour", "FFAAAAAA")
GUIEditorq.radiobutton[1] = guiCreateRadioButton(267*width, 69*height, 171*width, 25*height, "Skin 280", false, GUIEditorq.window[1])
guiRadioButtonSetSelected(GUIEditorq.radiobutton[1], true)
GUIEditorq.radiobutton[2] = guiCreateRadioButton(267*width, 99*height, 171*width, 25*height, "Skin 281", false, GUIEditorq.window[1])
GUIEditorq.radiobutton[3] = guiCreateRadioButton(267*width, 134*height, 171*width, 25*height, "Policjant w cywilu", false, GUIEditorq.window[1])
GUIEditorq.radiobutton[4] = guiCreateRadioButton(267*width, 169*height, 171*width, 25*height, "SWAT", false, GUIEditorq.window[1])
GUIEditorq.button[5] = guiCreateButton(25*width, 325*height, 185*width, 49*height, "Zakończ pracę", false, GUIEditorq.window[1])
guiSetProperty(GUIEditorq.button[5], "NormalTextColour", "FFAAAAAA")
GUIEditorq.button[6] = guiCreateButton(449*width, 23*height, 41*width, 36*height, "X", false, GUIEditorq.window[1])
guiSetProperty(GUIEditorq.button[6], "NormalTextColour", "FFAAAAAA")

guiSetVisible(GUIEditorq.window[1], false)

addEvent("startGGPol",true)
addEventHandler("startGGPol", root, 
	function(hitElement)
		if hitElement == localPlayer then
			guiSetVisible(GUIEditorq.window[1], true)
			showCursor(true)
		end
	end
)

function onZamknij4()
	guiSetVisible(GUIEditorq.window[1], false)
	showCursor(false)
end
addEventHandler("onClientGUIClick",GUIEditorq.button[6],onZamknij4,false)

function przebierz()
	if guiRadioButtonGetSelected(GUIEditorq.radiobutton[1]) then
		triggerServerEvent("przebierzPol", localPlayer, 280)
	elseif guiRadioButtonGetSelected(GUIEditorq.radiobutton[2]) then
		triggerServerEvent("przebierzPol", localPlayer, 281)
	elseif guiRadioButtonGetSelected(GUIEditorq.radiobutton[3]) then
		triggerServerEvent("przebierzPol", localPlayer, 240)
	elseif guiRadioButtonGetSelected(GUIEditorq.radiobutton[4]) then
		triggerServerEvent("przebierzPol", localPlayer, 285)
	else
		--outputChatBox("● INFO: Wybierz skina do przebrania!",255,0,0,true)
		exports["skyrpg_gui"]:addNotification("Wybierz skina do przebrania!", 'error')
	end
end
addEventHandler("onClientGUIClick",GUIEditorq.button[3],przebierz,false)

function zakoncz()
	triggerServerEvent("zakonczPol", localPlayer)
end
addEventHandler("onClientGUIClick",GUIEditorq.button[5],zakoncz,false)

function bron()
	triggerServerEvent("bronPol", localPlayer)
end
addEventHandler("onClientGUIClick",GUIEditorq.button[1],bron,false)

function kam()
	triggerServerEvent("kamizelkaPol", localPlayer)
end
addEventHandler("onClientGUIClick",GUIEditorq.button[2],kam,false)