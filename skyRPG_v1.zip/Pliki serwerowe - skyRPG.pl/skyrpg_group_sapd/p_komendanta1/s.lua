﻿function uzupelnij(player)
	local accName = getAccountName ( getPlayerAccount ( player ) )      
	if accName == "Makari" then  
	local acl = aclGetGroup( "SAPD" )
	local data = {}
	for i,v in ipairs(aclGroupListObjects(acl)) do
	    if string.sub( v, 1, 5 ) == "user." then
	        local len = string.len( v )
	        local name3 = string.sub( v, 6, len )
	        table.insert( data, name3 )
	    end
	end	
	triggerClientEvent( player, "uruch", root, data )
	end
end
addCommandHandler("komendant", uzupelnij)

function zatrudnij( name )
	local ppl = getPlayerFromName( name )
	local ac = getPlayerAccount( ppl )
	local acname = getAccountName( ac )
	local acl2 = aclGetGroup( "SAPD" )
	if acl2 then
		aclGroupAddObject( acl2, "user." .. acname )
		aclSave()
		aclReload()	
		--[[outputChatBox( "● INFO: Gracz " .. getPlayerName(ppl) .. " zostal zatrudniony pod nazwa " .. acname .. ".", source, 255, 0, 0, true )
		outputChatBox( "● INFO: Zostales zatrudniony do policji, przez głownego jego komendanta!", ppl, 255, 0, 0, true )]]--
		exports["skyrpg_gui"]:addNotification(source, "Gracz " .. getPlayerName(ppl) .. " zostal zatrudniony pod nazwa " .. acname .. ".", 'success')	
		exports["skyrpg_gui"]:addNotification(ppl, "Zostales zatrudniony do policji przez głownego komendanta!", 'success')	
	end
end

addEvent( "zatrudnijPr", true )
addEventHandler( "zatrudnijPr",root, zatrudnij )

function za( name, nr, data )
	local names = getAccount(name)
	setAccountData(names,"nrPol", nr)
	setAccountData(names,"dataPol", data)
	--outputChatBox("● INFO: Zmieniłeś funkcjonariuszowi "..name.." nr. legitymacji na: "..nr.." oraz date ważności legitymacji do: "..data..".",source, 255,0,0,true)
	exports["skyrpg_gui"]:addNotification(source, "Zmieniłeś funkcjonariuszowi "..name.." nr. legitymacji na: "..nr.." oraz date ważności legitymacji do: "..data..".", 'success')	
end

addEvent( "AkceptujPra", true )
addEventHandler( "AkceptujPra",root, za )

function zwolnij( name )
	local acl2 = aclGetGroup( "SAPD" )
	if acl2 then
		aclGroupRemoveObject( acl2, "user." .. name )
		aclSave()
		aclReload()	
		--outputChatBox( "● INFO: Gracz/Funkcjonariusz " .. name .. " zostal zwolniony.", source, 255, 0, 0, true )
		exports["skyrpg_gui"]:addNotification(source, "Funkcjonariusz " .. name .. " zostal zwolniony.", 'info')	
	end
end

addEvent( "zwolnijPr", true )
addEventHandler( "zwolnijPr", getRootElement(), zwolnij )

function akceptuj( name, ranga )
	local acc = getAccount(name)
	if name then
	setAccountData(acc, "StopienPol", ranga)
	--outputChatBox( "● INFO: Zmieniłeś stopień funkcjonariuszowi "..name.." na "..ranga..".", source, 255, 0, 0, true )
	exports["skyrpg_gui"]:addNotification(source, "Zmieniłeś stopień funkcjonariuszowi "..name.." na "..ranga..".", 'success')	
	else
	--outputChatBox( "● INFO: Funkcjonariusza " .. name .. " nie ma na serwerze.", source, 255, 255, 255, true )
	exports["skyrpg_gui"]:addNotification(source, "Funkcjonariusza " .. name .. " nie ma na serwerze.", 'error')
	end
end

addEvent( "AkceptujPr", true )
addEventHandler( "AkceptujPr", getRootElement(), akceptuj )