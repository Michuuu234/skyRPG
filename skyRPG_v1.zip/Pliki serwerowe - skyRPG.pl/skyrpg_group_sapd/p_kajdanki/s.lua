function findPlayer(plr,cel)
	local target=nil
	if (tonumber(cel) ~= nil) then
		target=getElementByID("p"..cel)
	else -- podano fragment nicku
		for _,thePlayer in ipairs(getElementsByType("player")) do
			if string.find(string.gsub(getPlayerName(thePlayer):lower(),"#%x%x%x%x%x%x", ""), cel:lower(), 1, true) then
				if (target) then
					--outputChatBox("Znaleziono wiecej niz jednego gracza o pasujacym nicku, podaj wiecej liter.", plr)
					exports["skyrpg_gui"]:addNotification(plr, "Znaleziono wiecej niz jednego gracza o pasujacym nicku, podaj wiecej liter.", 'error')
					return nil
				end
				target=thePlayer
			end
		end
	end
	return target
end

kaj = {}

function zalozkaj(plr, cmd, target)
	local gracz = findPlayer(plr, target)
	if getElementData(plr, "wiezien") == false then
		local accName = getAccountName ( getPlayerAccount ( plr ) )      
			if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then 
			local gracz = getPlayerName(gracz)
			local gracz = getPlayerFromName(gracz)
			local x2,y2,z2 = getElementPosition(gracz)
				local x,y,z = getElementPosition(plr)
				if (getDistanceBetweenPoints3D(x,y,z,x2,y2,z2)<20) then
					toggleControl(gracz, "enter_exit", false)
					toggleControl(gracz, "enter_passenger", false)
					attachElements(gracz, plr, 0,0.4,0)
					setElementPosition(gracz, x,y,z)
					local graczz = getPlayerName(gracz)
					kaj[plr] = {}
					kaj[plr] = {graczz}
					setElementData(plr,"wiezien", true)
					--outputChatBox("● INFO: Policjant "..getPlayerName(plr).." zakuwa cię w kajdanki.",gracz, 255,0,0,true)
					--outputChatBox("● INFO: Zakładasz kajdanki graczowi "..graczz..".",plr,255,0,0,true)
					exports["skyrpg_gui"]:addNotification(gracz, "Policjant "..getPlayerName(plr).." zakuwa cię w kajdanki.", 'info')
					exports["skyrpg_gui"]:addNotification(plr, "Zakładasz kajdanki graczowi "..graczz..".", 'info')
				end
			end
	else
		--outputChatBox("● INFO: Nie możesz założyć kajdanek dwóm osobom na raz.",plr,255,0,0, true)
		exports["skyrpg_gui"]:addNotification(plr, "Nie możesz założyć kajdanek dwóm osobom na raz.", 'error')
	end
end
addCommandHandler("zakuj",zalozkaj)

addEventHandler("onVehicleEnter",root,
function(plr)
	if getElementData(plr, "wiezien") then
		local peds = kaj[plr][1]
		local ped = getPlayerFromName(peds)
		local veh = getPedOccupiedVehicle(plr)
		local atta = getAttachedElements(plr)
			for i,v in pairs(atta)do
				detachElements(v, plr)
			end
		warpPedIntoVehicle(ped, veh, 3)
		--outputChatBox("● INFO: Policjant "..getPlayerName(plr).." wsadza cię do radiowozu.",ped, 255,0,0,true)
		--outputChatBox("● INFO: Wsadzasz do radiowozu gracza "..getPlayerName(ped)..".",plr,255,0,0,true)
		exports["skyrpg_gui"]:addNotification(ped, getPlayerName(plr).." wsadza cię do radiowozu.", 'info')
		exports["skyrpg_gui"]:addNotification(plr, "Wsadzasz do radiowozu gracza "..getPlayerName(ped)..".", 'info')
	end
end)

addEventHandler("onVehicleStartExit",root,
function(plr)
	if getElementData(plr, "wiezien") then
		local ped = kaj[plr][1]
		local ped = getPlayerFromName(ped)
		local x,y,z = getElementPosition(plr)
		removePedFromVehicle(ped)
		attachElements(ped, plr, 0,0.4,0)
		--outputChatBox("● INFO: Policjant #FF0036"..getPlayerName(plr).."#919191 wyciąga cię z radiowozu.",ped, 255,0,0,true)
		--outputChatBox("● INFO: Wyciągasz z radiowozu gracza "..getPlayerName(ped)..".",plr,255,0,0,true)
		exports["skyrpg_gui"]:addNotification(ped, getPlayerName(plr).." wyciąga cię z radiowozu.", 'info')
		exports["skyrpg_gui"]:addNotification(plr, "Wyciągasz z radiowozu gracza "..getPlayerName(ped)..".", 'info')
	end
end)

function sciagnijkaj(plr, cmd, target)
	local gracz = findPlayer(plr, target)
	if getElementData(plr, "wiezien") then
		local accName = getAccountName ( getPlayerAccount ( plr ) )      
			if isObjectInACLGroup ("user."..accName, aclGetGroup ( "SAPD" ) ) then 
			local gracz = getPlayerName(gracz)
			local gracz = getPlayerFromName(gracz)
			local x2,y2,z2 = getElementPosition(gracz)
				local x,y,z = getElementPosition(plr)
					if (getDistanceBetweenPoints3D(x,y,z,x2,y2,z2)<20) then
					local atta = getAttachedElements(plr)
					toggleControl(gracz, "enter_exit", true)
					toggleControl(gracz, "enter_passenger", true)
						for i,v in pairs(atta)do
							detachElements(v, plr)
						end
					setElementPosition(gracz, x+2,y,z)
					setElementData(plr,"wiezien", false)
					kaj[plr] = {}
					--outputChatBox("● INFO: Policjant "..getPlayerName(plr).." odkuwa cię.",gracz, 255,0,0,true)
					--outputChatBox("● INFO: Ściągasz kajdanki graczowi "..getPlayerName(gracz)..".",plr,255,0,0,true)
					exports["skyrpg_gui"]:addNotification(gracz, getPlayerName(plr).." odkuwa cię.", 'info')
					exports["skyrpg_gui"]:addNotification(plr, "Ściągasz kajdanki graczowi "..getPlayerName(gracz)..".", 'info')
				end
			end
	else
		--outputChatBox("● INFO: Nie załozyłeś nikomu kajdanek.",plr,255,0,0, true)
		exports["skyrpg_gui"]:addNotification(plr, "Nie załozyłeś nikomu kajdanek.", 'error')
	end
end
addCommandHandler("odkuj",sciagnijkaj)

