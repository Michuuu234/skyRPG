v1 = createMarker(-1605.5693359375, 710.783203125, 13.8671875+0.7,"arrow",1,255,255,0,255)
v2 = createMarker(246.787109375, 62.74609375, 1003.640625+0.85,"arrow",1,255,255,0,255)
setElementInterior(v2,6)

v5 = createMarker(242.724609375, 66.2734375, 1003.640625+0.7,"arrow",1,255,255,0,255)
setElementInterior(v5,6)
v6 = createMarker(-1594.2099609375, 716.1787109375, -4.90625+0.85,"arrow",1,255,255,0,255)

ped = createPed(281,251.6484375, 67.9853515625, 1003.640625, 90.223846435547)
setElementInterior(ped, 6)

addEventHandler("onMarkerHit",v5, 
	function(hitElement)
		exports.skyrpg_loading:wyswietlObiekty(hitElement)
		setElementPosition(hitElement, -1586.7373046875, 715.6162109375, -5.2421875)
		setElementInterior(hitElement, 0)
	end
)

addEventHandler("onMarkerHit", v6 ,
	function(hitElement)
		exports.skyrpg_loading:wyswietlObiekty(hitElement)
		local veh = getPedOccupiedVehicle(hitElement)
		if veh then
		else
		setElementPosition(hitElement, 245.76953125, 66.9921875, 1003.640625)
		setElementInterior(hitElement, 6)
		end
	end
)


addEventHandler("onMarkerHit",v1, 
	function(hitElement)
		local veh = getPedOccupiedVehicle(hitElement)
		if not veh then
			if getElementData(hitElement, "wiezien") then
				local atta = getAttachedElements(hitElement)
				setElementPosition(hitElement,246.369140625, 66.296875, 1003.640625)
				setElementInterior(hitElement, 6)
				for i,v in ipairs(atta) do
					setElementPosition(v,246.369140625, 66.296875, 1004.640625)
					setElementInterior(v, 6)
					attachElements(v, hitElement, 0,0.4,0)
				end
			else
				exports.skyrpg_loading:wyswietlObiekty(hitElement)
				setElementPosition(hitElement,246.369140625, 66.296875, 1003.640625)
				setElementInterior(hitElement, 6)
			end
		end
	end
)

addEventHandler("onMarkerHit", v2 ,
	function(hitElement)
				if getElementData(hitElement, "wiezien") then
				local atta = getAttachedElements(hitElement)
				setElementPosition(hitElement,-1605.7763671875, 720.9423828125, 12.009721755981)
				setElementInterior(hitElement, 0)
				for i,v in ipairs(atta) do
					setElementPosition(v,-1605.7763671875, 720.9423828125, 12.009721755981)
					setElementInterior(v, 0)
					attachElements(v, hitElement, 0,0.4,0)
				end
			else
				exports.skyrpg_loading:wyswietlObiekty(hitElement)
				setElementPosition(hitElement,-1605.7763671875, 720.9423828125, 12.009721755981)
				setElementInterior(hitElement, 0)
			end
	end
)