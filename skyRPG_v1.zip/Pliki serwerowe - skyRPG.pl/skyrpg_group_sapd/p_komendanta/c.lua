mojeW,mojeH = 1680, 1050
sW,sH = guiGetScreenSize()
width, height = (sW/mojeW), (sH/mojeH)

GUIEditorr = {
    button = {},
    window = {},
    label = {},
    combobox = {},
	gridlist = {},
	edit = {}
}
GUIEditorr.window[1] = guiCreateWindow(612*width, 306*height, 429*width, 344*height, "Panel Komendanta", false)
guiWindowSetSizable(GUIEditorr.window[1], false)

GUIEditorr.combobox[1] = guiCreateComboBox(24*width, 65*height, 150*width, 158*height, "--Wybierz--", false, GUIEditorr.window[1])
GUIEditorr.combobox[2] = guiCreateComboBox(214*width, 65*height, 193*width, 158*height, "--Wybierz--", false, GUIEditorr.window[1])
guiComboBoxAddItem(GUIEditorr.combobox[2], "Generalny Inspektor")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Nadinspektor")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Inspektor")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Młodszy Inspektor")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Podinspektor")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Nadkomisarz")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Komisarz")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Podkomisarz")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Aspirant Sztabowy")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Starszy Aspirant")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Aspirant")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Młodszy Aspirant")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Sierżant Sztabowy")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Starszy Sierżant")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Sierżant")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Starszy Posterunkowy")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Posterunkowy")
guiComboBoxAddItem(GUIEditorr.combobox[2], "Brak")
GUIEditorr.label[1] = guiCreateLabel(26*width, 34*height, 93*width, 21*height, "Login:", false, GUIEditorr.window[1])
guiSetFont(GUIEditorr.label[1], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditorr.label[1], "center")
GUIEditorr.label[2] = guiCreateLabel(214*width, 34*height, 120*width, 21*height, "Stopień Służbowy:", false, GUIEditorr.window[1])
guiSetFont(GUIEditorr.label[2], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditorr.label[2], "center")
GUIEditorr.button[1] = guiCreateButton(24*width, 228*height, 150*width, 38*height, "Zatrudnij", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[1], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[2] = guiCreateButton(257*width, 228*height, 150*width, 38*height, "Zwolnij", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[2], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[3] = guiCreateButton(142*width, 276*height, 150*width, 38*height, "Dodaj Premie", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[3], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[4] = guiCreateButton(9*width, 295*height, 44*width, 39*height, "X", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[4], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[8] = guiCreateButton(69*width, 295*height, 64*width, 39*height, "Leg.", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[8], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[5] = guiCreateButton(141*width, 175*height, 150*width, 38*height, "Akceptuj Zmiany", false, GUIEditorr.window[1])
guiSetProperty(GUIEditorr.button[5], "NormalTextColour", "FFAAAAAA")

GUIEditorr.window[2] = guiCreateWindow(631*width, 310*height, 379*width, 404*height, "Panel Zatrudniania", false)
guiWindowSetSizable(GUIEditorr.window[2], false)

GUIEditorr.gridlist[1] = guiCreateGridList(29*width, 47*height, 243*width, 305*height, false, GUIEditorr.window[2])
guiGridListAddColumn(GUIEditorr.gridlist[1], "Gracz", 0.9)
GUIEditorr.button[6] = guiCreateButton(219*width, 363*height, 150*width, 31*height, "Zatrudnij", false, GUIEditorr.window[2])
guiSetProperty(GUIEditorr.button[6], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[7] = guiCreateButton(323*width, 25*height, 46*width, 41*height, "X", false, GUIEditorr.window[2])
guiSetProperty(GUIEditorr.button[7], "NormalTextColour", "FFAAAAAA")

GUIEditorr.window[3] = guiCreateWindow(631*width, 310*height, 379*width, 190*height, "Panel Legitymacji", false)
guiWindowSetSizable(GUIEditorr.window[3], false)

GUIEditorr.label[3] = guiCreateLabel(24*width, 50*height, 50*width, 36*height, "Nr:", false, GUIEditorr.window[3])
guiSetFont(GUIEditorr.label[3], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditorr.label[3], "center")
GUIEditorr.label[4] = guiCreateLabel(24*width, 90*height, 50*width, 36*height, "Data:", false, GUIEditorr.window[3])
guiSetFont(GUIEditorr.label[4], "default-bold-small")
guiLabelSetVerticalAlign(GUIEditorr.label[4], "center")
GUIEditorr.edit[1] = guiCreateEdit(57*width, 50*height, 220*width, 36*height, "", false, GUIEditorr.window[3])
GUIEditorr.edit[2] = guiCreateEdit(57*width, 90*height, 220*width, 36*height, "", false, GUIEditorr.window[3])
GUIEditorr.button[9] = guiCreateButton(219*width, 160*height, 150*width, 31*height, "Akceptuj", false, GUIEditorr.window[3])
guiSetProperty(GUIEditorr.button[9], "NormalTextColour", "FFAAAAAA")
GUIEditorr.button[10] = guiCreateButton(323*width, 25*height, 46*width, 41*height, "X", false, GUIEditorr.window[3])
guiSetProperty(GUIEditorr.button[10], "NormalTextColour", "FFAAAAAA")

guiSetVisible(GUIEditorr.window[3], false)
guiSetVisible(GUIEditorr.window[2], false)
guiSetVisible(GUIEditorr.window[1], false)

addEvent( "uruch", true )
addEventHandler( "uruch", root,
function(data)
	guiSetVisible(GUIEditorr.window[1], true)
	showCursor(true)
	guiComboBoxClear( GUIEditorr.combobox[1] )
    for i,v in ipairs(data) do
        guiComboBoxAddItem( GUIEditorr.combobox[1], v )
    end
end
)


	function zatrudnij()
		guiSetVisible(GUIEditorr.window[1], false)
		guiSetVisible(GUIEditorr.window[2], true)
		guiGridListClear( GUIEditorr.gridlist[1] )
		for i,v in ipairs(getElementsByType("player")) do
			local row = guiGridListAddRow( GUIEditorr.gridlist[1] )
			guiGridListSetItemText( GUIEditorr.gridlist[1], row, 1, getPlayerName(v), false, false )
		end
	end
addEventHandler("onClientGUIClick", GUIEditorr.button[1],zatrudnij,false)

 
function Zamknij1()
		guiSetVisible(GUIEditorr.window[1], false)
		showCursor(false)		
end
addEventHandler("onClientGUIClick",GUIEditorr.button[4], Zamknij1,false)


function Zamknij2()
		guiSetVisible(GUIEditorr.window[2], false)
		showCursor(false)		
end
addEventHandler("onClientGUIClick",GUIEditorr.button[7], Zamknij2, false)

function Zamknij3()
		guiSetVisible(GUIEditorr.window[3], false)
		showCursor(false)		
end
addEventHandler("onClientGUIClick",GUIEditorr.button[10], Zamknij3, false)


function zatrudnijPr()
    	local row = guiGridListGetSelectedItem( GUIEditorr.gridlist[1] )
    	if row ~= -1 then
    		local name = guiGridListGetItemText( GUIEditorr.gridlist[1], row, 1 )
    		if getPlayerFromName( name ) then
    			guiSetVisible( GUIEditorr.window[2], false )
				showCursor(false)	
    			triggerServerEvent( "zatrudnijPr", getLocalPlayer(), name)
    		else
    			--outputChatBox( "* Gracz nie istnieje.", 255, 0, 0, true )
				exports["skyrpg_gui"]:addNotification("Gracz nie istnieje.", 'error')				
    		end
    	else
    		--outputChatBox( "* Wybierz gracza, ktorego chcesz zatrudnic.", 255, 0, 0, true )
			exports["skyrpg_gui"]:addNotification("Wybierz gracza, ktorego chcesz zatrudnic.", 'error')				
    	end
end
addEventHandler("onClientGUIClick",GUIEditorr.button[6], zatrudnijPr, false)

function zwolnijPr()
		local name = guiGetText( GUIEditorr.combobox[1] )
	    if name ~= "-- Wybierz --" then
			guiSetVisible(GUIEditorr.window[1], false)
			showCursor(false)	
			triggerServerEvent( "zwolnijPr", getLocalPlayer(), name )
		else
		    --outputChatBox( "* Wybierz pracownika.", 255, 0, 0 )
			exports["skyrpg_gui"]:addNotification("Wybierz pracownika.", 'error')	
		end	
end
addEventHandler("onClientGUIClick",GUIEditorr.button[2], zwolnijPr, false)

function akceptuj()
		local name = guiGetText( GUIEditorr.combobox[1] )
		local name1 = guiGetText( GUIEditorr.combobox[2] )
	    if name ~= "-- Wybierz --" and name1 ~= "-- Wybierz --" then
			triggerServerEvent( "AkceptujPr", getLocalPlayer(), name , name1 )
		else
		    --outputChatBox( "* Wybierz pracownika i Stopnień.", 255, 0, 0 )
			exports["skyrpg_gui"]:addNotification("Wybierz pracownika i stopień.", 'error')	
		end	
end
addEventHandler("onClientGUIClick",GUIEditorr.button[5], akceptuj, false)

function akceptuj1()
		local name = guiGetText( GUIEditorr.combobox[1] )
	    if name ~= "-- Wybierz --" then
			guiSetVisible(GUIEditorr.window[1], false)
			guiSetVisible(GUIEditorr.window[3], true)
			setElementData(localPlayer,"Pra", name)
		else
		    --outputChatBox( "* Wybierz pracownika.", 255, 0, 0 )
			exports["skyrpg_gui"]:addNotification("Wybierz pracownika.", 'error')	
		end	
end
addEventHandler("onClientGUIClick",GUIEditorr.button[8], akceptuj1, false)


function akceptuj2()
	local nr = guiGetText( GUIEditorr.edit[1] )
	local data = guiGetText( GUIEditorr.edit[2] )
	local name = getElementData(localPlayer,"Pra")
	triggerServerEvent( "AkceptujPra", getLocalPlayer(), name, nr, data )
end
addEventHandler("onClientGUIClick",GUIEditorr.button[9], akceptuj2, false)


