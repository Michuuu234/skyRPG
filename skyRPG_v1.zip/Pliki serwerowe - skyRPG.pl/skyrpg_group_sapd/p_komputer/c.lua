GUIEditorse = {
    gridlist = {},
    window = {},
    button = {}
}
GUIEditorse.window[1] = guiCreateWindow(0.35, 0.33, 0.30, 0.34, "Komputer policji", true)
guiWindowSetSizable(GUIEditorse.window[1], false)

GUIEditorse.gridlist[1] = guiCreateGridList(0.05, 0.26, 0.91, 0.71, true, GUIEditorse.window[1])
guiGridListAddColumn(GUIEditorse.gridlist[1], "Gracz", 0.5)
guiGridListAddColumn(GUIEditorse.gridlist[1], "Kwota z mandatów", 0.3)
GUIEditorse.button[1] = guiCreateButton(0.92, 0.05, 0.06, 0.08, "X", true, GUIEditorse.window[1])
guiSetProperty(GUIEditorse.button[1], "NormalTextColour", "FFAAAAAA")

guiSetVisible(GUIEditorse.window[1], false)

function Start()
	guiSetVisible(GUIEditorse.window[1], true)
	showCursor(true)
	guiGridListClear( GUIEditorse.gridlist[1] )
	for i,v in ipairs(getElementsByType("player")) do
		local row = guiGridListAddRow( GUIEditorse.gridlist[1] )
		guiGridListSetItemText( GUIEditorse.gridlist[1], row, 1, getPlayerName(v), false, false )
		guiGridListSetItemText( GUIEditorse.gridlist[1], row, 2, "0", false, false )
	end
end
addCommandHandler("startKom", Start)