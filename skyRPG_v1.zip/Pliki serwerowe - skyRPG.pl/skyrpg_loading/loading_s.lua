-- ekran ladowania (server-side)

function downloadingData (root)
  triggerClientEvent("downloadingData", root)
end

function loadingObjects (localPlayer)
  triggerClientEvent("loadingObjects", localPlayer)
end