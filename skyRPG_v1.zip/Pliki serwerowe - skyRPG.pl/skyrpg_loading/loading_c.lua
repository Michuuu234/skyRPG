local screenW, screenH = guiGetScreenSize()
local wFont = dxCreateFont(":skyrpg_gui/hud/fonts/normal.ttf", 18)

if not wFont then
  wFont = "default-bold"
end

local startTicking = getTickCount()
local rotation = 0

function downloadingFiles () -- Pobieranie zasob�w/danych z serwera do klienta

  local now = getTickCount()
  local endTime = startTicking + 5000
  local elapsedTime = now - startTicking
  local duration = endTime - startTicking
  local progress = elapsedTime / duration
  
  local x1, y1, z1 = screenW * 0.3563, screenH * 0.1500, screenW * 0.3297, screenH * 0.1685
  local x2, y2, z2 = screenW * 0.3563, screenH * 0.1000, screenW * 0.3297, screenH * 0.1685
  
  local logoX, logoY, logoZ = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "CosineCurve")
  
  rotation = rotation + 1 > 360 and 0 or rotation + 1
  
  exports.skyrpg_blur:dxDrawBluredRectangle(screenW * 0.0000, screenH * 0.0000, screenW, screenH, tocolor(155, 155, 155, 255))
  
  dxDrawImage(logoX, logoY, screenW * 0.3297, screenH * 0.1685, ":skyrpg_login/images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
  dxDrawImage(screenW * 0.3563, screenH * 0.6000, screenW * 0.3107, screenH * 0.5185, "img/loading.png", rotation, 0, 0, tocolor(255, 255, 255, 255), false)
  
  dxDrawText("Pobieranie zasob�w/danych serwera...", screenW * 0.0590, screenH * 1.0000, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, wFont, "center", "center", false, false, false, false, false)
  
end

addEvent("downloadingData", true)
addEventHandler("downloadingData", root, downloadingFiles)

function loadingInteriorObjects () -- �adowanie obiekt�w w interiorze/pomieszczeniu

  local now = getTickCount()
  local endTime = startTicking + 5000
  local elapsedTime = now - startTicking
  local duration = endTime - startTicking
  local progress = elapsedTime / duration
  
  local x1, y1, z1 = screenW * 0.3563, screenH * 0.1500, screenW * 0.3297, screenH * 0.1685
  local x2, y2, z2 = screenW * 0.3563, screenH * 0.1000, screenW * 0.3297, screenH * 0.1685
  
  local logoX, logoY, logoZ = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "CosineCurve")
  
  rotation = rotation + 1 > 360 and 0 or rotation + 1
  
  exports.skyrpg_blur:dxDrawBluredRectangle(screenW * 0.0000, screenH * 0.0000, screenW, screenH, tocolor(155, 155, 155, 255))
  
  dxDrawImage(logoX, logoY, screenW * 0.3297, screenH * 0.1685, ":skyrpg_login/images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
  dxDrawImage(screenW * 0.3563, screenH * 0.6000, screenW * 0.3107, screenH * 0.5185, "img/loading.png", rotation, 0, 0, tocolor(255, 255, 255, 255), false)
  
  dxDrawText("�adowanie obiekt�w w interiorze...", screenW * 0.0590, screenH * 1.0000, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, wFont, "center", "center", false, false, false, false, false)  

end

addEvent("loadingObjects", true)
addEventHandler("loadingObjects", localPlayer, loadingInteriorObjects)