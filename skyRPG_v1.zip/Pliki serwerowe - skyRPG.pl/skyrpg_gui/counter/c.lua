local lFont = dxCreateFont("counter/fonts/lcz.ttf", 15)
if not lFont then lFont = "default-bold" end

local motory = {
["Freeway"] = true,
["FCR-900"] = true,
["Faggio"] = true,
["Pizzaboy"] = true,
["BF-400"] = true,
["NRG-500"] = true,
["PCJ-600"] = true,
["HPV-1000"] = true,
["Wayfarer"] = true,
["Sanchez"] = true,
["Quadbike"] = true,
}

local sW, sH = guiGetScreenSize()
local screenW, screenH = guiGetScreenSize()

local renderData = {}
renderData[1] =
{
	X = sW - 300,
	Y = sH - 290,
	Y2 = sH - 270,
	W = 300,
	H = 300,
}

addEventHandler("onClientRender", getRootElement(), function()
	if not getElementData(localPlayer, "logged") then return end
	local pojazd = getPedOccupiedVehicle(localPlayer)
	if pojazd then 
		if getVehicleEngineState(pojazd) and getElementData(pojazd, "paliwo") and getElementData(pojazd, "paliwo") < 1 then
			setVehicleEngineState(pojazd, false)
		end
		if getElementData(localPlayer, "hud") then return end
		local sx,sy,sz = getElementVelocity(pojazd)
		local kmh = math.ceil(((sx^2+sy^2+sz^2)^(0.5))*143)
		local paliwo = getElementData(pojazd, "paliwo") or 100
		paliwo = string.format("%1d", paliwo)
		local km = getElementData(pojazd, "przebieg") or 0
		local bak = getElementData(pojazd, "bak") or 100
		km = string.format("%1.2f", km)
		local inf = kmh.."km/h\nBak: "..paliwo.."/"..bak.."L\n"..km.."km"
		local p = getElementData(pojazd, "lrgb")
		local r, g, b = "?"
		if p then
			r, g, b = p.r, p.g, p.b
		else
			r, g, b = 255, 255, 255
		end
		if motory[getVehicleName(pojazd)] then
        	dxDrawText(inf, (screenW * 0.8638) + 1, (screenH * 0.8984) + 1, (screenW * 0.9927) + 1, (screenH * 0.9870) + 1, tocolor(0, 0, 0, 255), 1.00, lFont, "center", "center", false, false, false, false, false)
        	dxDrawText(inf, screenW * 0.8638, screenH * 0.8984, screenW * 0.9927, screenH * 0.9870, tocolor(r, g, b, 255), 1.00, lFont, "center", "center", false, false, false, false, false)
        else
       		if getVehicleOverrideLights(pojazd) ~= 2 then
				dxDrawImage(renderData[1].X, renderData[1].Y, renderData[1].W, renderData[1].H, "counter/img/counter.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
			else
				dxDrawImage(renderData[1].X, renderData[1].Y, renderData[1].W, renderData[1].H, "counter/img/counter.png", 0, 0, 0, tocolor(r, g, b, 255), false)
			end
			kmh = kmh-5
			dxDrawImage(renderData[1].X, renderData[1].Y2, renderData[1].W, renderData[1].H, "counter/img/pointer.png", kmh, 0, 0)
       		dxDrawText(km.."km\nBak: "..paliwo.."/"..bak.."L", (screenW * 0.8858) + 1, (screenH * 0.8893) + 1, (screenW * 0.9810) + 1, (screenH * 0.9518) + 1, tocolor(0, 0, 0, 255), 1.00, lFont, "center", "center", false, false, false, false, false)
        	dxDrawText(km.."km\nBak: "..paliwo.."/"..bak.."L", screenW * 0.8858, screenH * 0.8893, screenW * 0.9810, screenH * 0.9518, tocolor(255, 255, 255, 255), 1.00, lFont, "center", "center", false, false, false, false, false)
        end
	end
end)