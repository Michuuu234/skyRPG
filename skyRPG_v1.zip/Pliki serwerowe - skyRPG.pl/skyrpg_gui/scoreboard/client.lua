local scoreFunc = {}
local screenW, screenH = guiGetScreenSize()
local gracze = "?"
startR = getTickCount()
scoreFunc.page = 1

scoreFunc.onPage = 20

scoreFunc.renderData = {screenW * 0.2723, screenH * 0.1497, screenW * 0.4561, screenH * 0.7005}

function scoreFunc.sort(op1, op2)
	if isElement(op1) and isElement(op2) then
		return getElementData(op1, "id") < getElementData(op2, "id")
	end
end

local czcionka = dxCreateFont(":skyrpg_gui/hud/fonts/normal.ttf", 9)
if not czcionka then czcionka = "default-bold" end

local czcionka2 = dxCreateFont(":skyrpg_gui/hud/fonts/bold.ttf", 10)
if not czcionka2 then czcionka2 = "default-bold" end

local czcionka3 = dxCreateFont(":skyrpg_gui/hud/fonts/normal.ttf", 18)
if not czcionka3 then czcionka2 = "default-bold" end

function scoreFunc.render()
    
	local allPlayers = {}
	for k, v in ipairs(getElementsByType("player")) do
		if v ~= localPlayer then
			table.insert(allPlayers, v)
		end
	end
	table.sort(allPlayers, scoreFunc.sort)
	local _allPlayers = allPlayers
	allPlayers = {}
	table.insert(allPlayers, localPlayer)
	for i = 1, #_allPlayers do
		allPlayers[i + 1] = _allPlayers[i]
	end
	_allPlayers = nil

	local i = 1
	gracze = #allPlayers
	exports["skyrpg_blur"]:dxDrawBluredRectangle(scoreFunc.renderData[1], scoreFunc.renderData[2], scoreFunc.renderData[3], scoreFunc.renderData[4]-30, tocolor(150, 150, 150, 255))
	
	--dxDrawRectangle(screenW * 0.2892, screenH * 0.2279, screenW * 0.4180, screenH * 0.0430, tocolor(158, 24, 188, 155), false)
	dxDrawImage(screenW * 0.2892, screenH * 0.2279, screenW * 0.4180, screenH * 0.0430, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
	for k, v in ipairs(allPlayers) do
		if k >= (scoreFunc.page - 1) * scoreFunc.onPage and k < scoreFunc.page * scoreFunc.onPage then
			local ping = getPlayerPing(v)
			local r, g, b = getPlayerNametagColor(v)
			dxDrawText((getElementData(v, "id") or "-"), screenW * 0.3100, screenH * 0.2813 + (i - 1) * 20, screenW * 0.3175, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText((getElementData(v, "dbid") or "-"), screenW * 0.3655, screenH * 0.2813 + (i - 1) * 20, screenW * 0.3650, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText(getPlayerName(v), screenW * 0.4490, screenH * 0.2813 + (i - 1) * 20, screenW * 0.4495, screenH * 0.3177 + (i - 1) * 20, tocolor(r, g, b, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText((getElementData(v, "punkty") or "-"), screenW * 0.5200, screenH * 0.2813 + (i - 1) * 20, screenW * 0.5200, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText((getElementData(v, "organizacja") or "Brak"), screenW * 0.5700, screenH * 0.2813 + (i - 1) * 20, screenW * 0.5700, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText((getElementData(v, "sluzba") or "Brak"), screenW * 0.6300, screenH * 0.2813 + (i - 1) * 20, screenW * 0.6300, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			dxDrawText(ping, screenW * 0.6815, screenH * 0.2813 + (i - 1) * 20, screenW * 0.6838, screenH * 0.3177 + (i - 1) * 20, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
			i = i + 1
		end
	end
	
	local now = getTickCount()
    local endTime = startR + 1000
    local elapsedTime = now - startR
    local duration = endTime - startR
    local progress = elapsedTime / duration
	
	local x1,y1, z1 = screenW * 0.2900, screenH * 0.1449, screenW * 0.1434, screenH * 0.0694 -- Logo (początek animacji)
    local x2,y2, z2 = screenW * 0.2900, screenH * 0.1499, screenW * 0.1434, screenH * 0.0694 -- Logo (koniec animacji)
	
	local xA,yA,zA = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "CosineCurve")
	--dxDrawText("Forum: http://skyrpg.pl/", (screenW * 0.2892) + 1, (screenH * 0.1628) + 1, (screenW * 0.4400) + 1, (screenH * 0.2148) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka2, "left", "center", false, false, false, false, false)
	--dxDrawText("Forum: http://skyrpg.pl/", screenW * 0.2892, screenH * 0.1628, screenW * 0.4400, screenH * 0.2148, tocolor(255, 255, 255, 255), 1.00, czcionka2, "left", "center", false, false, false, false, false)
	dxDrawText(#allPlayers.." graczy", (screenW * 0.5461) + 1, (screenH * 0.1615) + 1, (screenW * 0.6991) + 1, (screenH * 0.2148) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka3, "right", "center", false, false, false, false, false)
	dxDrawText(#allPlayers.." graczy", screenW * 0.5461, screenH * 0.1615, screenW * 0.6991, screenH * 0.2148, tocolor(255, 255, 255, 255), 1.00, czcionka3, "right", "center", false, false, false, false, false)
	--dxDrawLine(screenW * 0.2899, screenH * 0.2721, screenW * 0.7064, screenH * 0.2721, tocolor(158, 24, 188, 155), 1, false)
	dxDrawImage(screenW * 0.2899, screenH * 0.2721, screenW * 0.4164, screenH * 0.0031, ":skyrpg_gui/scoreboard/img/scoreboardline.png")
	dxDrawText("ID", (screenW * 0.2899) + 1, (screenH * 0.2292) + 1, (screenW * 0.3411) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("ID", screenW * 0.2899, screenH * 0.2292, screenW * 0.3411, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("DBID", (screenW * 0.3655) + 1, (screenH * 0.2292) + 1, (screenW * 0.3650) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("DBID", screenW * 0.3655, screenH * 0.2292, screenW * 0.3650, screenH * 0.271, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Nazwa użytkownika", (screenW * 0.4527) + 1, (screenH * 0.2292) + 1, (screenW * 0.4545) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Nazwa użytkownika", screenW * 0.4527, screenH * 0.2292, screenW * 0.4545, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("RP", (screenW * 0.5200) + 1, (screenH * 0.2292) + 1, (screenW * 0.5200) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("RP", screenW * 0.5200, screenH * 0.2292, screenW * 0.5200, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Organizacja", (screenW * 0.5700) + 1, (screenH * 0.2292) + 1, (screenW * 0.5700) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Organizacja", screenW * 0.5700, screenH * 0.2292, screenW * 0.5700, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Służba", (screenW * 0.6300) + 1, (screenH * 0.2292) + 1, (screenW * 0.6300) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Służba", screenW * 0.6300, screenH * 0.2292, screenW * 0.6300, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Ping", screenW * 0.6654 + 1, screenH * 0.2292 + 1, screenW * 0.7064 + 1, screenH * 0.2721 + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawText("Ping", screenW * 0.6654, screenH * 0.2292, screenW * 0.7064, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	dxDrawImage(xA, yA, screenW * 0.1434, screenH * 0.0694, ":skyrpg_login/images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	--dxDrawImage(screenW * 0.2892, screenH * 0.2279, screenW * 0.4180, screenH * 0.0430, "img/scoreboardline.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
end

function scoreFunc.bindKey(key, state)
	if state == "down" then
		addEventHandler("onClientRender", root, scoreFunc.render)
	else
		removeEventHandler("onClientRender", root, scoreFunc.render)
	end	
end
bindKey("TAB", "both", scoreFunc.bindKey)

bindKey("mouse_wheel_down", "down", function()
	local max = math.floor(gracze / scoreFunc.onPage)+1
	if max == scoreFunc.page then return end
	scoreFunc.page = scoreFunc.page + 1
end)

bindKey("mouse_wheel_up", "down", function()
	if scoreFunc.page == 1 then return end
	scoreFunc.page = scoreFunc.page - 1
end)