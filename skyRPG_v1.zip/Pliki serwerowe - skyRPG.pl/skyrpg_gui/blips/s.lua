local b = {}

b.sapd = createBlip(-1588.59375, 722.12890625, -4.90625, 30)
b.przecho = createBlip(-2110.21, 3.47, 35.32, 35)
b.mechanik = createBlip(-2042.25, 176.56, 28.84, 27)
b.salon = createBlip(-1960.53, 286.00, 35.47, 55)
b.urzad = createBlip(-2054.60, 455.55, 35.17, 39)

setBlipVisibleDistance(b.sapd, 200)
setBlipVisibleDistance(b.salon, 200)
setBlipVisibleDistance(b.przecho, 200)
setBlipVisibleDistance(b.mechanik, 200)
setBlipVisibleDistance(b.urzad, 200)
