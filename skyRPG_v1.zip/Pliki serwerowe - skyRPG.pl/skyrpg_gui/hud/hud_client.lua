local screenW, screenH = guiGetScreenSize()
local sx, sy = guiGetScreenSize()

local wFont = dxCreateFont( "hud/fonts/normal.ttf", 18 )
local oFont = dxCreateFont( "hud/fonts/normal.ttf", 11 )
local sFont = dxCreateFont( "hud/fonts/bold.ttf", 9 )
if not wFont then wFont = "default-bold" end
if not oFont then oFont = "default-bold" end
if not sFont then sFont = "default-bold" end

setTimer(function()
	local online = tonumber(getElementData(localPlayer, "online")) or 0
	if not online then return end
	setElementData(localPlayer, "online", online+1)
end, 60000, 0)

addEventHandler("onClientRender", getRootElement(), function()

	if not isPlayerMapVisible() then
		if getElementData(localPlayer, "hud") then return end
		local rp = getElementData(localPlayer, "punkty")
		local dolary = getElementData(localPlayer, "dolary")
		local sluzba = getElementData(localPlayer, "sluzba") or "Brak"
		dolary = string.format("%1.2f", dolary)
		rp = string.format("%s", rp)
		local hp = getElementHealth(localPlayer)
		local wym = math.floor(hp)
		wym = wym .. "%"
		sluzba = "Służba: "..sluzba
		dxDrawImage(screenW * 0.0000, screenH * 0.0000, screenW, screenH, "hud/img/hud.png")
		dxDrawText(wym, screenW * -0.7921, screenH * 1.8770, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, wFont, "center", "center", false, false, false, false, false)
		dxDrawText(rp, screenW * -0.6621, screenH * 1.8770, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, wFont, "center", "center", false, false, false, false, false)
		dxDrawText(dolary, screenW * -0.4721, screenH * 1.8770, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, wFont, "center", "center", false, false, false, false, false)
		if getElementData(localPlayer, "sluzba") then
			dxDrawText(sluzba, screenW - 70, screenH * 1.7600, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, oFont, "center", "center", false, false, false, false, false)
			dxDrawText("Czas służby: 00:00", screenW - 80, screenH * 1.8000, screenW * 0.9846, screenH * 0.0898, tocolor(255, 255, 255, 255), 1, sFont, "center", "center", false, false, false, false, false)
		end
		dxDrawText("skyRPG.pl - v1.0dev", screenW, screenH-26, screenW-4, screenH, tocolor(240, 240, 240, 122.5), 1, 'default', 'right', 'top', false, false, true)
	end
end)