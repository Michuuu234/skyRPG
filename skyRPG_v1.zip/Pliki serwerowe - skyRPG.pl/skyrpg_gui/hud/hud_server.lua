local chestOfNotifications = createObject ( 980, 0,0, -100 )

function ogloszenie ( source, cmd, ... )
if not getElementData(source, "duty") then outputChatBox("* Nie posiadasz konta premium aby wystawić ogłoszenie!",source,255,0,0) return end
	if ... then
		if not getElementData ( chestOfNotifications, "ogloszenie" ) then
			local text = table.concat({...}, " " )
			setElementData ( chestOfNotifications, "ogloszenie", true )
			setElementData ( chestOfNotifications, "tekstogloszenia", getPlayerName(source):gsub("#%x%x%x%x%x%x","")..": "..text.."")
			setTimer ( setElementData, 20000,1, chestOfNotifications, "ogloszenie", false )
		else
			outputChatBox("Ogłoszenia mogą być nadawane minimum 20 sekund.", source, 255, 96, 0, true ) 
		end
	else
	end
end
addCommandHandler("ogloszenie", ogloszenie)