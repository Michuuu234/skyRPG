addCommandHandler("do", function(g, _, ...)
	if not ... then return end
	local wiadomosc = table.concat({...}, " ")
	local x, y, z = getElementPosition(g)
	local cuboid = createColSphere(x, y, z, 20)
	local wCuboid = getElementsWithinColShape(cuboid, "player")		
	destroyElement(cuboid)
	for _, p in ipairs(wCuboid) do
		local nick = getPlayerName(g)
		wiadomosc = string.gsub(wiadomosc, "#%x%x%x%x%x%x", "")
		local info = "#fc00e7** "..wiadomosc.." ( "..nick.." ) **"
		outputChatBox(info, p, 255, 255, 255, true)
		--triggerClientEvent(source, "dodajLogi", g, getPlayerName(g)..": "..wiadomosc, "chat")
	end
end)

addEventHandler("onPlayerChat", root, function(wiadomosc, typ)
	if typ == 1 then
		cancelEvent()
		local x, y, z = getElementPosition(source)
		local cuboid = createColSphere(x, y, z, 20)
		local wCuboid = getElementsWithinColShape(cuboid, "player")
		destroyElement(cuboid)
		for _, p in ipairs(wCuboid) do
			local nick = getPlayerName(source)
			wiadomosc = string.gsub(wiadomosc, "#%x%x%x%x%x%x", "")
			local info = "#cc1cd8* "..nick.." "..wiadomosc
			outputChatBox(info, p, 255, 255, 255, true)
			--triggerClientEvent(source, "dodajLogi", source, wiadomosc.."("..getPlayerName(source)..")", "chat")
		end
	end
end)

addCommandHandler("mf", function(g, _, ...)
	if not getElementData(g, "sluzba") then
		return exports.skyrpg_gui:addNotification(g, "Tylko frakcje mogą używać tej komendy!", 'error')
	end
	if not ... then return end
	local wiadomosc = table.concat({...}, " ")
	local x, y, z = getElementPosition(g)
	local cuboid = createColSphere(x, y, z, 20)
	local wCuboid = getElementsWithinColShape(cuboid, "player")		
	destroyElement(cuboid)
	for _, p in ipairs(wCuboid) do
		local nick = getPlayerName(g)
		local sluzba = getElementData(g, "sluzba")
		wiadomosc = string.gsub(wiadomosc, "#%x%x%x%x%x%x", "")
		local info = "#fffa00"..nick.." ("..sluzba..") :o< "..wiadomosc..""
		outputChatBox(info, p, 255, 255, 255, true)
		--triggerClientEvent(source, "dodajLogi", g, getPlayerName(g)..": "..wiadomosc, "chat")
	end
end)