local names = {
	gM = "skyRPG.pl - wersja: 1.0",
}

addEventHandler("onResourceStart", resourceRoot, function()

	if not names then return end

	setFPSLimit(60)
	setMapName(names.gM)
	setGameType(names.gM)
	
end)