function dawajto(localPlayer)
	local punkty = getElementData(localPlayer, "punkty")
	local dolary = getElementData(localPlayer, "dolary")
	if getElementData(localPlayer, "premium") then
		setElementData(localPlayer, "punkty", punkty+2)
		setElementData(localPlayer, "dolary", dolary+200)
		exports.skyrpg_gui:addNotification("Otrzymujesz 140$ i 2 RP za 5 minut gry na naszym serwerze!", 'info')
	else
		setElementData(localPlayer, "punkty", punkty+1)
		setElementData(localPlayer, "dolary", dolary+50)
		exports.skyrpg_gui:addNotification("Otrzymujesz 50$ i 1 RP za 5 minut gry na naszym serwerze!", 'info')
	end
end
setTimer (dawajto, 300000, 0, localPlayer)