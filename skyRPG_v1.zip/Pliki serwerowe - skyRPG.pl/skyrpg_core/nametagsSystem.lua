local screenW, screenH = guiGetScreenSize()
local sx, sy = guiGetScreenSize()

local nametagFont = dxCreateFont( ":skyrpg_gui/hud/fonts/normal.ttf", 10 )
if not nametagFont then nametagFont = "default-bold" end

local nCz = dxCreateFont( ":skyrpg_gui/hud/fonts/bold.ttf", 10 )
if not nCz then nCz = "default-bold" end

function kolor(a)
	local p = getElementData(a, "lrgb")
	if p then
		return p.r, p.g, p.b
	else
		return 255, 0, 0
	end
end

addEventHandler("onClientRender", getRootElement(), function()
if not getElementData(localPlayer, "logged") then return end
for _, p in ipairs(getElementsByType("player")) do
	local rx, ry, rz = getCameraMatrix()
    local x, y, z = getPedBonePosition(p, 5)
    local sy, sx = getScreenFromWorldPosition(x, y, z + 0.5)
    local dystans = getDistanceBetweenPoints3D(rx, ry, rz, x, y, z)
    local alpha = getElementAlpha(p)
    local dimensions = getElementDimension(localPlayer) == getElementDimension(p)
    local interiors = getElementInterior(localPlayer) == getElementInterior(p)
    if dystans < 25 and sy and sx and interiors and dimensions and alpha > 0 and p ~= localPlayer then
		local nick = getPlayerName(p)
		local dbid = getElementData(p, "dbid")
		local rp = getElementData(p, "punkty")
		if not getElementData(p, "logged") then return end
			dxDrawText(nick:gsub("#%x%x%x%x%x%x","").." (DBID: "..dbid..", "..rp.." RP)", sy + 1, sx + 6, sy + 1, sx + 1, tocolor(0, 0, 0, 190), 1, nCz, "center", "center", false, false, false, true, false)
			dxDrawText(nick.." (DBID: "..dbid..", "..rp.." RP)", sy, sx + 5, sy, sx, tocolor(255, 255, 255, 190), 1, nCz, "center", "center", false, false, false, true, false)
			local duty = getElementData(p, "duty")
			local premium = getElementData(p, "premium")
			if duty then
				ranga = getElementData(p, "ranga")
			elseif premium then
				ranga =  "#ffff43Premium#ffffff"
			else
				ranga = "#939393Gracz#ffffff"
			end
		dxDrawText(ranga:gsub("#%x%x%x%x%x%x",""), sy + 1, sx - 34, sy + 1, sx + 1, tocolor(0, 0, 0, 190), 1, nCz, "center", "center", false, false, false, true, false)
		dxDrawText(ranga, sy, sx - 35, sy, sx, tocolor(255, 255, 255, 190), 1, nCz, "center", "center", false, false, false, true, false)
    end
end

for _,v in ipairs(getElementsByType("vehicle")) do
	local x1x, y1x, z1x = getElementPosition(v)
	local x2x, y2x, z2x = getElementPosition(localPlayer)
	local dist = getDistanceBetweenPoints3D(x1x,y1x,z1x, x2x,y2x,z2x)
	if dist < 7 then
		local sx,sy = getScreenFromWorldPosition(x1x, y1x, z1x)
	    if sx and sy then
	        local text = getElementData(v, "nametag") or ""
	        dxDrawText(text, sx+1, sy+1, sx+1, sy+1, tocolor(0, 0, 0, 255), 1, nametagFont, "center", "center")
	        dxDrawText(text, sx, sy, sx, sy, tocolor(255, 255, 255, 255), 1, nametagFont, "center", "center")
	   	end
	end
end

for i,v in ipairs(getElementsByType("ped")) do
	local x1, y1, z1 = getPedBonePosition(v, 8)
	local x2, y2, z2 = getElementPosition(localPlayer)
	local dist = getDistanceBetweenPoints3D(x1,y1,z1+0.3, x2,y2,z2)
	if dist < 30 then
		if isLineOfSightClear(x1,y1,z1+0.3, x2,y2,z2, true, false, false, true, false, false, true, getPedOccupiedVehicle(localPlayer) or localPlayer) then
			local sx,sy = getScreenFromWorldPosition(x1, y1, z1+0.4)
			if sx and sy then
				local text = getElementData(v, "name") or ""
				dxDrawText(text, sx+1, sy+1, sx+1, sy+1, tocolor(0, 0, 0, 190), 1, nametagFont, "center", "center", false, false, false, false)
				dxDrawText(text, sx, sy, sx, sy, tocolor(255, 255, 255, 190), 1, nametagFont, "center", "center", false, false, false, true)
			end
		end
	end
end

for i,v in ipairs(getElementsByType("text")) do
	local x1, y1, z1 = getElementPosition(v)
	local x2, y2, z2 = getElementPosition(localPlayer)
	local dist = getDistanceBetweenPoints3D(x1,y1,z1, x2,y2,z2)
	if dist < 30 then
		if isLineOfSightClear(x1,y1,z1+1.2, x2,y2,z2, true, false, true, true, false, false, true, localPlayer) then
			local sx,sy = getScreenFromWorldPosition(x1, y1, z1)
			if sx and sy then
				local text = getElementData(v, "text") or ""
				dxDrawText(text, sx+1, sy+1, sx+1, sy+1, tocolor(0, 0, 0, 255), 1, nametagFont, "center", "center")
				dxDrawText(text, sx, sy, sx, sy, tocolor(255, 255, 255, 255), 1, nametagFont, "center", "center")
			end
		end
	end
end
end)

addEventHandler("onClientResourceStart", resourceRoot, function()
	for _,v in ipairs(getElementsByType("player")) do
		setPlayerNametagShowing(v, false)
	end
end)

addEventHandler("onClientPlayerSpawn", root,  function()
	setPlayerNametagShowing(source, false)
end)