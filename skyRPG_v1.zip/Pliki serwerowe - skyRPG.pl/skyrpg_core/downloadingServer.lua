addEventHandler("onPlayerJoin", root, function()
	local downloading = true
	if downloading == true then
		exports.skyrpg_loading:downloadingData(root)
	else
		
	end
	addEventHandler("onClientFileDownloadComplete", root, function()
		downloading = false
	end)
end)