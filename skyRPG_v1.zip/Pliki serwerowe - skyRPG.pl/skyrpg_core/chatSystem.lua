function idRanga(g)
  local ranga = getElementData(g, "duty")
  local premium = getElementData(g, "premium")
  if ranga == 1 then
    return "#43ff43"
  elseif ranga == 2 then
	  return "#009000"
	elseif ranga == 3 then
	  return "#4343ff"
	elseif ranga == 4 then
	  return "#ff0000"
	end
  if premium then
    return "#ffff00"
  else
    return "#ffffff"
  end
end

addEventHandler("onPlayerChat", root, function(wiadomosc, typ)
	if typ == 0 then
		cancelEvent()
		local x, y, z = getElementPosition(source)
		local cuboid = createColSphere(x, y, z, 20)
		local wCuboid = getElementsWithinColShape(cuboid, "player")
		destroyElement(cuboid)
		for _, p in ipairs(wCuboid) do
			local nick = getPlayerName(source)
			local id = getElementData(source, "id") or 0
			local kolor = idRanga(source)
			wiadomosc = string.gsub(wiadomosc, "#%x%x%x%x%x%x", "")
			local info = "#939393["..id.."] "..kolor..""..nick.."#ffffff: "..wiadomosc
			outputChatBox(info, p, 255, 255, 255, true)
			--triggerClientEvent(source, "dodajLogi", source, getPlayerName(source)..": "..wiadomosc, "chat")
		end
	end
end)