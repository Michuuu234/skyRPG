local commandSpam = {}

function preventCommandSpam()
	if (not commandSpam[source]) then
		commandSpam[source] = 1
	elseif (commandSpam[source] == 10) then
		cancelEvent()
		kickPlayer(source, "[antyCheat] Wyrzucono za spam komendami na serwerze.")
	else
		commandSpam[source] = commandSpam[source] + 1
	end
end
addEventHandler("onPlayerCommand", root, preventCommandSpam)
setTimer(function() commandSpam = {} end, 1000, 0)

addEventHandler("onVehicleStartEnter", root, function(g, s)
	if s ~= 0 then return end
	if getVehicleController(source) and getVehicleController(source) ~= g then
		cancelEvent()
	end
end)

addEventHandler("onPlayerCommand", root, function(c)
	if not getElementData(source, "logged") then
		if c == "Toggle" then return end
		cancelEvent()
	end
end)