addEventHandler("onPlayerWasted", root, function()
	plr=source
	exports.skyrpg_gui:addNotification(plr, "Jesteś nieprzytomny na 30 sekund. Zostaniesz przerzucony na spawn.", 'info')
	setTimer(function()
		spawnPlayer(plr, -1983.36, 138.37, 27.69, 0, getElementData(plr, "skin"), 0)
		setCameraTarget(plr, plr)
		setElementModel(plr, getElementData(plr, "skin"))
	end, 30000, 1)
end)