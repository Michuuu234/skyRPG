local markery = {
-- {kordy, kordy2, kordy3, kordy4}
{-2057.07, 454.56, 35.17, -2027.52, 477.18, 161.55, -2027.55, 480.63, 161.55, -2052.78, 458.15, 35.17, 1, 0},
{-1730.01, -107.93, 3.55, -1721.81, -152.38, 43.99, -1721.43, -157.60, 43.99, -1731.97, -109.89, 3.55, 1, 0},
{-1694.19, 951.45, 24.89, -1701.37, 950.61, 109.65, -1704.15, 950.68, 109.65, -1697.79, 950.63, 24.89, 1, 0},
}

addEventHandler("onResourceStart", resourceRoot, function()
	for _, m in ipairs(markery) do
		local wejscie = createMarker(m[1], m[2], m[3]+0.6, "arrow", 1, 0, 0, 0, 125)
		local wyjscie = createMarker(m[7], m[8], m[9]+0.5, "arrow", 1, 0, 0, 0, 125)
		setElementInterior(wyjscie, m[14])
		setElementDimension(wyjscie, m[13])
		addEventHandler("onMarkerHit", wejscie, function(hit)
			if getElementType(hit) ~= "player" then return end
			if not isPedInVehicle(hit) then
			fadeCamera(hit, false)
			setElementFrozen(hit, true)
			setTimer(function()
				fadeCamera(hit, true)
				setElementFrozen(hit, false)
				setElementPosition(hit, m[4], m[5], m[6])
				setElementInterior(hit, m[14])
				setElementDimension(hit, m[13])
			end, 1500, 1)
		end
		end)
		addEventHandler("onMarkerHit", wyjscie, function(hit)
			if getElementType(hit) ~= "player" then return end
			if not isPedInVehicle(hit) then
			fadeCamera(hit, false)
			setElementFrozen(hit, true)
			setTimer(function()
				if isPedInVehicle(hit) then return end
				fadeCamera(hit, true)
				setElementFrozen(hit, false)
				setElementPosition(hit, m[10], m[11], m[12])
				setElementInterior(hit, 0)
				setElementDimension(hit, 0)
			end, 1500, 1)
		end
		end)
	end
end)