function jp(gracz)
	if getElementData(gracz, "duty") then
		if doesPlayerHaveJetPack(gracz) then
			removePlayerJetPack(gracz)
		else
			givePlayerJetPack(gracz)
		end
	end
end

local jednostki = {
	["m"] = true,
	["h"] = true,
	["d"] = true,	
}

function getTimestamp(year, month, day, hour, minute, second)
    -- initiate variables
    local monthseconds = { 2678400, 2419200, 2678400, 2592000, 2678400, 2592000, 2678400, 2678400, 2592000, 2678400, 2592000, 2678400 }
    local timestamp = 0
    local datetime = getRealTime()
    year, month, day = year or datetime.year + 1900, month or datetime.month + 1, day or datetime.monthday
    hour, minute, second = hour or datetime.hour, minute or datetime.minute, second or datetime.second

    -- calculate timestamp
    for i=1970, year-1 do timestamp = timestamp + (isLeapYear(i) and 31622400 or 31536000) end
    for i=1, month-1 do timestamp = timestamp + ((isLeapYear(year) and i == 2) and 2505600 or monthseconds[i]) end
    timestamp = timestamp + 86400 * (day - 1) + 3600 * hour + 60 * minute + second

    timestamp = timestamp - 3600 --GMT+1 compensation
    if datetime.isdst then timestamp = timestamp - 3600 end

    return timestamp
end

function isLeapYear(year)
    if year then year = math.floor(year)
    else year = getRealTime().year + 1900 end
    return ((year % 4 == 0 and year % 100 ~= 0) or year % 400 == 0)
end

function zbanuj(plr, cmd, target, t1, t2, ...)
	if not getElementData(plr, "duty") then return end
	if not target or not t1 or not t2 or not ... then
		return
	end
	local player = findPlayer(plr, target)
	if not player then return end
		local text = table.concat({...}, ", ")
		local ts_start = getTimestamp()
		if t1 == "m" then
			local t2 = tonumber(t2)
			local ts_final = ts_start + t2*60
			local time = getRealTime(ts_final)
			local txt = getPlayerName(player).." został zbanowany przez "..getPlayerName(plr).." na czas "..t2.." minut z powodu "..text
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			--exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO bany SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
			kickPlayer(player, "Połącz się ponownie")
		elseif t1 == "h" then
			local t2 = tonumber(t2)
			local ts_final = ts_start + t2*3600
			local time = getRealTime(ts_final)
			local txt = getPlayerName(player).." został zbanowany przez "..getPlayerName(plr).." na czas "..t2.." godzin z powodu "..text
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			--exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO bany SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
			kickPlayer(player, "Połącz się ponownie")
		elseif t1 == "d" then
			local t2 = tonumber(t2)
			local ts_final = ts_start + t2*86400
			local time = getRealTime(ts_final)
			local txt = getPlayerName(player).." został zbanowany przez "..getPlayerName(plr).." na czas "..t2.." dni z powodu "..text
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			--exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO bany SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
			kickPlayer(player, "Połącz się ponownie")
	end
end

function kicknij(gracz, _, graczhere, ...)
	if graczhere and ... and getElementData(gracz, "duty") then
		graczhere = findPlayer(gracz, graczhere)
		if not graczhere then
			--exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			return
		end
		local tresc = table.concat({...}, " ")
		local txt = getPlayerName(graczhere).." został wykopany przez "..getPlayerName(gracz).." z powodu "..tresc
		kickPlayer(graczhere, gracz, tresc)
		outputConsole(txt)
		--triggerClientEvent(root, "notiAdmin", root, txt)
		exports.skyrpg_gui:addNotification(root, txt, 'error')
	end
end

function warnij(gracz, _, graczhere, ...)
	if graczhere and ... and getElementData(gracz, "duty") then
		graczhere = findPlayer(gracz, graczhere)
		if not graczhere then
			--exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			return
		end
		local tresc = table.concat({...}, " ")
		local txt2 = getPlayerName(graczhere).." zostałeś ostrzeżony przez "..getPlayerName(gracz).." z powodu "..tresc
		local txt = getPlayerName(graczhere).." został ostrzeżony przez "..getPlayerName(gracz).." z powodu "..tresc
				exports.skyrpg_gui:addNotification(gracz, txt2, 'error')
		exports.skyrpg_gui:addNotification(root, txt, 'error')
		outputChatBox(" ", graczhere, 255, 0, 0)
		outputChatBox("Otrzymałeś ostrzeżenie od "..getPlayerName(gracz), graczhere, 255, 0, 0)
		outputChatBox(" ", graczhere, 255, 0, 0)
		outputChatBox("Powód: "..tresc, graczhere, 255, 255, 255)
		outputChatBox(" ", graczhere, 255, 0, 0)
		outputChatBox("Nie stosowanie się do ostrzeżenia, może skutkować kickiem lub banem.", graczhere, 255, 0, 0)
		outputConsole(txt)
	end
end

function prawko(plr, cmd, target, t1, t2, ...)
	if not getElementData(plr, "duty") then return end
	if not target or not t1 or not t2 or not ... then
		return
	end
	local player = findPlayer(plr, target)
	if not player then return end
		local text = table.concat({...}, ", ")
		local ts_start = getTimestamp()
		if t1 == "m" then
			local t2 = tonumber(t2)
			local ts_final = ts_start + t2*60
			local time = getRealTime(ts_final)
			local txt = getPlayerName(player).." otrzymał zakaz prowadzenia pojazdów kat. A,B,C od "..getPlayerName(plr).." na czas "..t2.." minut z powodu "..text
			--exports.skyrpg_gui:addNotification(root, txt, 'error')
			exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			removePedFromVehicle(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO prawka SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
		elseif t1 == "h" then
			local t2 = tonumber(t2)
			local ts_final = ts_start + t2*3600
			local time = getRealTime(ts_final)
			removePedFromVehicle(player)
			local txt = getPlayerName(player).." otrzymał zakaz prowadzenia pojazdów kat. A,B,C od "..getPlayerName(plr).." na czas "..t2.." godzin z powodu "..text
			exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO prawka SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
		elseif t1 == "d" then
			local t2 = tonumber(t2)
			removePedFromVehicle(player)
			local ts_final = ts_start + t2*86400
			local time = getRealTime(ts_final)
			local txt = getPlayerName(player).." otrzymał zakaz prowadzenia pojazdów kat. A,B,C od "..getPlayerName(plr).." na czas "..t2.." dni z powodu "..text
			exports.skyrpg_gui:addNotification(root, txt, 'error')
			outputConsole(txt)
			local user_id = getElementData(player, "dbid")
			local user_serial = getPlayerSerial(player)
			local final_date = (time.year+1900).."-"..(time.month+1).."-"..(time.monthday).." "..(time.hour+1)..":"..(time.minute)..":"..(time.second)
			exports.skyrpg_db:query("INSERT INTO prawka SET nick=?, serial=?, ip=?, data=?, admin=?", getPlayerName(player), getPlayerSerial(player), getPlayerIP(player), final_date, getPlayerName(plr))
	end
end

function report(gracz, _, graczhere, ...)
	if ... and graczhere then
		graczhere = findPlayer(gracz, graczhere)
		if not graczhere then 
			exports.skyrpg_gui:addNotification(gracz, "Nie znaleziono podanego gracza.", 'error')
			return
		end
		local tekst = table.concat({...}, " ")
		--exports["nm-noti"]:noti("Pomyślnie wysłano zgłoszenie na gracza "..getPlayerName(graczhere).." o treści "..tekst, gracz)
		exports.skyrpg_gui:addNotification(gracz, "Pomyślnie wysłano zgłoszenie na gracza "..getPlayerName(graczhere).."", 'success')
		exports.skyrpg_gui:addNotification(graczhere, "Gracz "..getPlayerName(gracz).." napisał na ciebie raport z powodem: "..tekst, 'error')
		tekst = getPlayerName(gracz).."("..getElementData(gracz, "id")..") > "..getPlayerName(graczhere).."("..getElementData(graczhere, "id").."): "..tekst
		triggerClientEvent(root, "dRaps", root, tekst, getElementData(graczhere, "id"))
	end
end
addCommandHandler("report", report)
addCommandHandler("raport", report)

addCommandHandler("cl", function(gracz, _, graczh)
	if getElementData(gracz, "duty") and graczh then
		triggerClientEvent(root, "uRaps", root, graczh)
		--exports["nm-noti"]:noti("Pomyślnie usunięto reporta.", gracz)
		exports.skyrpg_gui:addNotification(gracz, "Usunięto pomyślnie raporta.", 'success')
	end
end)

function findPlayer(p, ph)
	for i,v in ipairs(getElementsByType("player")) do
		if tonumber(ph) then
			if getElementData(v, "id") == tonumber(ph) then
				return getPlayerFromName(getPlayerName(v))
			end
		else
			if string.find(string.gsub(getPlayerName(v):lower(),"#%x%x%x%x%x%x", ""), ph:lower(), 1, true) then
				return getPlayerFromName(getPlayerName(v))
			end
		end
	end
end

addEventHandler("onPlayerCommand", root, function(cmd)
	if cmd == "shutdown" then cancelEvent() end
	if cmd == "aexec" then cancelEvent() end
	if cmd == "runcode" then cancelEvent() end
	if cmd == "refreshall" then cancelEvent() end
	if cmd == "logout" then cancelEvent() end
	if cmd == "msg" then cancelEvent() end
	if cmd == "nick" then cancelEvent() end
	if cmd == "chgmypass" then cancelEvent() end
	if cmd == "ver" then cancelEvent() end
	if cmd == "whowas" then cancelEvent() end
	if cmd == "whois" then cancelEvent() end
	if cmd == "sver" then cancelEvent() end
	if cmd == "openports" then cancelEvent() end
	if cmd == "help" then cancelEvent() end
	if cmd == "debugdb" then cancelEvent() end
	if cmd == "ase" then cancelEvent() end
	if cmd == "stopall" then cancelEvent() end
	if cmd == "refreshall" then cancelEvent() end
	if getPlayerSerial(source) ~= "86866E7FEF366B70DFD6D5BC22324FA1" then
		if cmd == "login" then cancelEvent() end
		if cmd == "register" then cancelEvent() end
		if cmd == "reloadmodule" then cancelEvent() end
		if cmd == "unloadmodule" then cancelEvent() end
		if cmd == "loadmodule" then cancelEvent() end
		if cmd == "delaccount" then cancelEvent() end
		if cmd == "addaccount" then cancelEvent() end
		if cmd == "aclrequest" then cancelEvent() end
		if cmd == "upgrade" then cancelEvent() end
		if cmd == "list" then cancelEvent() end
		if cmd == "check" then cancelEvent() end
		if cmd == "refreshall" then cancelEvent() end
		if cmd == "maps" then cancelEvent() end
		if cmd == "zarejestruj" then cancelEvent() end
	end
end)

function globalChat(gracz, _, ...)
	if getElementData(gracz, "duty") and ... then
		local tekst = table.concat({...}, " ")
		local duty = getElementData(gracz, "duty")
		local c1, c2, c3 = 255, 255, 255
		if duty == 1 then
			c1, c2, c3 = 0, 255, 155
		elseif duty == 2 then
			c1, c2, c3 = 0, 100, 0
		elseif duty == 3 then
			c1, c2, c3 = 0, 155, 255
		elseif duty == 4 then
			c1, c2, c3 = 255, 0, 0
		end
		outputChatBox(">> "..tekst.." #ffffff- "..getPlayerName(gracz), root, c1, c2, c3, true)
	end
end

function tpTo(gracz, _, graczhere)
	if getElementData(gracz, "duty") and graczhere then
		local graczhere = findPlayer(gracz, graczhere)
		if not graczhere then return end
		local x, y, z = getElementPosition(graczhere)
		setElementPosition(gracz, x, y, z)
		--exports["nm-noti"]:noti("Teleportowałeś się do "..getPlayerName(graczhere), gracz)
		exports.skyrpg_gui:addNotification(gracz, "Teleportowałeś się do "..getPlayerName(graczhere)..".", 'info')
		exports.skyrpg_gui:addNotification(graczhere, getPlayerName(gracz).." przeteleportował się do ciebie.", 'info')
	end
end

function dpln(gracz, _, graczhere, ile)
	if getElementData(gracz, "duty") == 4 and graczhere and ile then
		local graczhere = findPlayer(gracz, graczhere)
		if not graczhere then return end
		ile = string.format("%1.2f", ile)
		setElementData(graczhere, "dolary", getElementData(graczhere, "dolary")+ile)
		--exports["nm-noti"]:noti("Dałeś "..ile.."$ graczu "..getPlayerName(graczhere), gracz)
		--exports["nm-noti"]:noti("Otrzymałeś "..ile.."$ od "..getPlayerName(gracz), graczhere)
		exports.skyrpg_gui:addNotification(gracz, "Dałeś "..ile.."$ graczu "..getPlayerName(graczhere), 'info')
		exports.skyrpg_gui:addNotification(graczhere, "Otrzymałeś "..ile.."$ od "..getPlayerName(gracz), 'success')
	end
end

function dmp(gracz, _, graczhere, ile)
	if getElementData(gracz, "duty") == 4 and graczhere and ile then
		local graczhere = findPlayer(gracz, graczhere)
		if not graczhere then return end
		setElementData(graczhere, "punkty", getElementData(graczhere, "punkty")+ile)
		--exports["nm-noti"]:noti("Dałeś "..ile.." mP graczu "..getPlayerName(graczhere), gracz)
		--exports["nm-noti"]:noti("Otrzymałeś "..ile.." mP od "..getPlayerName(gracz), graczhere)
		exports.skyrpg_gui:addNotification(gracz, "Dałeś "..ile.." RP graczu "..getPlayerName(graczhere), 'info')
		exports.skyrpg_gui:addNotification(graczhere, "Otrzymałeś "..ile.." RP od "..getPlayerName(gracz), 'success')
	end
end

function paliwo(gracz)
	if getElementData(gracz, "duty") and isPedInVehicle(gracz) then
		local pojazd = getPedOccupiedVehicle(gracz)
		if not pojazd then return end
		local bak = getElementData(pojazd, "bak") or 100
		setElementData(pojazd, "paliwo", bak)
		--exports["nm-noti"]:noti("Zatankowałeś pojazd.", gracz)
		exports.skyrpg_gui:addNotification(gracz, "Zatankowałeś pojazd.", 'info')
	end
end

function tpToHere(gracz, _, graczhere)
	if getElementData(gracz, "duty") and graczhere then
		local graczhere = findPlayer(gracz, graczhere)
		if not graczhere then return end
		local x, y, z = getElementPosition(gracz)
		setElementPosition(graczhere, x, y, z)
		--exports["nm-noti"]:noti("Teleportowałeś do siebie użytkownika "..getPlayerName(graczhere), gracz)
		exports.skyrpg_gui:addNotification(gracz, "Teleportowałeś do siebie "..getPlayerName(graczhere)..".", 'info')
		exports.skyrpg_gui:addNotification(graczhere, getPlayerName(gracz).." przeteleportował ceibie do siebie.", 'info')
	end
end

function tpv(gracz, _, id)
	if getElementData(gracz, "duty") and id then
		id = tonumber(id)
		for i,v in ipairs(getElementsByType("vehicle")) do
			if getElementData(v, "id") and getElementData(v, "id") == id then
				local x, y, z = getElementPosition(v)
				setElementPosition(gracz, x, y, z)
			end
		end
	end
end

function tpvh(gracz, _, id)
	if getElementData(gracz, "duty") and id then
		id = tonumber(id)
		for i,v in ipairs(getElementsByType("vehicle")) do
			if getElementData(v, "id") and getElementData(v, "id") == id then
				local x, y, z = getElementPosition(gracz)
				setElementPosition(v, x, y, z)
			end
		end
	end
end

function aChat(gracz, _, ...)
	if ... and getElementData(gracz, "duty") then
		local tekst = table.concat({...}, " ")
		for i,v in ipairs(getElementsByType("player")) do
			if getElementData(v, "duty") then
				outputChatBox("#ff0000[Administracja]#ffffff "..getPlayerName(gracz)..": "..tekst, v, 255, 255, 255, true)
			end
		end
	end
end

function inv(gracz)
	if getElementData(gracz, "duty") then
		if getElementAlpha(gracz) == 255 then
			setElementAlpha(gracz, 0)
		else
			setElementAlpha(gracz, 255)
		end
	end
end

function spec(gracz, _, graczhere)
	if graczhere and getElementData(gracz, "duty") then
		graczhere = findPlayer(gracz, graczhere)
		if not graczhere then return end
		if getCameraTarget(gracz) == graczhere then
			setCameraTarget(gracz, gracz)
		else
			setCameraTarget(gracz, graczhere)
		end
	end
end

function komendy(gracz)
	if getElementData(gracz, "duty") then
		outputChatBox("Komendy administracji:", gracz)
outputChatBox("/g - komenda , która umożliwia nam wysyłanie wiadomości na chacie globalnym ( wszyscy je widza ) . Kolor tekstu zależy od rangi .", gracz)
outputChatBox("/wy <id/nick> <powod> (wyrzucenie gracza z serwera)", gracz)
outputChatBox("/zb <id/nick> <jednostka> <czas> <powod> (zbanowanie gracza na serwerze)", gracz)
outputChatBox("/zp <id/nick> <jednostka <czas> <powod> (zabranie prawa jazdy gracza)", gracz)
outputChatBox("/jp (jectpack)", gracz)
outputChatBox("/tp <id/nick> (teleport do gracza)", gracz)
outputChatBox("/tph <id/nick> (teleport gracza do siebie)", gracz)
outputChatBox("/tpv <id> (teleport do pojazdu)", gracz)
outputChatBox("/tpvh <id> (teleport pojazdu do siebie)", gracz)
outputChatBox("/wa <id/nick> <powod> (ostrzezenie gracza)", gracz)
outputChatBox("/dpaliwo (danie paliwa do pojazdu)", gracz)
outputChatBox("/a <tresc> (chat ekipy)", gracz)
	end
end

local komendy = {
{"g", globalChat},
{"tp",	tpTo},
{"tph",	tpToHere},
{"dpln", dpln},
{"dpaliwo", paliwo},
{"tpv", tpv},
{"tpvh", tpvh},
{"a", aChat},
{"zb", zbanuj},
{"wy", kicknij},
{"wa", warnij},
{"zp", prawko},
{"jp", jp},
{"spec", spec},
{"inv", inv},
{"cmd", komendy},
{"dmp", dmp},
}

addEventHandler("onResourceStart", resourceRoot, function()
	for i, v in ipairs(komendy) do
		addCommandHandler(v[1], v[2])
	end
end)

addCommandHandler("duty", function(gracz)
	local spr = exports.skyrpg_db:query("SELECT * FROM ekipa WHERE gracz=? AND serial=?", getPlayerName(gracz), getPlayerSerial(gracz))
	if #spr > 0 then
		if getElementData(gracz, "duty") then
			setElementData(gracz, "duty", false)
			setElementData(gracz, "ranga", false)
	  	outputChatBox("Wylogowałeś się z duty ekipy servera.", gracz, 0, 255, 0)
		else
			setElementData(gracz, "duty", spr[1].tranga)
			setElementData(gracz, "ranga", spr[1].ranga)
			outputChatBox("Zalogowałeś się na duty ekipy servera.", gracz, 0, 255, 0)
		end
	end
end)

addCommandHandler("admins", function(plr)
	local modzi = {}
	local admini = {}
	local rconi = {}
  for i,v in ipairs(getElementsByType("player")) do

	if getElementData(v, "duty") == 4 then
	  local r = getPlayerName(v).." ("..getElementData(v,"id")..")"
		table.insert(rconi, r)
	elseif getElementData(v, "duty") == 3 then
		local a = getPlayerName(v).." ("..getElementData(v,"id")..")"
		table.insert(admini, a)
	elseif getElementData(v, "duty") == 2 then
		local m = getPlayerName(v).." ("..getElementData(v,"id")..")"
		table.insert(modzi, m)
  end
	end

  outputChatBox("Zarząd:", plr, 255, 0, 0)
  if #rconi > 0 then
    outputChatBox(" " ..table.concat(rconi,", "), plr, 255, 255, 255)
  else
		outputChatBox(" brak", plr, 255, 255, 255)
  end

	outputChatBox("Administratorzy:", plr, 60, 54, 226)
  if #admini > 0 then
    outputChatBox(" " ..table.concat(admini,", "), plr, 255, 255, 255)
  else
		outputChatBox(" brak", plr, 255, 255, 255)
  end

	outputChatBox("Moderatorzy:", plr, 0, 100, 0)
  if #modzi > 0 then
    outputChatBox(" " ..table.concat(modzi,", "), plr, 255, 255, 255)
  else
		outputChatBox(" brak", plr, 255, 255, 255)
  end
end)

