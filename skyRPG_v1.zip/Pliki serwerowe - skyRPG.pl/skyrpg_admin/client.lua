 --[[
	Autor: Asper
	Dla servera: .newMode
	Skrypt: Duty administracji
]]

local screenW, screenH = guiGetScreenSize()

local text = {}

addEventHandler("onClientRender", root, function()
	if getElementData(localPlayer, "duty") then
		local r_text = ""
		for i,v in ipairs(text) do
			r_text = r_text.."\n"..v[1]
		end
		dxDrawText("Lista reportów\n"..r_text, screenW * 0.8500+1, screenH * 0.1862+1, screenW * 0.9861+1, screenH * 0.6875+1, tocolor(0, 0, 0), 1.00, "default", "center", "top", false, true, false, false, false)
		dxDrawText("Lista reportów\n"..r_text, screenW * 0.8500, screenH * 0.1862, screenW * 0.9861, screenH * 0.6875, tocolor(255, 255, 255), 1.00, "default", "center", "top", false, true, false, false, false)
	end
end)

addEvent("dRaps", true)
addEventHandler("dRaps", root, function(tekst, gracz)
  	if #text > 10 then
		table.remove(text, 1)
  	end
   	table.insert(text, {tekst, gracz})
end)

addEvent("uRaps", true)
addEventHandler("uRaps", root, function(gracz)
	for i=#text,1,-1 do
		if text[i][2] == tonumber(gracz) then
	  		table.remove(text, i)
		end
	end
end)

local ltext = {}

addEventHandler("onClientRender", root, function()
	if getElementData(localPlayer, "duty") then
		local l_text = ""
		for i,v in ipairs(ltext) do
			l_text = l_text.."\n"..v
		end
		dxDrawText("Lista przelewów\n"..l_text, screenW * 0.5500+1, screenH * 0.1862+1, screenW * 0.9861+1, screenH * 0.6875+1, tocolor(0, 0, 0), 1.00, "default", "center", "top", false, true, false, false, false)
		dxDrawText("Lista przelewów\n"..l_text, screenW * 0.5500, screenH * 0.1862, screenW * 0.9861, screenH * 0.6875, tocolor(255, 255, 255), 1.00, "default", "center", "top", false, true, false, false, false)
	end
end)

addEvent("dLogi", true)
addEventHandler("dLogi", root, function(tekst)
  	if #ltext > 10 then
		table.remove(ltext, 1)
  	end
   	table.insert(ltext, tekst)
end)

-- banicje etc

local okno = guiCreateWindow(0.00, 0.00, 1.00, 1.00, "Zostałeś zbanowany na tym serwerze!", true)
guiWindowSetMovable(okno, false)
guiSetAlpha(okno, 1.00)
local napisy = guiCreateLabel(0.32, 0.38, 0.36, 0.24, "Zostałeś zbanowany na tym serwerze!\n\nBan został nałożony na serial:\nBan został nałożony na IP:\nBan został nałożony na nick:\nBan jest aktywny do:\nNick admina banującego:\n\nOd kary możesz zaapelować na forum: new-mode.pl", true, okno)
guiLabelSetHorizontalAlign(napisy, "center", false)
guiLabelSetVerticalAlign(napisy, "center")
local przycisk = guiCreateButton(0.33, 0.65, 0.34, 0.15, "Wyjdź z serwera", true, okno) 
guiSetVisible(okno, false)

addEvent("oknoZbanowany", true)
addEventHandler("oknoZbanowany", root, function(g, i, s, d, a, n)
	guiSetVisible(okno, true)
	guiSetText(napisy, "Zostałeś zbanowany na tym serwerze!\n\nBan został nałożony na serial: "..s.."\nBan został nałożony na IP: "..i.."\nBan został nałożony na nick: "..n.."\nBan jest aktywny do: "..d.."\nNick admina banującego: "..a.."\n\nOd kary możesz zaapelować na forum: new-mode.pl")
end)

local wFont = dxCreateFont( ":nm-interakcja/czcionka.ttf", 10)
if not wFont then wFont = "default-bold" end

local wFont2 = dxCreateFont( ":nm-geodeta/czcionka.ttf", 9)
if not wFont2 then wFont2 = "default-bold" end

local text = false

local screenW, screenH = guiGetScreenSize()

function gui()
		--exports["nm-blur"]:dxDrawBluredRectangle(screenW * 0.2430, screenH * 0.9219, screenW * 0.2943, screenH * 0.0651, tocolor(150, 150, 150, 255))
        --dxDrawText(text, (screenW * 0.2438) + 1, (screenH * 0.9193) + 1, (screenW * 0.5373) + 1, (screenH * 0.9870) + 1, tocolor(0, 0, 0, 255), 1.00, wFont2, "center", "center", false, true, false, false, false)
        --dxDrawText(text, screenW * 0.2438, screenH * 0.9193, screenW * 0.5373, screenH * 0.9870, tocolor(255, 0, 0, 255), 1.00, wFont2, "center", "center", false, true, false, false, false)
end

addEvent("notiAdmin", true)
addEventHandler("notiAdmin", root, function(t)
	addEventHandler("onClientPreRender", root, gui)
	text = t
	setTimer(function()
		removeEventHandler("onClientPreRender", root, gui)
		text = false
	end, 7500, 1)
end)

addEventHandler("onClientGUIClick", przycisk, function()
	triggerServerEvent("banWyrzuc", localPlayer)
end)

local wtext = false

function gui2()
       -- exports["nm-blur"]:dxDrawBluredRectangle(screenW * 0.2972, screenH * 0.2083, screenW * 0.4063, screenH * 0.5833, tocolor(150, 150, 150, 255))
        --dxDrawRectangle(screenW * 0.2972, screenH * 0.2070, screenW * 0.4063, screenH * 0.0651, tocolor(255, 27, 27, 155), false)
        --dxDrawText("Otrzymałeś ostrzeżenie od "..wtext.kto, (screenW * 0.2965) + 1, (screenH * 0.2057) + 1, (screenW * 0.7035) + 1, (screenH * 0.2721) + 1, tocolor(0, 0, 0, 255), 1.00, wFont, "center", "center", false, false, false, false, false)
        --dxDrawText("Otrzymałeś ostrzeżenie od "..wtext.kto, screenW * 0.2965, screenH * 0.2057, screenW * 0.7035, screenH * 0.2721, tocolor(255, 255, 255, 255), 1.00, wFont, "center", "center", false, false, false, false, false)
        --dxDrawText("Powód: "..wtext.powod.."\n\n\n\nNie stosowanie się do ostrzeżenia może skutkować kickiem lub banem.", (screenW * 0.3199) + 1, (screenH * 0.3333) + 1, (screenW * 0.6852) + 1, (screenH * 0.7174) + 1, tocolor(0, 0, 0, 255), 1.00, wFont, "center", "center", false, false, false, false, false)
        --dxDrawText("Powód: "..wtext.powod.."\n\n\n\nNie stosowanie się do ostrzeżenia może skutkować kickiem lub banem.", screenW * 0.3199, screenH * 0.3333, screenW * 0.6852, screenH * 0.7174, tocolor(255, 255, 255, 255), 1.00, wFont, "center", "center", false, false, false, false, false)
end

addEvent("warnPlayer", true)
addEventHandler("warnPlayer", root, function(t)
	addEventHandler("onClientPreRender", root, gui2)
	wtext = t
	setTimer(function()
		removeEventHandler("onClientPreRender", root, gui2)
		wtext = false
	end, 7500, 1)
end)