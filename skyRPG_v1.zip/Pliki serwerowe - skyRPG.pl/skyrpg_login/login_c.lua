--    skyRPG, panel logowania    --
-- 	      Autor: Michuuu 		--

start = getTickCount()
startR = getTickCount()
local screenW, screenH = guiGetScreenSize()
local music = false
local czcionka = dxCreateFont("fonts/normal.ttf", 12)
local uzytkownik = guiCreateEdit(0.406, 0.395, 0.1976, 0.06, "", true)
local haslo = guiCreateEdit(0.406, 0.506, 0.1976, 0.06, "", true)
guiEditSetMaxLength(uzytkownik, 10)
guiEditSetMaxLength(haslo, 25)
guiSetAlpha(uzytkownik, 0.5)
guiSetAlpha(haslo, 0.5)
guiEditSetMasked(haslo, true)
local font = guiCreateFont("fonts/normal.ttf")
guiSetFont(uzytkownik, font)
guiSetFont(haslo, font)
guiSetVisible(uzytkownik, false)
guiSetVisible(haslo, false)

function removeLabels ()
guiSetVisible(uzytkownik, false)
guiSetVisible(haslo, false)
end

if getElementData (localPlayer, "logged") then
	return
end

-- Funkcja na mousePosition, nie ruszaj jej! --

local sx, sy = guiGetScreenSize()

function mousePosition(psx,psy,pssx,pssy,abx,aby)
    if not isCursorShowing() then return end
    cx,cy=getCursorPosition()
    cx,cy=cx*sx,cy*sy
    if cx >= psx and cx <= psx+pssx and cy >= psy and cy <= psy+pssy then
        return true,cx,cy
    else
        return false
    end
end

-- Funkcja na mousePosition, nie ruszaj jej! --

-- Całe GUI --

local glowna = true -- Główne GUI
local logowanie = false -- Logowanie
local rejestracja = false -- Rejestracja
local zmiany = false -- Zmiany na serwerze

addEventHandler("onClientClick", root, function(button, state)
  local login = guiGetText(uzytkownik)
  local haslo = guiGetText(haslo)
  if button == "left" and state == "down" and mousePosition(screenW * 0.6163, screenH * 0.3236, screenW * 0.1635, screenH * 0.3012) and glowna == true then
	glowna = false -- Główne GUI
    logowanie = true 
    rejestracja = false
	zmiany = false
    removeEventHandler("onClientRender", root, glownaGUI)
    addEventHandler("onClientRender", root, logowanieGUI)
  elseif button == "left" and state == "down" and mousePosition(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912) and logowanie == true then
	glowna = true -- Główne GUI
    logowanie = false
    rejestracja = false
	zmiany = false
	removeLabels()
    removeEventHandler("onClientRender", root, logowanieGUI)
    addEventHandler("onClientRender", root, glownaGUI)
  elseif button == "left" and state == "down" and mousePosition(screenW * 0.8161, screenH * 0.3236, screenW * 0.1635, screenH * 0.3012) and glowna == true then
	glowna = false -- Główne GUI
    logowanie = false
    rejestracja = true
	zmiany = false
    removeEventHandler("onClientRender", root, glownaGUI)
    addEventHandler("onClientRender", root, rejestracjaGUI)
  elseif button == "left" and state == "down" and mousePosition(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912) and rejestracja == true then
	glowna = true -- Główne GUI
    logowanie = false
    rejestracja = false
	zmiany = false
	removeLabels()
    removeEventHandler("onClientRender", root, rejestracjaGUI)
    addEventHandler("onClientRender", root, glownaGUI)
  elseif button == "left" and state == "down" and mousePosition(screenW * 0.4479, screenH * 0.6500, screenW * 0.1047, screenH * 0.0600) and logowanie == true then
    if login:len() < 3 then
      changeNotification("Podany login ma za mało znaków.")
      return
    end
    if haslo:len() < 3 then
      changeNotification("Podane hasło ma za mało znaków.")
      return
    end
    login = string.gsub(login, "[ ]", "")
    haslo = string.gsub(haslo, "[ ]", "")
    triggerServerEvent("log_in_server", localPlayer, login, haslo)
  elseif button == "left" and state == "down" and mousePosition(screenW * 0.4479, screenH * 0.6500, screenW * 0.1047, screenH * 0.0600) and rejestracja == true then
    if login:len() < 3 then
      changeNotification("Podany login ma za mało znaków.")
      return
    end
    if haslo:len() < 3 then
      changeNotification("Podane hasło ma za mało znaków.")
      return
    end
    login = string.gsub(login, "[ ]", "")
    haslo = string.gsub(haslo, "[ ]", "")
    triggerServerEvent("register_server", localPlayer, login, haslo)
  end
end)

function glownaGUI ()

	local now = getTickCount()
    local endTime = start + 4000
    local elapsedTime = now - start
    local duration = endTime - start
    local progress = elapsedTime / duration
	
	local nowl = getTickCount()
	local endTimel = start + 6000
	local elapsedTimel = nowl - start
	local durationl = endTimel - start
	local progressl = elapsedTimel / durationl
	
	local nowr = getTickCount()
	local endTimer = start + 7000
	local elapsedTimer = nowr - start
	local durationr = endTimer - start
	local progressr = elapsedTimer / durationr
	
	local nowc = getTickCount()
	local endTimec = start + 7000
	local elapsedTimec = nowc - start
	local durationc = endTimec - start
	local progressc = elapsedTimec / durationc
	
    local x1,y1, z1 = screenW * -1.0263, screenH * 0.4009, screenW * -1.1047, screenH * -0.9417 -- Logo (początek animacji)
    local x2,y2, z2 = screenW * 0.0263, screenH * 0.4009, screenW * 0.3297, screenH * 0.1685 -- Logo (koniec animacji)
	
    local x3,y3, z3 = screenW * 0.6163, screenH * -2.0000, screenW * -1.1047, screenH * -0.9417 -- Logowanie (początek animacji)
    local x4,y4, z4 = screenW * 0.6163, screenH * 0.3236, screenW * 0.1635, screenH * 0.3012 -- Logowanie (koniec animacji)
	
    local x5,y5, z5 = screenW * 0.8161, screenH * 2.0000, screenW * 0.1635, screenH * 0.3012 -- Rejestracja (początek animacji)
    local x6,y6, z6 = screenW * 0.8161, screenH * 0.3236, screenW * 0.1635, screenH * 0.3012 -- Rejestracja (koniec animacji)
	
    local x7,y7, z7 = screenW * 1.2000, screenH * 3.2010, screenW * 0.4898, screenH * 0.7448 -- Copyright (początek animacji)
    local x8,y8, z8 = screenW * 1.2000, screenH * 1.2010, screenW * 0.4898, screenH * 0.7448 -- Copyright (koniec animacji)
	
    local x,y,z = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "OutQuad")
    local xl,yl,zl = interpolateBetween(x3, y3, z3, x4, y4, z4, progressl, "OutQuad")
    local xr,yr,zr = interpolateBetween(x5, y5, z5, x6, y6, z6, progressr, "OutQuad")
    local xc,yc,zc = interpolateBetween(x7, y7, z7, x8, y8, z8, progressc, "OutQuad")
	
	setCameraMatrix(-59.00, 518.17, 136.11, -100000, 0, 0)
	exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.0000, screenH * 0.0000, screenW, screenH, tocolor(150, 150, 150, 255))
	
    if mousePosition(xl, yl, screenW * 0.1635, screenH * 0.3012) then
       dxDrawImage(xl, yl, screenW * 0.1635, screenH * 0.3012, "images/buttons/login_hover.png")
    else
		dxDrawImage(xl, yl, screenW * 0.1635, screenH * 0.3012, "images/buttons/login_nohover.png")
    end
		
	if mousePosition(xr, yr, screenW * 0.1635, screenH * 0.3012) then
		dxDrawImage(xr, yr, screenW * 0.1635, screenH * 0.3012, "images/buttons/register_hover.png")
    else
		dxDrawImage(xr, yr, screenW * 0.1635, screenH * 0.3012, "images/buttons/register_nohover.png")
    end
		
	dxDrawImage(x, y, screenW * 0.3297, screenH * 0.1685, "images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawText("Copyright © 2017 skyrpg.pl", xc, yc, screenW * 0.4898, screenH * 0.7448, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
	
end

function logowanieGUI ()

	local now = getTickCount()
    local endTime = startR + 1000
    local elapsedTime = now - startR
    local duration = endTime - startR
    local progress = elapsedTime / duration
	
	local x1,y1, z1 = screenW * 0.3363, screenH * 0.1300, screenW * 0.3297, screenH * 0.1685 -- Logo (początek animacji)
    local x2,y2, z2 = screenW * 0.3363, screenH * 0.1000, screenW * 0.3297, screenH * 0.1685 -- Logo (koniec animacji)
	
	local xA,yA,zA = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "CosineCurve")
	
	exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.0000, screenH * 0.0000, screenW, screenH, tocolor(150, 150, 150, 255))
	dxDrawImage(xA, yA, screenW * 0.3297, screenH * 0.1685, "images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.2869, screenH * 0.3500, screenW * 0.4297, screenH * 0.3685, "images/gui/background_login.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.4479, screenH * 0.6500, screenW * 0.1047, screenH * 0.0600, "images/gui/login_button.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	
	if mousePosition(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912) then
		dxDrawImage(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912, "images/buttons/back_hover.png")
    else
		dxDrawImage(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912, "images/buttons/back_nohover.png")
    end
	
	dxDrawImage(screenW * 0.3709, screenH * 0.4000, screenW * 0.0195, screenH * 0.0395, "images/gui/user.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.3709, screenH * 0.5200, screenW * 0.0195, screenH * 0.0395, "images/gui/password.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	guiSetVisible(uzytkownik, true)
	guiSetVisible(haslo, true)
	dxDrawRectangle(screenW * 0.4078, screenH * 0.3971, screenW * 0.1955, screenH * 0.0560, tocolor(255, 255, 255, 255), false)
    dxDrawRectangle(screenW * 0.4078, screenH * 0.5091, screenW * 0.1955, screenH * 0.0560, tocolor(255, 255, 255, 255), false)
	
end

function rejestracjaGUI ()

	local now = getTickCount()
    local endTime = startR + 1000
    local elapsedTime = now - startR
    local duration = endTime - startR
    local progress = elapsedTime / duration
	
	local x1,y1, z1 = screenW * 0.3363, screenH * 0.1300, screenW * 0.3297, screenH * 0.1685 -- Logo (początek animacji)
    local x2,y2, z2 = screenW * 0.3363, screenH * 0.1000, screenW * 0.3297, screenH * 0.1685 -- Logo (koniec animacji)
	
	local xA,yA,zA = interpolateBetween(x1, y1, z1, x2, y2, z2, progress, "CosineCurve")
	
	exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.0000, screenH * 0.0000, screenW, screenH, tocolor(150, 150, 150, 255))
	dxDrawImage(xA, yA, screenW * 0.3297, screenH * 0.1685, "images/gui/logo.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.2869, screenH * 0.3500, screenW * 0.4297, screenH * 0.3685, "images/gui/background_register.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.4479, screenH * 0.6500, screenW * 0.1047, screenH * 0.0600, "images/gui/register_button.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	
	if mousePosition(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912) then
		dxDrawImage(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912, "images/buttons/back_hover.png")
    else
		dxDrawImage(screenW * 0.4279, screenH * 0.6900, screenW * 0.1435, screenH * 0.2912, "images/buttons/back_nohover.png")
    end
	
	dxDrawImage(screenW * 0.3709, screenH * 0.4000, screenW * 0.0195, screenH * 0.0395, "images/gui/user.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	dxDrawImage(screenW * 0.3709, screenH * 0.5200, screenW * 0.0195, screenH * 0.0395, "images/gui/password.png", 0, 0, 0, tocolor(255, 255, 255, 255), false)
	guiSetVisible(uzytkownik, true)
	guiSetVisible(haslo, true)
	dxDrawRectangle(screenW * 0.4078, screenH * 0.3971, screenW * 0.1955, screenH * 0.0560, tocolor(255, 255, 255, 255), false)
    dxDrawRectangle(screenW * 0.4078, screenH * 0.5091, screenW * 0.1955, screenH * 0.0560, tocolor(255, 255, 255, 255), false)
	
end

local napisy = "?"
local spawn = 2
local wybieranie = false
local mspawn = 3
local spawn2 = "Stacja kolejowa, San Fierro"
local spawn3 = "Przechowalnia, San Fierro"
local spawn1 = "Urząd miasta, San Fierro"

function wybieranieGUI ()
  if spawn == 1 then 
    napisy = spawn1 
    setCameraMatrix(-2017.04, 476.85, 45.17, -100000, 0, 0)
  end
  
  if spawn == 2 then 
    napisy = spawn2 
    setCameraMatrix(-2017.52, 125.51, 35.54, 0, 0, 0)
  end
  
  if spawn == 3 then 
    napisy = spawn3 
    setCameraMatrix(-2085.47, 0.20, 45, -100000, 0, 0)
  end
  exports["skyrpg_blur"]:dxDrawBluredRectangle(screenW * 0.3715, screenH * 0.0260, screenW * 0.2130, screenH * 0.0794, tocolor(150, 150, 150, 255))
  dxDrawText(napisy.."\nAby zarządać użyj strzałek\nAby zatwierdzić opcje użyj spacji", (screenW * 0.2050) + 1, (screenH * 0.0117) + 1, (screenW * 0.7555) + 1, (screenH * 0.1211) + 1, tocolor(0, 0, 0, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
  dxDrawText(napisy.."\nAby zarządać użyj strzałek\nAby zatwierdzić opcje użyj spacji", screenW * 0.2050, screenH * 0.0117, screenW * 0.7555, screenH * 0.1211, tocolor(255, 255, 255, 255), 1.00, czcionka, "center", "center", false, false, false, false, false)
end

bindKey("arrow_l", "both", function(k, s)
  if s ~= "down" then return end
  if wybieranie ~= true then return end
  if spawn == 1 then return end
  spawn = spawn-1
end)

bindKey("arrow_r", "both", function(k, s)
  if s ~= "down" then return end
  if wybieranie ~= true then return end
  if spawn == 3 then return end
  spawn = spawn+1
end)

bindKey("space", "down", function()
  if wybieranie ~= true then return end
  removeEventHandler("onClientRender", root, wybieranieGUI)
  wybieranie = false
  showChat(true)
  showCursor(false)
  stopSound(muzyka)
  if spawn == 1 then
    triggerServerEvent("spawn", localPlayer, "urzad")
  elseif spawn == 2 then
    triggerServerEvent("spawn", localPlayer, "spawn")
  elseif spawn == 3 then
    triggerServerEvent("spawn", localPlayer, "przecho")
  end
end)

addEventHandler("onClientResourceStart", resourceRoot, function()
  addEventHandler("onClientRender", root, glownaGUI)
  showChat(false)
  showCursor(true)
  setPlayerHudComponentVisible("all", false)
  muzyka = playSound("sounds/login.mp3", true)
  fadeCamera(true)
  --triggerServerEvent("sprawdzBana", localPlayer)
end)

addEvent("bShowedLogin", true)
addEventHandler("bShowedLogin", root, function()
  guiSetVisible(uzytkownik, false)
  guiSetVisible(haslo, false)
  removeEventHandler("onClientRender", root, logowanieGUI)
  logowanie = false
  glowna = false
  rejestracja = false
  zmiany = false
end)

addEvent("removeElementsLogin", true)
addEventHandler("removeElementsLogin", root, function(domy)
  guiSetVisible(uzytkownik, false)
  guiSetVisible(haslo, false)
  removeEventHandler("onClientRender", root, glownaGUI)
  removeEventHandler("onClientRender", root, logowanieGUI)
  removeEventHandler("onClientRender", root, rejestracjaGUI)
  addEventHandler("onClientRender", root, wybieranieGUI)
  wybieranie = true
  logowanie = false
  rejestracja = false
  glowna = false
  zmiany = false
end)

function changeNotification(text)
  exports["skyrpg_gui"]:addNotification(text, 'error')
end

addEvent("changeNotification", true)
addEventHandler("changeNotification", root, changeNotification)